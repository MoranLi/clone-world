/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id: IIOPHelloServerTest.java 1664 2008-03-09 12:18:41Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.ng.test;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NameClassPair;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;

import org.ow2.cmi.admin.CMIAdmin;
import org.ow2.cmi.admin.CMIMBeanConfigException;
import org.ow2.cmi.config.CMIConfigException;
import org.ow2.cmi.config.CMIProperty;
import org.ow2.cmi.config.JNDIConfig;
import org.ow2.cmi.info.ClusteredObjectInfo;
import org.ow2.cmi.lb.policy.FirstAvailable;
import org.ow2.cmi.reference.CMIReference;
import org.ow2.cmi.reference.ObjectNotFoundException;
import org.ow2.cmi.test.IIOPHelloServer;
import org.ow2.cmi.test.TestItf;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * TestNG .
 *
 * @author The new CMI team
 */
public class IIOPHelloServerTest {

    private static CMIAdmin cmiAdmin = null;

    private static Context ic = null;

    private static Context ic1 = null;

    private static Context ic2 = null;

    protected static HashMap<String, TestItf> testItfs = new HashMap<String, TestItf>();

    /**
     * Protocol used in the client side.
     */
    private static final String default_protocol = "iiop";

    /**
     * Provider URL to use for connecting.
     */
    private static String providerURLs = "iiop://localhost:2007";

    /**
     * Provider URL to use for connecting.
     */
    private static String providerURLs2 = "iiop://localhost:20098";

    /**
     * Wrapped factory.
     */
    private static String wrappedFactoryName = "com.sun.jndi.cosnaming.CNCtxFactory";

    /**
     * RMi registry port.
     */
    public static final int IIOP1_REGISTRY_PORT = 2007;

    /**
     * Other RMi registry port.
     */
    public static final int IIOP2_REGISTRY_PORT = 20098;

    /**
     * Transient name service.
     */
    private Process tnameserv = null;


    /**
     * Setup for test case.
     *
     * @throws Exception
     *             if super method fails
     */
    @BeforeMethod
    protected void setUp() throws Exception {

//		FileOutputStream fos = new FileOutputStream("output/reports/testNGerrors.txt");
//		PrintStream ps = new PrintStream(fos);
//		System.setErr(ps);



    }

    /**
     * Tests the bind "toto".
     */
    @Test
    public void testBind() throws Throwable {

        Hashtable<String, ?> cmiEnv;
        tnameserv = Runtime.getRuntime().exec(
                System.getProperty("java.home") + System.getProperty("file.separator") + "bin"
                + System.getProperty("file.separator") + "tnameserv -ORBInitialPort " + IIOP1_REGISTRY_PORT);

        Thread.sleep(2000);

        try {
            Properties p = new Properties();
            p.put(JNDIConfig.INITIAL_PROVIDER_URLS, providerURLs);
            p.put(JNDIConfig.WRAPPED_INITIAL_CONTEXT_FACTORY, wrappedFactoryName);
            p.put(JNDIConfig.WRAPPED_PROTOCOL, default_protocol);
            p.put(JNDIConfig.SERVER_MODE, "true");
            p.put(CMIProperty.REPLICATION_ENABLED.getPropertyName(), "true");
            p.put(CMIProperty.REPLICATION_MANAGER_CLASS.getPropertyName(),
            "org.ow2.cmi.controller.server.impl.jgroups.JGroupsClusterViewManager");
            String stack =
                "TCP(start_port=7800):" +
                "TCPPING(timeout=3000;initial_hosts=localhost[7800],localhost[7801]):" +
                "FD_SOCK:" +
                "VERIFY_SUSPECT(timeout=1500):" +
                "pbcast.NAKACK(gc_lag=5;retransmit_timeout=3000):" +
                "UNICAST(timeout=5000):" +
                "pbcast.STABLE(desired_avg_gossip=10000):" +
                "FRAG2(frag_size=60000):" +
                "pbcast.GMS(join_timeout=5000;shun=false;print_local_addr=true):" +
                "pbcast.STATE_TRANSFER";
            p.put("cmi.server.impl.jgroups.stack", stack);
            p.put(CMIProperty.MBEAN_DOMAIN_NAME.getPropertyName(), "CMI");
            p.put(CMIProperty.CMIADMIN_MBEAN_NAME.getPropertyName(), "CMIAdmin");
            p.put(CMIProperty.PROVIDER_BOUND.getPropertyName(), "true");

            cmiEnv = JNDIConfig.getCMIEnv(p);
            ic = new InitialContext(cmiEnv);
            cmiAdmin = CMIAdmin.getCMIAdmin();

            IIOPHelloServer s = new IIOPHelloServer("toto");
            ic.rebind("toto", s);
            ((TestItf) ic.lookup("toto")).display();
            ic.unbind("toto");
            NamingEnumeration<NameClassPair> list = ic.list(ic.getNameInNamespace());
            ic.close();
        } finally {
            tnameserv.destroy();
        }
    }

//	/**
//	* Tests the bind "toto".
//	*/
//	@Test(dependsOnMethods="testBind")
//	public void testBind1() {

//	Hashtable<String, ?> cmiEnv;

//	try {
//	this.registry2 = LocateRegistry.createRegistry(RMI2_REGISTRY_PORT);

//	Properties p = new Properties();
//	p.put(INITIAL_CONTEXT_FACTORY, cmi_factory);
//	p.put(INITIAL_PROVIDER_URLS, providerURLs2);
//	p.put(WRAPPED_INITIAL_CONTEXT_FACTORY, wrappedFactoryName);
//	p.put(WRAPPED_PROTOCOL, default_protocol);

//	p.put("cmi.mode.server", "true");
//	p.put("cmi.server.start.replication", "true");
//	p.put("cmi.server.manager.class",
//	"org.ow2.cmi.controller.server.replication.jgroups.JGroupsClusterViewManager");
//	p.put("cmi.server.manager.jgroups.conf", "jgroups-cmi.xml");
//	p.put("cmi.server.manager.jgroups.gc", "10000");
//	p.put("cmi.server.admin.domain", "CMI");
//	p.put("cmi.server.admin.mbean", "CMIAdmin");
//	p.put("cmi.server.provider.bind", "true");

//	cmiEnv = JNDIConfig.getCMIEnv(p);
//	ic1 = new InitialContext(cmiEnv);
//	cmiAdmin = CMIAdmin.getCMIAdmin();

//	System.out.println("Binding \"" + "toto" + "\"...");
//	JRMPHelloServer s1 = new JRMPHelloServer("toto");
//	ic1.rebind("toto", s1);

//	} catch (NamingException e) {
//	// TODO Auto-generated catch block
//	e.printStackTrace();
//	} catch (CMIConfigException e) {
//	// TODO Auto-generated catch block
//	e.printStackTrace();
//	} catch (RemoteException e) {
//	e.printStackTrace();
//	}
//	}

//	/**
//	* Tests the lookup "toto".
//	*/
//	@Test(dependsOnMethods = "testBind1")
//	public void testLookup() {

//	Hashtable<String, ?> cmiEnv;

//	try {

//	Properties p = new Properties();
//	p.put(INITIAL_CONTEXT_FACTORY, cmi_factory);
//	p.put(INITIAL_PROVIDER_URLS, providerURLs);
//	p.put(WRAPPED_INITIAL_CONTEXT_FACTORY, wrappedFactoryName);
//	p.put(WRAPPED_PROTOCOL, default_protocol);

//	p.put("cmi.mode.server", "false");
//	p.put("cmi.client.refresh.time", "50000");

//	cmiEnv = JNDIConfig.getCMIEnv(p);
//	ic2 = new InitialContext(cmiEnv);

//	cmiAdmin = CMIAdmin.getCMIAdmin();

//	System.out.println("Lookup \"" + "toto" + "\"...");
//	TestItf testItf = (TestItf) ic2.lookup("toto");
//	testItfs.put("toto", testItf);

//	} catch (CMIConfigException e) {
//	// TODO Auto-generated catch block
//	e.printStackTrace();
//	} catch (NamingException e) {
//	e.printStackTrace();
//	}
//	}

//	/**
//	* Tests the invoke "toto".
//	*/
//	@Test(dependsOnMethods = "testLookup")
//	public void testInvoke() {
//	try {
//	System.out.print("Invoke \"" + "toto" + "\"...");
//	testItfs.get("toto").display();
//	} catch (RemoteException e) {
//	e.printStackTrace();
//	}
//	}

//	/**
//	* Tests the policy.
//	*/
//	@Test(dependsOnMethods = "testInvoke")
//	public void testChangePolicy() {
//	try {
//	System.out.println("before change the policy: " + cmiAdmin.getLBPolicyClassName("toto"));
//	cmiAdmin.setLBPolicyClassName("toto", "FirstAvailablePolicy.class");
//	System.out.println("after change the policy: " + cmiAdmin.getLBPolicyClassName("toto"));
//	} catch (ObjectNotFoundException e) {
//	// TODO Auto-generated catch block
//	e.printStackTrace();
//	}
//	}

//	/**
//	* Tests the lookup "toto".
//	*/
//	@Test(dependsOnMethods = "testChangePolicy")
//	public void testChangePolicyLookup() {
//	try {
//	System.out.println("Re-Lookup \"" + "toto" + "\"...");
//	TestItf testItf = (TestItf) ic2.lookup("toto");
//	testItfs.put("toto", testItf);
//	} catch (NamingException e) {
//	e.printStackTrace();
//	}
//	}

//	/**
//	* Tests the invoke "toto".
//	*/
//	@Test(dependsOnMethods = "testChangePolicyLookup")
//	public void testChangePolicyInvoke() {
//	try {
//	System.out.print("Re-Invoke \"" + "toto" + "\"...");
//	testItfs.get("toto").display();
//	} catch (RemoteException e) {
//	e.printStackTrace();
//	}
//	}
}
