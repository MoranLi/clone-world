/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007 Bull S.A.S.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id:ClientClusterViewManagerException.java 949 2007-06-02 17:24:33Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.controller.client;


/**
 * Exception thrown if there is a failure in the manager of the cluster view at client-side.
 * @author The new CMI team
 */
public class ClientClusterViewManagerException extends RuntimeException {

    /**
     * Id for serializable class.
     */
    private static final long serialVersionUID = -2952476018272870779L;

    public ClientClusterViewManagerException(final String message) {
        super(message);
    }

    public ClientClusterViewManagerException(final String message, final Throwable cause) {
        super(message, cause);
    }
}
