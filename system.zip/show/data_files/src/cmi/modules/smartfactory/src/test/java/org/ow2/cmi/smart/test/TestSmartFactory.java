/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id: TestSmartFactory.java 1659 2008-03-07 17:46:48Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.smart.test;

import java.io.File;
import java.io.FileOutputStream;
import java.net.URL;
import java.net.URLClassLoader;
import java.rmi.Remote;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Vector;

import javax.naming.Context;
import javax.naming.InitialContext;

import org.ow2.fastrmic.RMIC;
import org.ow2.util.log.Log;
import org.ow2.util.log.LogFactory;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import org.ow2.cmi.config.CMIProperty;
import org.ow2.cmi.config.JNDIConfig;
import org.ow2.cmi.smart.client.SmartClassLoader;
import org.ow2.cmi.smart.server.SmartEndPoint;

/**
 * Test for the smart factory.
 *
 * @author The new CMI team
 *
 */
public class TestSmartFactory {
    /**
     * Logger.
     */
    private static Log logger = LogFactory.getLog(TestSmartFactory.class);

    /**
     * The smart endpoint that listens the requests.
     */
    private SmartEndPoint smartEndPoint = null;

    /**
     * The smart connector.
     */
    private DummySmartConnector sconnector = null;

    /**
     * The smart context.
     */
    private Context initialContext = null;

    /**
     * CMI context.
     */
    private Context cmiContext = null;

    /**
     * The smart endpoint port.
     */
    public static final int SMART_ENDPOINT_PORT = 2505;

    /**
     * The rmi registry port.
     */
    public static final int RMI_REGISTRY_PORT = 2600;

    /**
     * Endpoint classloader.
     */
    private ClassLoader endpointCL = null;

    /**
     * Tmp directory for dumping files.
     */
    private File tmpDir = null;

    /**
     * Registry object.
     */
    private Registry registry = null;

    /**
     * The list of providers url.
     */
    private List<String> urls = null;

    /**
     * Default InitialContextFactory to use.
     */
    private static final String SMART_INITIAL_CONTEXT_FACTORY = "org.ow2.cmi.smart.spi.SmartContextFactory";

    /**
     * The used wrapped factory name.
     */
    private static String wrappedFactoryName = "com.sun.jndi.rmi.registry.RegistryContextFactory";

    /**
     * The default protocol name.
     */
    private static String defaultprotocol = "jrmp";

    /**
     * Initialize a rmi registry and create a cmi context.
     *
     * @throws Throwable
     *             if the registry can not be successfully started or the cmi
     *             context can not be created
     *
     */
    @BeforeClass
    public void init() throws Throwable {
        this.registry = LocateRegistry.createRegistry(RMI_REGISTRY_PORT);
        // Create a smart connector to get the factory name and the provider
        // urls.
        sconnector = new DummySmartConnector();
        sconnector.setProviderURL("jrmp", "rmi://localhost:"
                + RMI_REGISTRY_PORT);
        sconnector.setInitialContextFactoryName("jrmp", wrappedFactoryName);
        this.urls = sconnector.getProviderURLs("jrmp");

        // Create the CMI context.
        Hashtable<String, ?> cmiEnv;

        Properties p = new Properties();
        p.put(JNDIConfig.INITIAL_PROVIDER_URLS, urls.get(0));
        p.put(JNDIConfig.WRAPPED_INITIAL_CONTEXT_FACTORY, wrappedFactoryName);
        p.put(JNDIConfig.WRAPPED_PROTOCOL, defaultprotocol);
        p.put(JNDIConfig.SERVER_MODE, "true");
        p.put(CMIProperty.REPLICATION_ENABLED.getPropertyName(), "true");
        p.put(CMIProperty.REPLICATION_MANAGER_CLASS.getPropertyName(),
                        "org.ow2.cmi.controller.server.impl.jgroups.JGroupsClusterViewManager");
        String stack = "TCP(start_port=7800):"
                + "TCPPING(timeout=3000;initial_hosts=localhost[7800],localhost[7801]):"
                + "FD_SOCK:" + "VERIFY_SUSPECT(timeout=1500):"
                + "pbcast.NAKACK(gc_lag=5;retransmit_timeout=3000):"
                + "UNICAST(timeout=5000):"
                + "pbcast.STABLE(desired_avg_gossip=10000):"
                + "FRAG2(frag_size=60000):"
                + "pbcast.GMS(join_timeout=5000;shun=false;print_local_addr=true):"
                + "pbcast.STATE_TRANSFER";
        p.put("cmi.server.impl.jgroups.stack", stack);
        p.put(CMIProperty.MBEAN_DOMAIN_NAME.getPropertyName(), "CMI");
        p.put(CMIProperty.CMIADMIN_MBEAN_NAME.getPropertyName(), "CMIAdmin");
        p.put(CMIProperty.PROVIDER_BOUND.getPropertyName(), "true");

        // JNDIConfig.fixMultiprotocolSupport(p);
        cmiEnv = JNDIConfig.getCMIEnv(p);
        try {
            cmiContext = new InitialContext(cmiEnv);
        } catch(Exception e) {
            e.printStackTrace();
            Assert.fail("Cannot create a CMIContext", e);
        }

        // Create a classloader
        this.tmpDir = new File(System.getProperty("java.io.tmpdir")
                + File.separator + System.getProperty("user.name")
                + File.separator + "cmi-smart-test");
        if (!tmpDir.exists()) {
            tmpDir.mkdirs();
        }

        URL url = tmpDir.toURI().toURL();
        endpointCL = new URLClassLoader(new URL[] { url }, Thread
                .currentThread().getContextClassLoader());

    }

    /**
     * Test starting a smart end point.
     *
     * @throws Throwable
     *             if the smart end point can not be successfully started.
     */
    @Test
    public void testStartEndPoint() throws Throwable {
        logger.debug("Begin the test of starting a smart endpoint...");

        ClassLoader old = Thread.currentThread().getContextClassLoader();

        try {
            Thread.currentThread().setContextClassLoader(endpointCL);

            // start a smart end point.
            this.smartEndPoint = new SmartEndPoint();
            smartEndPoint.setSmartConnector(sconnector);
            smartEndPoint.setPortNumber(SMART_ENDPOINT_PORT);
            smartEndPoint.start();
            logger.debug("The test of starting a smart end point is finished!");

        } finally {
            Thread.currentThread().setContextClassLoader(old);
        }

    }

    /**
     * Test accessing the smart factory.
     * @throws Exception if it fails.
     */
//    @Test(dependsOnMethods = "testStartEndPoint")
    public void testAccessSmartFactory() throws Exception {
        logger.debug("Begin the test of accessing the smart factory...");
        Hashtable<String, Object> env = new Hashtable<String, Object>();
        env.put(Context.INITIAL_CONTEXT_FACTORY, SMART_INITIAL_CONTEXT_FACTORY);
        env.put(Context.PROVIDER_URL, "smart://localhost:" + SMART_ENDPOINT_PORT);
        this.initialContext = new InitialContext(env);
        logger.debug("The test of accessing the smart factory is finished!");
    }

    /**
     * Test binding an object.
     */
//    @Test(dependsOnMethods = "testAccessSmartFactory")
    public void testBindingObject() throws Exception {
        logger.debug("Begin the test of binding an object");
        String pkgName = "org.ow2.cmi.smart.test";
        String className = "Pony";
        String itfName = "TestItf";
        String fullclzname = pkgName + "." + className;
        String fullitfname = pkgName + "." + itfName;

        String classpath = System.getProperty("java.io.tmpdir")
                + System.getProperty("user.name") + File.separator
                + "cmi-smart-test";

        Vector<String> vcmd = new Vector<String>();
        vcmd.addElement("-classpath");
        vcmd.addElement(classpath);
        vcmd.addElement("-keep");
        vcmd.addElement("-d");
        vcmd.addElement(classpath);
        vcmd.addElement(fullclzname);

        ArrayList<Object> lcmd = new ArrayList<Object>();
        for (Iterator<String> it = vcmd.iterator(); it.hasNext();) {
            Object o = it.next();
            lcmd.add(o);
        }

        // Get the bytecode of the generated class
        byte[] bytecode = GenerateByteCode.getByteForClass(fullclzname.replace(
                '.', '/'), "Hi pony!");

        // Get the bytecode of the generated interface
        byte[] bytesItf = GenerateInterface.getByteForItf(fullitfname.replace(
                '.', '/'));

        // Generate the package org.ow2.cmi.smart.test
        File pkgDir1 = new File(tmpDir, "org");
        pkgDir1.mkdir();
        File pkgDir2 = new File(pkgDir1, "ow2");
        pkgDir2.mkdir();
        File pkgDir3 = new File(pkgDir2, "carol");
        pkgDir3.mkdir();
        File pkgDir4 = new File(pkgDir3, "cmi");
        pkgDir4.mkdir();
        File pkgDir5 = new File(pkgDir4, "smart");
        pkgDir5.mkdir();
        File pkgDir = new File(pkgDir5, "test");
        pkgDir.mkdir();

        // Store the bytecode of class into a file
        FileOutputStream fos;
        fos = new FileOutputStream(new File(pkgDir, className + ".class"));
        fos.write(bytecode);
        fos.close();
        // Store the bytecode of interface into a file
        FileOutputStream fos1;
        fos1 = new FileOutputStream(new File(pkgDir, itfName + ".class"));
        fos1.write(bytesItf);
        fos1.close();

        ClassLoader old = Thread.currentThread().getContextClassLoader();
        try {
            Thread.currentThread().setContextClassLoader(this.endpointCL);

            File stub = new File(pkgDir, className + "_Stub.class");
            if (stub.exists()) {
                stub.delete();
            }
            File skeleton = new File(pkgDir, className + "_Skel.class");
            if (skeleton.exists()) {
                skeleton.delete();
            }

            Remote obj = (Remote) this.endpointCL.loadClass(fullclzname).newInstance();

            // Build the stub using Fast RMIC
            String[] cmd = (String[]) lcmd.toArray(new String[] {});
            RMIC rmic = new RMIC(cmd);
            rmic.run();

            this.cmiContext.bind("Pony", obj);
            logger.debug("The test of binding an object is finished!");
        } finally {
            Thread.currentThread().setContextClassLoader(old);
        }

    }

    /**
     * Test looking up an object and invoking a method.
     *
     * @throws Exception
     *             if the object can not be found.
     */
//    @Test(dependsOnMethods = "testBindingObject")
    public void testLookupObject() throws Exception {
        SmartClassLoader scl = new SmartClassLoader("localhost",SMART_ENDPOINT_PORT);
        ClassLoader old = Thread.currentThread().getContextClassLoader();
        try{
            Thread.currentThread().setContextClassLoader(scl);

        logger.info("Begin the test of look up an object...");
        // look up the object from the smart context.
        Object obj = this.initialContext.lookup("Pony");

        logger.info("The object has been found and downloaded!");
        TestItf testItf = (TestItf) obj;

        logger.info("Try to invoke a method of the object...");
        // invoke the method of the object.
        testItf.hello();

        logger.info("The test for looking up an object and invoking its method is successful!");
        }finally{
            Thread.currentThread().setContextClassLoader(old);
        }

    }

    /**
     * Stop the started registry.
     *
     * @throws Exception
     *             if registry is not stopped
     */
    @AfterClass(alwaysRun = true)
    public void stopRegistry() throws Exception {
        if (registry != null) {
            UnicastRemoteObject.unexportObject(registry, true);
            registry = null;
        }
    }

    /**
     * Stop the started smart end point.
     *
     * @throws Exception
     *             if endpoint is not stopped.
     */
    @AfterClass(alwaysRun = true)
    public void stopEndPoint() throws Exception {
        if (smartEndPoint != null) {
            smartEndPoint.stop();
        }
    }
}
