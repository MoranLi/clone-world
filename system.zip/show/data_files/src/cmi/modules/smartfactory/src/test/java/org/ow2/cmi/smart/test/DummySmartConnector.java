/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id: DummySmartConnector.java 1659 2008-03-07 17:46:48Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.smart.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.ow2.cmi.smart.api.SmartConnector;

/**
 * The dummy smart connector that is used to get
 * the provider url and the factory name.
 * @author The new CMI team
 *
 */
public class DummySmartConnector implements SmartConnector {

    /**
     * The map of protocols and theirs corresponded providers url.
     */
    private Map<String, ArrayList> protoURLs = new HashMap<String, ArrayList>();

    /**
     * The map of protocols and theirs corresponded factory name.
     */
    private Map<String, String> protofactoryname = new HashMap<String, String>();

    /**
     * The list of providers url.
     */
    private ArrayList<String> providerurls = new ArrayList<String>();

    /**
     * Get the initial context factory name.
     * @param protocolName the given protocol name.
     * @return the initial context factory name.
     */
    public String getInitialContextFactoryName(final String protocolName) {
        return this.protofactoryname.get(protocolName);
    }

    /**
     * Get the providers url.
     * @param protocolName the given protocol name.
     * @return the providers url.
     * @throws Exception if the provider urls can not be found.
     */
    public List<String> getProviderURLs(final String protocolName) throws Exception {
        return this.providerurls;
    }

    /**
     * Set the providers url.
     * @param protocolName the given protocol name.
     * @param providerURL the providers url.
     */
    @SuppressWarnings("unchecked")
    public void setProviderURL(final String protocolName, final String providerURL) {
        ArrayList<String> urls = new ArrayList<String>();
        urls.add(providerURL);
        if (protoURLs.get(protocolName) == null){
            protoURLs.put(protocolName, urls);
        }
        this.providerurls = urls;
    }

    /**
     * Set the initial context factory name.
     * @param protocolName the given protocol name.
     * @param factoryName the initial context factory name.
     */
    public void setInitialContextFactoryName(final String protocolName,
            final String factoryName) {
        this.protofactoryname.put(protocolName, factoryName);
    }

}

