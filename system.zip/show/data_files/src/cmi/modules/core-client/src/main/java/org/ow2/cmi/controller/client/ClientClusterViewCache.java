/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007,2008 Bull S.A.S.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: ClientClusterViewCache.java 1695 2008-03-20 13:27:55Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.controller.client;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.ejb.EJBObject;

import net.jcip.annotations.ThreadSafe;

import org.ow2.cmi.lb.data.PolicyData;
import org.ow2.cmi.lb.policy.IPolicy;
import org.ow2.cmi.lb.strategy.IStrategy;
import org.ow2.cmi.reference.CMIReference;
import org.ow2.cmi.reference.ObjectNotFoundException;
import org.ow2.cmi.reference.ServerRef;

/**
 * A cache of cluster view at client side.
 * ClientClusterViewManager refreshes periodically this view.
 * @author The new CMI team
 * @see ClientClusterViewManagerImpl
 */
@ThreadSafe
final class ClientClusterViewCache {

    /**
     * Associations object name - replicated data for policy.
     */
    private final Map<String, PolicyData> policyData =
        new ConcurrentHashMap<String, PolicyData>();

    /**
     * Associations object name - name of interface.
     */
    private final Map<String, Class<?>> itfNames =
        new ConcurrentHashMap<String, Class<?>>();

    /**
     * Set of names of replicated objects.
     */
    private final Set<String> replicatedObjects =
        Collections.synchronizedSet(new HashSet<String>());

    /**
     * Set of names of stateful objects.
     */
    private final Set<String> statefulObjects =
        Collections.synchronizedSet(new HashSet<String>());

    /**
     * Associations object name - name of business interface.
     */
    private final Map<String, Class<? extends EJBObject>> businessNames =
        new ConcurrentHashMap<String, Class<? extends EJBObject>>();

    /**
     * Associations object name - type of policy.
     */
    private final Map<String, Class<? extends IPolicy<?>>> policyClasses =
        new ConcurrentHashMap<String, Class<? extends IPolicy<?>>>();

    /**
     * Associations object name - type of strategy.
     */
    private final Map<String, Class<? extends IStrategy<?>>> strategyClasses =
        new ConcurrentHashMap<String, Class<? extends IStrategy<?>>>();

    /**
     * Associations object name - list of CMI references.
     */
    private final Map<String, List<CMIReference>> cmiReferences =
        new ConcurrentHashMap<String, List<CMIReference>>();

    /**
     * Associations address - load factor.
     */
    private final Map<ServerRef, Integer> loadFactors =
        new ConcurrentHashMap<ServerRef, Integer>();

    /**
     * Associations object name - classnames of the application exceptions.
     */
    private final Map<String, Set<String>> applicationExceptionNames =
        new ConcurrentHashMap<String, Set<String>>();

    /**
     * Default constructor.
     */
    public ClientClusterViewCache() {}

    /**
     * Sets a object's load-balancing policy data (maybe a new version).
     * @param objectName a name of object
     * @param policyData the load balancing policy data
     */
    void setPolicyData(final String objectName, final PolicyData policyData){
        this.policyData.put(objectName, policyData);
    }

    /**
     * @param objectName a name of object
     * @return policy data for a given object
     */
    PolicyData getPolicyData(final String objectName) {
        return policyData.get(objectName);
    }

    /**
     * Sets the interface name of the object with the given name.
     * @param objectName a name of object
     * @param itfName an interface name
     */
    void setItfName(final String objectName, final Class<?> itfName){
        itfNames.put(objectName, itfName);
    }

    /**
     * Gets the interface name of the object with the given name.
     * @param objectName The name of object
     * @return the interface name of the object with the given name
     */
    Class<?> getItfName(final String objectName) {
        return itfNames.get(objectName);
    }

    /**
     * Sets the business interface name of the object with the given name.
     * @param objectName a name of object
     * @param businessName a business interface name
     */
    void setBusinessName(final String objectName, final Class<? extends EJBObject> businessName){
        businessNames.put(objectName, businessName);
    }

    /**
     * Gets the business interface name of the object with the given name.
     * @param objectName a name of object
     * @return the business interface name of the object with the given name
     */
    Class<? extends EJBObject> getBusinessName(final String objectName) {
        return businessNames.get(objectName);
    }

    /**
     * Gets the class of a load-balancing policy.
     * @param className a name of class
     * @return The class of the given load-balancing policy
     */
    Class<? extends IPolicy<?>> getPolicyClass(final String className) {
        return policyClasses.get(className);
    }

    /**
     * Sets the class for the given classname of policy.
     * @param className a name of class
     * @param policyClass a class for the given name of policy
     */
    void setPolicyClass(final String className, final Class<? extends IPolicy<?>> policyClass) {
        policyClasses.put(className, policyClass);
    }

    /**
     * Returns the class for the given classname of strategy.
     * @param className a name of class
     * @return the class for the given classname of strategy
     */
    Class<? extends IStrategy<?>> getStrategyClass(final String className) {
        return strategyClasses.get(className);
    }

    /**
     * Sets the class for the given classname of strategy.
     * @param className a name of class
     * @param strategyClass a class for the given classname of strategy
     */
    void setStrategyClass(
            final String className, final Class<? extends IStrategy<?>> strategyClass) {
        strategyClasses.put(className, strategyClass);
    }

    /**
     * Sets the list of CMIReference of a object with a given name.
     * @param objectName a name of object
     * @param cmiReferences a list of CMIReference
     */
    void setCMIReferences(final String objectName, final List<CMIReference> cmiReferences) {
        this.cmiReferences.put(objectName, cmiReferences);
    }

    /**
     * Returns the list of CMIReference of a object with a given name.
     * @param objectName a name of object
     * @return the list of CMIReference of a object with a given name
     */
    List<CMIReference> getCMIReferences(final String objectName) {
        return cmiReferences.get(objectName);
    }

    /**
     * Returns the load-factor for the server with the given address.
     * @param serverRef a reference on a server
     * @return the load-factor for the server with the given address
     */
    int getLoadFactor(final ServerRef serverRef) {
        return loadFactors.get(serverRef);
    }

    /**
     * Sets the load-factor for the server with the given address.
     * @param serverRef a reference on a server
     * @param loadFactor the load-factor for the server with the given address
     */
    void setLoadFactor(final ServerRef serverRef, final int loadFactor) {
        loadFactors.put(serverRef, loadFactor);
    }

    /**
     * Returns the set of references on known servers.
     * @return the set of references on known servers
     */
    Set<ServerRef> getAddressesOfServer() {
        return loadFactors.keySet();
    }

    /**
     * @return the set of clustered object names
     */
    Set<String> getObjectNames() {
        return new HashSet<String>(itfNames.keySet());
    }

    /**
     * Return true if the object with the given name is stateful.
     * @param objectName a name of object
     * @return true if the object with the given name is stateful
     */
    boolean hasState(final String objectName) {
        return statefulObjects.contains(objectName);
    }

    /**
     * Set if the object with the given name is stateful.
     * @param objectName a name of object
     */
    void setState(final String objectName) {
        statefulObjects.add(objectName);
    }

    /**
     * Return true if the object with the given name is replicated for high-availability.
     * @param objectName a name of object
     * @return true if the object with the given name is replicated for high-availability
     */
    boolean isReplicated(final String objectName) {
        return replicatedObjects.contains(objectName);
    }

    /**
     * Set if the object with the given name is replicated for high-availability.
     * @param objectName a name of object
     */
    void setReplicated(final String objectName) {
        replicatedObjects.add(objectName);
    }

    /**
     * Return classnames of the application exceptions.
     * @param objectName a name of object
     * @return classnames of the application exceptions
     * @throws ObjectNotFoundException if none object has the given name
     */
    Set<String> getApplicationExceptionNames(final String objectName) {
        return applicationExceptionNames.get(objectName);
    }

    /**
     * Set the classnames of the application exceptions.
     * @param objectName a name of object
     * @param classnames of the application exceptions
     * @throws ObjectNotFoundException if none object has the given name
     */
    void setApplicationExceptionNames(final String objectName, final Set<String> applicationExceptionNames) {
        this.applicationExceptionNames.put(objectName, applicationExceptionNames);
    }

}
