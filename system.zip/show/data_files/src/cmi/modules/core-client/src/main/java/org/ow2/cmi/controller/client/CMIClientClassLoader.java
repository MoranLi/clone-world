/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id: CMIClientClassLoader.java 1659 2008-03-07 17:46:48Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.controller.client;

import net.jcip.annotations.ThreadSafe;

import org.ow2.cmi.controller.client.ClientClusterViewManager;
import org.ow2.cmi.controller.client.ClientClusterViewManagerException;
import org.ow2.util.log.Log;
import org.ow2.util.log.LogFactory;

/**
 * This classloader downloads bytecode of the missing policies and strategies from a remote server.
 * @author The new CMI team
 */
@ThreadSafe
public final class CMIClientClassLoader extends ClassLoader {

    /**
     * Logger.
     */
    private static Log logger = LogFactory.getLog(CMIClientClassLoader.class);

    /**
     * ClientClusterViewManager to delegate download of bytecode from a remote server.
     */
    private final ClientClusterViewManager clientClusterViewManager;

    /**
     * Constructs a ClassLoader to enable the download of bytecode (for policy and strategy) from a remote server.
     * @param parent the parent class loader for delegation
     * @param clientClusterViewManager a manager to delegate the download of bytecode from a remote server
     */
    public CMIClientClassLoader(final ClassLoader parent, final ClientClusterViewManager clientClusterViewManager) {
        super(parent);
        this.clientClusterViewManager = clientClusterViewManager;
    }

    /**
     * Finds the class with the specified <a href="#name">binary name</a>.
     * This method downloads the bytecode from a provider of the cluster view.
     * @param binaryName The <a href="#name">binary name</a> of the class
     * @return  The resulting <tt>Class</tt> object
     * @throws ClassNotFoundException If the class could not be found
     */
    @Override
    protected synchronized Class<?> findClass(final String binaryName) throws ClassNotFoundException {
        logger.debug("Downloading {0}...", binaryName);
        try {
            byte[] bytes = clientClusterViewManager.getBytecode(binaryName);
            return defineClass(binaryName, bytes, 0, bytes.length);
        } catch (ClientClusterViewManagerException e) {
            throw new ClassNotFoundException();
        }
    }

}
