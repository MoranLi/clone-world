/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007,2008 Bull S.A.S.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id:ClientClusterViewManager.java 914 2007-05-25 16:48:16Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.controller.client;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ejb.EJBHome;
import javax.ejb.EJBObject;

import net.jcip.annotations.ThreadSafe;

import org.ow2.cmi.admin.CMIMBeanConfigException;
import org.ow2.cmi.admin.MBeanUtils;
import org.ow2.cmi.config.CMIConfig;
import org.ow2.cmi.controller.common.AbsClusterViewManager;
import org.ow2.cmi.controller.common.CMIThreadFactory;
import org.ow2.cmi.controller.common.ClusterViewManager;
import org.ow2.cmi.controller.provider.ClientClusterViewProvider;
import org.ow2.cmi.controller.provider.ClusteredClientClusterViewProvider;
import org.ow2.cmi.info.CMIInfoExtractor;
import org.ow2.cmi.info.CMIInfoExtractorException;
import org.ow2.cmi.info.ClusteredObjectInfo;
import org.ow2.cmi.lb.data.PolicyData;
import org.ow2.cmi.lb.policy.IPolicy;
import org.ow2.cmi.lb.strategy.IStrategy;
import org.ow2.cmi.pool.StubOrProxyFactory;
import org.ow2.cmi.reference.CMIReference;
import org.ow2.cmi.reference.CMIReferenceable;
import org.ow2.cmi.reference.ObjectNotFoundException;
import org.ow2.cmi.reference.ServerRef;
import org.ow2.cmi.rpc.CMIProxy;
import org.ow2.cmi.rpc.POJOInvocationHandler;
import org.ow2.util.log.Log;
import org.ow2.util.log.LogFactory;
import org.ow2.util.pool.api.IPoolConfiguration;
import org.ow2.util.pool.api.Pool;
import org.ow2.util.pool.impl.JPool;


/**
 * Manager that contains CMI logic for the client-side.
 * @author The new CMI team
 */
@ThreadSafe
public final class ClientClusterViewManagerImpl extends AbsClusterViewManager implements ClientClusterViewManager {

    /**
     * Logger.
     */
    private static final Log LOGGER = LogFactory.getLog(ClientClusterViewManagerImpl.class);

    /**
     * The InitialContextFactory name for constructing instances of the protocol-relative context.
     */
    private final String initialContextFactoryName;

    /**
     * The protocol name.
     */
    private final String protocol;

    /**
     * A daemon in charge of updating the cluster view.
     */
    private final Thread clientClusterViewUpdater;

    /**
     * Current selected ClientClusterViewProvider.
     */
    private static volatile ClientClusterViewProvider clientClusterViewProvider;

    /**
     * True if the cluster view provider is available.
     */
    private volatile boolean clusterViewProviderAvailable = false;

    private final ClientClusterViewCache clientClusterViewCache = new ClientClusterViewCache();

    /**
     * Builds a new manager for the client-side.
     * @param initialContextFactoryName an name of InitialContextFactory
     * @param protocol The protocol name
     */
    private ClientClusterViewManagerImpl(final String initialContextFactoryName, final String protocol) {
        this.initialContextFactoryName = initialContextFactoryName;
        this.protocol = protocol;

        // Create the daemon in charge of updating the cluster view
        CMIThreadFactory cmiThreadFactory = getCmiThreadFactory();
        clientClusterViewUpdater = cmiThreadFactory.newThread(new Runnable() {
            public void run() {
                // Register this client (for statistics)
                try {
                    clientClusterViewProvider.registerClient(getUUID());
                } catch (Exception e) {
                    // No importance !
                    LOGGER.debug("Thread {0}> Cannot register the client", Thread.currentThread().getName(), e);
                }
                do {
                    int refreshTime;
                    try {
                        refreshTime = getDelayToRefresh();
                    } catch (Exception e) {
                        // No importance !
                        refreshTime = 10000;
                    }
                    // Start latter because the system object is already up-to-date
                    LOGGER.debug("Thread {0} is sleeping for {1} millis...", Thread.currentThread().getName(), refreshTime);
                    try {
                        Thread.sleep(refreshTime);
                    } catch (InterruptedException e) {
                        LOGGER.debug("Thread client interrupted", e);
                    }
                    LOGGER.debug("Thread {0}> Updating the client cluster view...", Thread.currentThread().getName());
                    try {
                        updateClusterView();
                        clusterViewProviderAvailable = true;
                    } catch (Exception e) {
                        LOGGER.error("Thread {0}> Cannot update the cluster view", Thread.currentThread().getName(), e);
                    }
                    // Now sleep...
                } while(true);
            }
        });

    }

    /**
     * Static method to get a singleton instance of ClientClusterViewManager.
     * @param initialContextFactoryName a name of class of InitialContextFactory
     * to use for constructing instances of the protocol-relative context
     * @param protocol a name of protocol
     * @param serverRefs a set of references on server
     * @return the instance (singleton) of ClientClusterViewManager
     * @throws ClientClusterViewManagerException if we cannot get an instance of ClientClusterViewManager.
     */
    public static synchronized ClientClusterViewManager getClientClusterViewManager(
            final String initialContextFactoryName, final String protocol, final List<ServerRef> serverRefs)
    throws ClientClusterViewManagerException {

        ClusterViewManager clusterViewManager = AbsClusterViewManager.getClusterViewManager();
        // If none instance of ClusterViewManager exists, we create one
        if(clusterViewManager == null) {
            LOGGER.debug("Constructing a ClientClusterviewManager...");
            ClientClusterViewManagerImpl clientClusterViewManager =
                new ClientClusterViewManagerImpl(initialContextFactoryName, protocol);

            // Initializes data of the provider of cluster view
            clientClusterViewManager.initDataOfProvider(serverRefs);

            // Initializes data of the dummy registry to enable a load-balancing of the JNDI accesses
            clientClusterViewManager.initDataOfDummyRegistry();

            // Start the daemon to update the cluster view
            clientClusterViewManager.clientClusterViewUpdater.start();

            if(CMIConfig.isEmbedded()) {
                // Initializes CMIMBean
                try {
                    MBeanUtils.initCMIMBean();
                } catch (CMIMBeanConfigException e) {
                    LOGGER.error("Cannot initializes CMIMBean", e);
                }
                // Registers CMIMBean
                try {
                    MBeanUtils.registerCMIMBean(clientClusterViewManager);
                } catch (CMIMBeanConfigException e) {
                    LOGGER.error("Cannot registers CMIMBean", e);
                }
            }

            clusterViewManager = clientClusterViewManager;
            AbsClusterViewManager.setClusterViewManager(clusterViewManager);
            LOGGER.info("The client-side manager was successfully started");
        } else {
            if(!(clusterViewManager instanceof ClientClusterViewManager)){
                 LOGGER.error("An instance of the manager that is not a ClientClusterViewManager already exists in the JVM");
                 throw new ClientClusterViewManagerException(
                         "An instance of the manager that is not a ClientClusterViewManager already exists in the JVM");
            }
        }
        return (ClientClusterViewManager) clusterViewManager;
    }

    /**
     * Creates a CMI proxy to enable invocations on the provider of cluster view.
     * @param serverRefs an initial set of the provider URLs for the provider of cluster view
     * @throws ClientClusterViewManagerException if a CMI proxy cannot be obtained for the provider of cluster view
     */
    private void initDataOfProvider(final List<ServerRef> serverRefs) throws ClientClusterViewManagerException {
        LOGGER.debug("**** Begin of initialization of the connection at provider...");
        String providerName = CMIConfig.getBindNameForProvider();

        // Initializes the list of provider URL for getting the cluster view
        List<CMIReference> cmiReferences = new ArrayList<CMIReference>();
        for(ServerRef serverRef : serverRefs) {
            cmiReferences.add(new CMIReference(serverRef, providerName));
        }
        clientClusterViewCache.setCMIReferences(providerName, cmiReferences);

        // Extracts the informations about provider
        ClusteredObjectInfo clusteredObjectInfo;
        try {
            clusteredObjectInfo = CMIInfoExtractor.extractClusteringInfoFromAnnotatedPOJO(providerName,
                    ClientClusterViewProvider.class, ClusteredClientClusterViewProvider.class, false, false, null);
        } catch (CMIInfoExtractorException e) {
            LOGGER.error("Cannot extract the informations about provider", e);
            throw new ClientClusterViewManagerException("Cannot extract the informations about provider", e);
        }

        // Initializes the cache
        clientClusterViewCache.setItfName(providerName, ClientClusterViewProvider.class);

        Class<? extends IPolicy<?>> policyClass = clusteredObjectInfo.getPolicyType();
        Class<? extends IStrategy<?>> strategyClass = clusteredObjectInfo.getStrategyType();

        String policyClassname = policyClass.getName();
        String strategyClassname = strategyClass.getName();

        PolicyData policyDataForProvider =
            new PolicyData(policyClassname, strategyClassname, clusteredObjectInfo.getProperties());
        clientClusterViewCache.setPolicyData(providerName, policyDataForProvider);
        clientClusterViewCache.setPolicyClass(policyClassname, policyClass);
        clientClusterViewCache.setStrategyClass(strategyClassname, strategyClass);

        watch(providerName);
        try {
            updatePolicy(providerName);
        } catch (ObjectNotFoundException e) {
            LOGGER.error("Cannot initialize informations of the provider", e);
            throw new ClientClusterViewManagerException("Cannot initialize informations of the provider", e);
        }

        Pool<CMIReferenceable<?>, CMIReference> pool =
            new JPool<CMIReferenceable<?>, CMIReference>(new StubOrProxyFactory(this));
        pool.setPoolConfiguration(clusteredObjectInfo.getPoolConfiguration());
        setPool(providerName, pool);

        // Keep the current classloader: it can be a smart classloader
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();

        // Gets a CMI proxy to enable load-balanced calls at provider
        InvocationHandler invocationHandler =
             new POJOInvocationHandler(
                    classLoader, this, providerName, protocol, ClientClusterViewProvider.class);
        clientClusterViewProvider =
            (ClientClusterViewProvider) Proxy.newProxyInstance(
                    classLoader, new Class[] {ClientClusterViewProvider.class, CMIProxy.class}, invocationHandler);
        try {
            pullAndupdateObjectInfos(providerName);
            clusterViewProviderAvailable = true;
        } catch (Exception e) {
            LOGGER.error("Provider not found", e);
        }
        LOGGER.debug("**** End of initialization of the connection at provider.");
    }

    /**
     * Registers the dummy registry as an object to watch.
     */
    private void initDataOfDummyRegistry() {
        String dummyName = CMIConfig.getBindNameForDummyRegistry();
        watch(dummyName);
        try {
            pullAndupdateObjectInfos(dummyName);
        } catch (Exception e) {
            LOGGER.error("Dummy registry not found", e);
        }
    }

    /**
     * Adds an object with the given name to a set of objects that need to have their state up-to-date.
     * @param objectName a name of object
     * @throws ObjectNotFoundException if none object has the given name
     * @throws ClientClusterViewManagerException if the name of interface of the object with the given name cannot be downloaded
     */
    @SuppressWarnings("unchecked")
    public synchronized void addObjectToWatch(final String objectName)
    throws ObjectNotFoundException, ClientClusterViewManagerException {
        if(!isWatched(objectName)) {
            LOGGER.debug("Initializing local data for object with name {0}", objectName);
            String itfName;
            try {
                itfName = clientClusterViewProvider.getItfName(objectName);
            } catch (RemoteException e) {
                LOGGER.error("Cannot pull the name of interface for object with name {0}", objectName, e);
                throw new ClientClusterViewManagerException(
                        "Cannot get pull the name of interface for object with name " + objectName, e);
            }
            ClassLoader currentCLoader = Thread.currentThread().getContextClassLoader();
            try {
                Class<?> itfClass = Class.forName(itfName, true, currentCLoader);
                clientClusterViewCache.setItfName(objectName, itfClass);
            } catch (ClassNotFoundException e) {
                throw new ClientClusterViewManagerException(
                        "Cannot load the interface for name " + itfName, e);
            }
            // Check if the object is an ejb2
            if(Arrays.asList(getInterface(objectName).getInterfaces()).contains(EJBHome.class)) {
                String businessName;
                try {
                    businessName = clientClusterViewProvider.getBusinessName(objectName);
                } catch (RemoteException e) {
                    LOGGER.error("Cannot pull the name of business interface for object with name {0}", objectName, e);
                    throw new ClientClusterViewManagerException(
                            "Cannot get pull the name of business interface for object with name " + objectName, e);
                }
                try {
                    Class<? extends EJBObject> businessClass =
                        (Class<? extends EJBObject>) Class.forName(businessName, true, currentCLoader);
                    clientClusterViewCache.setBusinessName(objectName, businessClass);
                } catch (ClassNotFoundException e) {
                    throw new ClientClusterViewManagerException(
                            "Cannot load the business interface for name " + businessName, e);
                }
            }

            boolean hasState;
            try {
                hasState = clientClusterViewProvider.hasState(objectName);
            } catch (RemoteException e) {
                LOGGER.error("Cannot know if the object with name {0} has a state", objectName, e);
                throw new ClientClusterViewManagerException(
                        "Cannot know if the object with name " + objectName+" has a state", e);
            }
            if(hasState) {
                clientClusterViewCache.setState(objectName);
                boolean replicated;
                try {
                    replicated = clientClusterViewProvider.isReplicated(objectName);
                } catch (RemoteException e) {
                    LOGGER.error("Cannot know if the object with name {0} has a state", objectName, e);
                    throw new ClientClusterViewManagerException(
                            "Cannot know if the object with name " + objectName+" has a state", e);
                }
                if(replicated) {
                    clientClusterViewCache.setReplicated(objectName);
                }
            }
            Set<String> applicationExceptionNames;
            try {
                applicationExceptionNames = clientClusterViewProvider.getApplicationExceptions(objectName);
            } catch (RemoteException e) {
                LOGGER.error("Cannot get the application exception names for the object with name {0}", objectName, e);
                throw new ClientClusterViewManagerException(
                        "Cannot get the application exception names for the object with name " + objectName, e);
            }
            clientClusterViewCache.setApplicationExceptionNames(objectName, applicationExceptionNames);
            watch(objectName);
            pullAndupdateObjectInfos(objectName);
        }
    }

    /**
     * Returns the interface of an object bound with the given name.
     * @param objectName a name of object
     * @return the interface of an object bound with the given name
     * @throws ObjectNotFoundException if none object has the given name
     * @throws ClientClusterViewManagerException if the class cannot be loaded
     */
    public Class<?> getInterface(final String objectName) throws ObjectNotFoundException, ClientClusterViewManagerException {
        Class<?> itfName = clientClusterViewCache.getItfName(objectName);
        if(itfName == null) {
            LOGGER.error("Object is unknown: {0}", objectName);
            throw new ObjectNotFoundException("Object is unknown: " + objectName);
        }
        return itfName;
    }

    /**
     * Returns the interface of an object bound with the given name.
     * @param objectName a name of object
     * @return the interface of an object bound with the given name
     * @throws ObjectNotFoundException if none object has the given name
     * @throws ClientClusterViewManagerException if the class cannot be loaded
     */
    public Class<? extends EJBObject> getRemoteClass(final String objectName)
    throws ObjectNotFoundException, ClientClusterViewManagerException {
        Class<? extends EJBObject> businessName = clientClusterViewCache.getBusinessName(objectName);
        if(businessName == null) {
            LOGGER.error("Object is unknown: {0}", objectName);
            throw new ObjectNotFoundException("Object is unknown: " + objectName);
        }
        return businessName;
    }

    /**
     * Returns the class that defines the policy for an object with the given name.
     * @param objectName a name of object
     * @return the class that defines the policy for an object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     * @throws ClientClusterViewManagerException if the class of policy of the object with the given name cannot be downloaded
     */
    public Class<? extends IPolicy<?>> getPolicyClass(final String objectName)
    throws ObjectNotFoundException, ClientClusterViewManagerException {
        String classname = getPolicyClassName(objectName);
        Class<? extends IPolicy<?>> policy = clientClusterViewCache.getPolicyClass(classname);
        if(policy == null) {
            try {
                policy = pullPolicyClass(objectName);
            } catch (RemoteException e) {
                LOGGER.error("Cannot set the class of policy for {0}", objectName, e);
                throw new ClientClusterViewManagerException("Cannot set the class of policy for " + objectName, e);
            }
            clientClusterViewCache.setPolicyClass(classname, policy);
        }
        return policy;
    }

    /**
     * Returns the class that defines the strategy for an object with the given name.
     * @param objectName a name of object
     * @return the class that defines the strategy for an object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     * @throws ClientClusterViewManagerException if the class of strategy of the object with the given name cannot be downloaded
     */
    public Class<? extends IStrategy<?>> getStrategyClass(final String objectName)
    throws ObjectNotFoundException, ClientClusterViewManagerException {
        String classname = getStrategyClassName(objectName);
        Class<? extends IStrategy<?>> strategy = clientClusterViewCache.getStrategyClass(classname);
        if(strategy == null) {
            try {
                strategy = pullStrategyClass(objectName);
            } catch (RemoteException e) {
                LOGGER.error("Cannot set the class of strategy for {0}", objectName, e);
                throw new ClientClusterViewManagerException("Cannot set the class of strategy for " + objectName, e);
            }
            clientClusterViewCache.setStrategyClass(classname, strategy);
        }
        return strategy;
    }

    /**
     * Returns a list of CMIReference for an object with the given name and protocol.
     * @param objectName a name of object
     * @param protocolName a name of protocol
     * @return a list of CMIReference for an object with the given name and protocol
     * @throws ObjectNotFoundException if none object has the given name for the given protocol
     */
    public List<CMIReference> getCMIReferences(final String objectName, final String protocolName)
    throws ObjectNotFoundException {
        List<CMIReference> cmiReferences = clientClusterViewCache.getCMIReferences(objectName);
        if(cmiReferences == null) {
            LOGGER.debug("Object is unknown: {0}", objectName);
            throw new ObjectNotFoundException("Object is unknown: " + objectName);
        }
        return cmiReferences;
    }

    /**
     * Returns the date of properties for an object with the given name.
     * @param objectName a name of object
     * @return the date of properties for an object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public long getDateOfProperties(final String objectName) throws ObjectNotFoundException {
        PolicyData lbPolicyData = clientClusterViewCache.getPolicyData(objectName);
        if(lbPolicyData == null) {
            LOGGER.error("Object is unknown: {0}", objectName);
            throw new ObjectNotFoundException("Object is unknown: " + objectName);
        }
        return lbPolicyData.getDateOfProperties();
    }

    /************* Start of methods to pull the cluster view: *****************/

    /**
     * Pulls the Load Balance policy class.
     * @param objectName a name of object
     * @return A Load Balance policy class
     * @throws ObjectNotFoundException if none object has the given name
     * @throws RemoteException if the class of policy of the object with the given name cannot be downloaded
     */
    private Class<? extends IPolicy<?>> pullPolicyClass(final String objectName)
    throws ObjectNotFoundException, RemoteException {
        // Set classloader to download class of policy
        ClassLoader oldClassLoader = Thread.currentThread().getContextClassLoader();
        Thread.currentThread().setContextClassLoader(new CMIClientClassLoader(oldClassLoader, this));
        Class<? extends IPolicy<?>> policyClass;
        try {
            policyClass = clientClusterViewProvider.getPolicyClass(objectName);
        } catch(ClassNotFoundException e) {
            LOGGER.error("Cannot download the policy class for {0}", objectName, e);
            throw new ClientClusterViewManagerException(
                    "Cannot download the policy class for " + objectName, e);
        } finally {
            Thread.currentThread().setContextClassLoader(oldClassLoader);
        }
        return policyClass;
    }

    /**
     * Pulls the Load Balance strategy class.
     * @param objectName a name of object
     * @return A Load Balance strategy class
     * @throws ObjectNotFoundException if none object has the given name
     * @throws RemoteException if the class of strategy of the object with the given name cannot be downloaded
     */
    private Class<? extends IStrategy<?>> pullStrategyClass(final String objectName)
    throws RemoteException, ObjectNotFoundException {
        // Set classloader to download class of strategy
        ClassLoader oldClassLoader = Thread.currentThread().getContextClassLoader();
        Thread.currentThread().setContextClassLoader(new CMIClientClassLoader(oldClassLoader, this));
        Class<? extends IStrategy<?>> strategyClass;
        try {
            strategyClass = clientClusterViewProvider.getStrategyClass(objectName);
        } catch(ClassNotFoundException e) {
            LOGGER.error("Cannot download the strategy class for {0}", objectName, e);
            throw new ClientClusterViewManagerException(
                    "Cannot download the strategy class for " + objectName, e);
        } finally {
            Thread.currentThread().setContextClassLoader(oldClassLoader);
        }
        return strategyClass;
    }

    /**
     * Returns true if the pool for object with the given name should be empty.
     * @param objectName a name of object
     * @return true if the pool for object with the given name should be empty
     * @throws ObjectNotFoundException if no object is bound with the given name
     * @throws ClientClusterViewManagerException if the flag to empty pool for the object with the given name cannot be downloaded
     */
    public boolean isPoolToEmpty(final String objectName) throws ObjectNotFoundException, ClientClusterViewManagerException {
        try {
            return clientClusterViewProvider.isPoolToEmpty(objectName);
        } catch (RemoteException e) {
            LOGGER.error("Cannot pull the flag to reset or no the pool for object {0}", objectName, e);
            throw new ClientClusterViewManagerException(
                    "Cannot pull the flag to reset or no the pool for object " + objectName, e);
        }
    }

    /************* End of methods to pull the cluster view *****************/

    /**
     * Returns the properties of the LB policy for an object with the given name.
     * @param objectName a name of object
     * @return the properties of the policy for an object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public Map<String, Object> getPropertiesForPolicy(final String objectName) throws ObjectNotFoundException {
        PolicyData policyData = clientClusterViewCache.getPolicyData(objectName);
        if(policyData == null) {
            LOGGER.error("Object is unknown: {0}", objectName);
            throw new ObjectNotFoundException("Object is unknown: " + objectName);
        }
        return policyData.getProperties();
    }

    /**
     * Returns a value property of the policy for an object with the given name.
     * @param objectName a name of object
     * @param propertyName a name of property
     * @return a value property of the policy for an object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public Object getPropertyForPolicy(final String objectName, final String propertyName)
    throws ObjectNotFoundException {
        PolicyData policyData = clientClusterViewCache.getPolicyData(objectName);
        if(policyData == null) {
            LOGGER.error("Object is unknown: {0}", objectName);
            throw new ObjectNotFoundException("Object is unknown: " + objectName);
        }
        return policyData.getProperties().get(propertyName);
    }

    /**
     * Returns a name of class that implements the interface InitialContextFactory for the given name of protocol.
     * @param protocolName a name of protocol
     * @return a name of class that implements the interface InitialContextFactory for the given name of protocol
     */
    public String getInitialContextFactoryName(final String protocolName) {
        return initialContextFactoryName;
    }

    /**
     * Returns the protocol used by this manager.
     * @return the protocol used by this manager
     */
    public Set<String> getProtocols() {
        return Collections.singleton(protocol);
    }

    /**
     * Returns the bytecode of the class with the given binary name.
     * @param binaryName a binary name of a class
     * @return the bytecode of the class with the given binary name
     * @throws ClientClusterViewManagerException if the bytecode cannot obtained
     */
    public byte[] getBytecode(final String binaryName) throws ClientClusterViewManagerException {
        try {
            return clientClusterViewProvider.getBytecode(binaryName);
        } catch(Exception e) {
            LOGGER.error("Cannot get bytecode for {0}", binaryName, e);
            throw new ClientClusterViewManagerException("Cannot get bytecode for " + binaryName, e);
        }
    }

    /**
     * Returns true if the object with the specified name is clustered.
     * @param objectName a name of object
     * @return true if the object with the specified name is clustered
     * @throws ClientClusterViewManagerException if the flag to indicate if the object, with the given name,
     * is clustered cannot be downloaded
     */
    public boolean isClustered(final String objectName) throws ClientClusterViewManagerException {
        try {
            return clientClusterViewProvider.isClustered(objectName);
        } catch (RemoteException e) {
            LOGGER.error("Connection has failed", e);
            throw new ClientClusterViewManagerException("Connection has failed", e);
        }
    }

    /**
     * Returns the time between each update of the cluster view by clients.
     * @return the time between each update of the cluster view by clients
     * @throws ClientClusterViewManagerException if the delay between each update of the cluster view cannot be downloaded
     */
    public int getDelayToRefresh() throws ClientClusterViewManagerException {
        try {
            return clientClusterViewProvider.getDelayToRefresh();
        } catch (RemoteException e) {
            LOGGER.error("Cannot get delay to refresh", e);
            throw new ClientClusterViewManagerException("Cannot get delay to refresh", e);
        }
    }

    /**
     * Returns the name of class of policy for the object with the given name.
     * @param objectName a name of object
     * @return the name of class of policy for the object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public String getPolicyClassName(final String objectName) throws ObjectNotFoundException {
        PolicyData policyData = clientClusterViewCache.getPolicyData(objectName);
        if(policyData == null) {
            LOGGER.error("Object is unknown: {0}", objectName);
            throw new ObjectNotFoundException("Object is unknown: " + objectName);
        }
        return policyData.getPolicyType();
    }

    /**
     * Returns the name of class of strategy for the object with the given name.
     * @param objectName a name of object
     * @return the name of class of strategy for the object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public String getStrategyClassName(final String objectName) throws ObjectNotFoundException {
        PolicyData policyData = clientClusterViewCache.getPolicyData(objectName);
        if(policyData == null) {
            LOGGER.error("Object is unknown: {0}", objectName);
            throw new ObjectNotFoundException("Object is unknown: " + objectName);
        }
        return policyData.getStrategyType();
    }

    /**
     * Returns the name of cluster for the object with the given name.
     * @param objectName a name of object
     * @return the name of cluster for a object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     * @throws ClientClusterViewManagerException if the name of the cluster, that contains the object with the given name,
     * cannot be downloaded
     */
    public String getClusterName(final String objectName)
    throws ObjectNotFoundException, ClientClusterViewManagerException {
        try {
            return clientClusterViewProvider.getClusterName(objectName);
        } catch (RemoteException e) {
            LOGGER.error("Cannot get name of cluster for object with name {0}", objectName, e);
            throw new ClientClusterViewManagerException(
                    "Cannot get name of cluster for object with name " + objectName, e);
        }
    }

    /**
     * Updates informations about clustering for the object with the given name.
     * @param objectName a name of object
     * @throws ObjectNotFoundException if none object has the given name
     * @throws ClientClusterViewManagerException if the update failed
     */
    public void pullAndupdateObjectInfos(final String objectName)
    throws ObjectNotFoundException, ClientClusterViewManagerException {
        LOGGER.debug("Updating infos for: {0} - thread is {1}", objectName, Thread.currentThread().getName());
        try {
            pullAndUpdatePolicy(objectName);
            pullAndUpdateCMIReferences(objectName);
            if(hasPool(objectName)) {
                pullAndUpdatePoolConfiguration(objectName);
            }
        } catch (Exception e) {
            LOGGER.error("Cannot pull the informations for object with name {0}", objectName, e);
            throw new ClientClusterViewManagerException("Cannot pull the informations for object with name "+objectName, e);
        }
    }

    /**
     * Updates informations about clustering for every watched objects.
     * @throws ClientClusterViewManagerException if the update failed
     */
    public void updateClusterView() throws ClientClusterViewManagerException {
        // Update list of node for each clustered RMI object
        for(String objectName : getNamesOfWatchedObject()) {
            try {
                pullAndupdateObjectInfos(objectName);
            } catch (ObjectNotFoundException e) {
                LOGGER.fatal("The object with name {0} is unknown", objectName, e);
                throw new ClientClusterViewManagerException(
                        "The object with name " + objectName + " is unknown", e);
            }
        }
        pullAndUpdateLoadFactors();
    }

    /**
     * Pulls and updates the policy for the object with the given name.
     * @param objectName a name of object
     * @throws ObjectNotFoundException if none object has the given name
     * @throws ClientClusterViewManagerException if some informations miss or the new policy cannot be constructed
     * @throws RemoteException if the information about policy cannot be downloaded
     */
    private void pullAndUpdatePolicy(final String objectName)
    throws ObjectNotFoundException, ClientClusterViewManagerException, RemoteException {

        // Pulls the name of class for policy
        String lastPolicyName = clientClusterViewProvider.getPolicyClassName(objectName);
        if(lastPolicyName == null) {
            LOGGER.error("The new name of policy is null.");
            throw new ClientClusterViewManagerException("The new name of policy is null.");
        }
        LOGGER.debug("New policy name: {0}", lastPolicyName);

        // Pulls the name of class for strategy
        String lastStrategyName = clientClusterViewProvider.getStrategyClassName(objectName);
        if(lastStrategyName == null) {
            LOGGER.error("The new name of strategy is null.");
            throw new ClientClusterViewManagerException("The new name of strategy is null.");
        }
        LOGGER.debug("New strategy name: {0}", lastStrategyName);

        // Pulls the date of properties
        long dateOfLastProps = clientClusterViewProvider.getDateOfProperties(objectName);
        LOGGER.debug("New date of properties: {0}", dateOfLastProps);

        // Compares with the current data
        if(clientClusterViewCache.getPolicyData(objectName) != null) {
            // Cache contains some data
            String policyName = getPolicyClassName(objectName);
            LOGGER.debug("Old policy name: {0}", policyName);
            long dateOfProps = getDateOfProperties(objectName);
            LOGGER.debug("Old date of properties: {0}", dateOfProps);
            String strategyName = getStrategyClassName(objectName);
            LOGGER.debug("Old strategy name: {0}", strategyName);
            if(policyName.equals(lastPolicyName)
                    && dateOfProps == dateOfLastProps
                    && strategyName.equals(lastStrategyName)) {
                return;
            }
        }
        Map<String, Object> lastProperties;

        if(dateOfLastProps == 0) {
            // No property
            lastProperties = new HashMap<String, Object>();
        } else {
            lastProperties = clientClusterViewProvider.getPropertiesForPolicy(objectName);
        }
        clientClusterViewCache.setPolicyData(objectName, new PolicyData(
                lastPolicyName, lastStrategyName, lastProperties, dateOfLastProps));
        try {
            updatePolicy(objectName);
        } catch (ObjectNotFoundException e) {
            LOGGER.error("Cannot get policy for object {0}", objectName, e);
            throw new ClientClusterViewManagerException("Cannot get policy for object " + objectName, e);
        }
    }

    /**
     * Pulls and updates the CMI references for the object with the given name.
     * @param objectName a name of object
     * @throws ObjectNotFoundException if none object has the given name
     * @throws ClientClusterViewManagerException if the downloaded list is null
     * @throws RemoteException if the list cannot be downloaded
     */
    private void pullAndUpdateCMIReferences(final String objectName)
    throws ObjectNotFoundException, ClientClusterViewManagerException, RemoteException {

        //Update the list of nodes for this RMI object
        List<CMIReference> cmiReferences = clientClusterViewProvider.getCMIReferences(objectName, protocol);
        if(cmiReferences == null) {
            LOGGER.error("The new node list for {0} is null", objectName);
            throw new ClientClusterViewManagerException("The new node list for " + objectName+" is null");
        }

        // Update the load-factor of each server
        for(CMIReference cmiRef : cmiReferences) {
            pullAndUpdateMissingLoadFactor(cmiRef.getServerRef());
        }

        clientClusterViewCache.setCMIReferences(objectName, cmiReferences);
    }

    /**
     * Pulls and updates the configuration of the pool for the object with the given name.
     * @param objectName a name of object
     * @throws ObjectNotFoundException if none object has the given name
     */
    private void pullAndUpdatePoolConfiguration(final String objectName) throws ObjectNotFoundException {
        getPool(objectName).setPoolConfiguration(getPoolConfiguration(objectName));
    }

    private void pullAndUpdateMissingLoadFactor(final ServerRef serverRef) {
        try {
            clientClusterViewCache.getLoadFactor(serverRef);
        } catch(NullPointerException npe) {
            int loadFactor;
            try {
                loadFactor = clientClusterViewProvider.getLoadFactor(serverRef);
                clientClusterViewCache.setLoadFactor(serverRef, loadFactor);
            } catch (Exception e) {
                LOGGER.error("Cannot pull the load factor for server with address {0}", serverRef, e);
                throw new ClientClusterViewManagerException(
                        "Cannot pull the load factor for server with address " + serverRef, e);
            }
        }
    }

    /**
     * Pulls and updates the load-factors of the server known by this client.
     */
    private void pullAndUpdateLoadFactors() {
        for(ServerRef address : clientClusterViewCache.getAddressesOfServer()) {
            int loadFactor;
            try {
                loadFactor = clientClusterViewProvider.getLoadFactor(address);
                clientClusterViewCache.setLoadFactor(address, loadFactor);
            } catch (Exception e) {
                LOGGER.error("Cannot pull the load factor for server with address {0}", address, e);
                throw new ClientClusterViewManagerException(
                        "Cannot pull the load factor for server with address " + address, e);
            }
        }
    }

    /**
     * Returns the configuration of pool of CMIReferenceable for a object with the given name.
     * @param objectName a name of object
     * @return the configuration of pool of CMIReferenceable for a object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public IPoolConfiguration getPoolConfiguration(final String objectName) throws ObjectNotFoundException {
        try {
            return clientClusterViewProvider.getPoolConfiguration(objectName);
        } catch (RemoteException e) {
            LOGGER.error("Cannot get the configuration of pool for object with name {0}", objectName, e);
            throw new ClientClusterViewManagerException(
                    "Cannot get the configuration of pool for object with name " + objectName, e);
        }
    }

    /**
     * Returns the load-factor for the server with the given address.
     * @param serverRef a reference on a server
     * @return the load-factor for the server with the given address
     */
    public int getLoadFactor(final ServerRef serverRef) {
        return clientClusterViewCache.getLoadFactor(serverRef);
    }

    /**
     * Return true if the object with the given name is stateful.
     * @param objectName a name of object
     * @return true if the object with the given name is stateful
     * @throws ObjectNotFoundException if none object has the given name
     */
    public boolean hasState(final String objectName) throws ObjectNotFoundException {
        return clientClusterViewCache.hasState(objectName);
    }

    /**
     * Return true if the object with the given name is replicated for high-availability.
     * @param objectName a name of object
     * @return true if the object with the given name is replicated for high-availability
     * @throws ObjectNotFoundException if none object has the given name
     */
    public boolean isReplicated(final String objectName)
    throws ObjectNotFoundException {
        return clientClusterViewCache.isReplicated(objectName);
    }

    /**
     * Return classnames of the application exceptions.
     * @param objectName a name of object
     * @return classnames of the application exceptions
     * @throws ObjectNotFoundException if none object has the given name
     */
    public Set<String> getApplicationExceptionNames(final String objectName) throws ObjectNotFoundException{
        return clientClusterViewCache.getApplicationExceptionNames(objectName);
    }


    /**
     * @return the set of clustered object names
     */
    public Set<String> getObjectNames() {
        return clientClusterViewCache.getObjectNames();
    }

    /**
     * @return true if the cluster view provider is available
     */
    public boolean isClusterViewProviderAvailable() {
        return clusterViewProviderAvailable;
    }

}
