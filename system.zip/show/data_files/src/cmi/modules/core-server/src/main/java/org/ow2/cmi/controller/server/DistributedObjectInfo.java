/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007,2008 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id: DistributedObjectInfo.java 1664 2008-03-09 12:18:41Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.controller.server;

import java.io.Serializable;
import java.util.Set;

import net.jcip.annotations.ThreadSafe;

import org.ow2.cmi.lb.data.PolicyData;
import org.ow2.util.pool.api.IPoolConfiguration;

/**
 * Represents the replicated data for a clustered object.
 * @author The new CMI team
 */
@ThreadSafe
public class DistributedObjectInfo implements Serializable, Cloneable {

    /**
     * Id for serializable class.
     */
    private static final long serialVersionUID = 7128398689206804315L;

    /**
     * Name of the interface that the object implements.
     */
    private final String clusterName;

    /**
     * Name of the distributed object.
     */
    private final String objectName;

    /**
     * Name of the interface that the object implements.
     */
    private final String itfName;

    /**
     * Name of the business interface that the object implements.
     */
    private final String businessName;

    /**
     * Data of the policy.
     */
    private volatile PolicyData policyData;

    /**
     * True if this object has a state.
     */
    private final boolean stateful;

    /**
     * True if this object has a state replicated.
     */
    private final boolean replicated;

    /**
     * Classnames of the application exceptions.
     */
    private final Set<String> applicationExceptionNames;

    /**
     * Configuration of the pool.
     */
    private volatile IPoolConfiguration poolConfiguration;

    /**
     * Constructs informations for a clustered object with the default strategy for the given LB policy.
     * @param clusterName a name of the interface that the object implements
     * @param objectName a name of object
     * @param itfName a name of the interface that the object implements
     * @param businessName a name of the business interface that the object implements
     * @param policyData data of the LB policy
     * @param stateful true if this object has a state
     * @param replicated true if this object has a state replicated
     * @param applicationExceptionNames classnames of the application exceptions
     * @param poolConfiguration configuration of the pool
     */
    public DistributedObjectInfo(
            final String clusterName,
            final String objectName,
            final String itfName,
            final String businessName,
            final PolicyData policyData,
            final boolean stateful,
            final boolean replicated,
            final Set<String> applicationExceptionNames,
            final IPoolConfiguration poolConfiguration) {
        this.clusterName = clusterName;
        this.objectName = objectName;
        this.itfName = itfName;
        this.businessName = businessName;
        this.policyData = policyData;
        this.stateful = stateful;
        this.replicated = replicated;
        this.applicationExceptionNames = applicationExceptionNames;
        this.poolConfiguration = poolConfiguration;
    }

    /**
     * @return a name of the interface that the object implements
     */
    public String getClusterName() {
        return clusterName;
    }

    /**
     * @return Name of the interface that the object implements.
     */
    public String getItfName() {
        return itfName;
    }

    /**
     * @return the businessName
     */
    public String getBusinessName() {
        return businessName;
    }

    /**
     * @param policyData data of the associated policy
     */
    public void setPolicyData(final PolicyData policyData) {
        this.policyData = policyData;
    }

    /**
     * @return data of the associated policy
     */
    public PolicyData getPolicyData() {
        return policyData;
    }

    /**
     * @return the objectName
     */
    public String getObjectName() {
        return objectName;
    }

    /**
     * Return true if this object has a state.
     * @return true if this object has a state
     */
    public boolean hasState() {
        return stateful;
    }

    /**
     * @return true if this object has a state replicated
     */
    public boolean isReplicated() {
        return replicated;
    }

    /**
     * @return classnames of the application exceptions
     */
    public Set<String> getApplicationExceptionNames() {
        return applicationExceptionNames;
    }

    /**
     * @return configuration of the pool
     */
    public IPoolConfiguration getPoolConfiguration() {
        return poolConfiguration;
    }

    /**
     * Set the configuration for the pool of CMIReferenceable.
     * @param poolConfiguration the configuration for the pool of CMIReferenceable
     */
    public void setPoolConfiguration(final IPoolConfiguration poolConfiguration) {
        this.poolConfiguration = poolConfiguration;
    }

    @Override
    public boolean equals(final Object object) {
        if(object == null && !(object instanceof DistributedObjectInfo)) {
            return false;
        }
        DistributedObjectInfo distributedObjectInfo = (DistributedObjectInfo) object;
        return (clusterName == null ?
                    distributedObjectInfo.clusterName == null :
                        clusterName.equals(distributedObjectInfo.clusterName))
            && (objectName == null ?
                    distributedObjectInfo.objectName == null :
                        objectName.equals(distributedObjectInfo.objectName))
            && (itfName == null ?
                    distributedObjectInfo.itfName == null :
                        itfName.equals(distributedObjectInfo.itfName))
            && (businessName == null ?
                    distributedObjectInfo.businessName == null :
                        businessName.equals(distributedObjectInfo.businessName))
            && (policyData == null ?
                    distributedObjectInfo.policyData == null :
                        policyData.equals(distributedObjectInfo.policyData))
            && stateful == distributedObjectInfo.stateful
            && replicated == distributedObjectInfo.replicated
            && (applicationExceptionNames == null ?
                    distributedObjectInfo.applicationExceptionNames == null :
                        applicationExceptionNames.equals(distributedObjectInfo.applicationExceptionNames))
            && (poolConfiguration == null ?
                    distributedObjectInfo.poolConfiguration == null :
                        poolConfiguration.equals(distributedObjectInfo.poolConfiguration));
    }

    @Override
    public int hashCode() {
        return (itfName == null ? 0 : itfName.hashCode())
        + (businessName == null ? 0 : businessName.hashCode())
        + (clusterName == null ?0 : clusterName.hashCode())
        + (objectName == null ? 0 : objectName.hashCode())
        + (poolConfiguration == null ? 0 : poolConfiguration.hashCode())
        + (policyData == null ? 0 : policyData.hashCode())
        + (stateful ? 1 : 0)
        + (replicated ? 1 : 0)
        + (applicationExceptionNames == null ? 0 : applicationExceptionNames.hashCode());
    }

    @Override
    public String toString() {
        return "[clusterName=" + clusterName
            + ",objectName=" + objectName
            + ",itfName=" + itfName
            + ",businessName=" + businessName
            + ",lbPolicyData=" + policyData
            + ",stateful=" + stateful
            + ",replicated=" + replicated
            + ",applicationExceptionNames=" + applicationExceptionNames
            + ",poolConfiguration=" + poolConfiguration
            + "]";
    }

    @Override
    public DistributedObjectInfo clone() throws CloneNotSupportedException {
        DistributedObjectInfo distributedObjectInfo =
            (DistributedObjectInfo) super.clone();
        distributedObjectInfo.policyData = policyData.clone();
        return distributedObjectInfo;
    }

}
