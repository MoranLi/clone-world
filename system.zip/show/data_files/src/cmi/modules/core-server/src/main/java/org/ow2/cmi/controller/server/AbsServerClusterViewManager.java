/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007,2008 Bull S.A.S.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: AbsServerClusterViewManager.java 1695 2008-03-20 13:27:55Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.controller.server;

import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.rmi.NoSuchObjectException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import javax.ejb.EJBObject;
import javax.management.remote.JMXServiceURL;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import net.jcip.annotations.ThreadSafe;

import org.ow2.cmi.admin.CMIAdminConnectorManager;
import org.ow2.cmi.admin.CMIMBeanConfigException;
import org.ow2.cmi.admin.MBeanUtils;
import org.ow2.cmi.config.CMIConfig;
import org.ow2.cmi.controller.common.AbsClusterViewManager;
import org.ow2.cmi.controller.common.ClusterViewManager;
import org.ow2.cmi.controller.provider.ClientClusterViewProvider;
import org.ow2.cmi.controller.provider.ClusteredClientClusterViewProvider;
import org.ow2.cmi.info.CMIInfoExtractor;
import org.ow2.cmi.info.CMIInfoExtractorException;
import org.ow2.cmi.info.CMIInfoRepository;
import org.ow2.cmi.info.ClusteredObjectInfo;
import org.ow2.cmi.lb.data.PolicyData;
import org.ow2.cmi.lb.policy.FirstAvailable;
import org.ow2.cmi.lb.policy.HASingleton;
import org.ow2.cmi.lb.policy.IPolicy;
import org.ow2.cmi.lb.policy.Random;
import org.ow2.cmi.lb.policy.RoundRobin;
import org.ow2.cmi.lb.strategy.IStrategy;
import org.ow2.cmi.lb.strategy.LoadFactorComparator;
import org.ow2.cmi.lb.strategy.LoadFactorSort;
import org.ow2.cmi.lb.strategy.LocalPreference;
import org.ow2.cmi.lb.strategy.NoStrategy;
import org.ow2.cmi.lb.util.PolicyFactory;
import org.ow2.cmi.reference.CMIReference;
import org.ow2.cmi.reference.ObjectNotFoundException;
import org.ow2.cmi.reference.ServerRef;
import org.ow2.util.log.Log;
import org.ow2.util.log.LogFactory;
import org.ow2.util.pool.api.IPoolConfiguration;

/**
 * Common implementation for all manager of the cluster view at server-side.
 * @author The new CMI team
 */
@ThreadSafe
public abstract class AbsServerClusterViewManager extends AbsClusterViewManager
implements ServerClusterViewManager {

    /**
     * Logger.
     */
    private static final Log LOGGER = LogFactory.getLog(AbsServerClusterViewManager.class);

    /**
     * Map names of protocol and InitialContextFactories in purpose to perform lookups.
     */
    private final Map<String, String> initialContextFactories =
        new ConcurrentHashMap<String, String>();

    /**
     * References on the local registry for each protocol.
     */
    private final Map<String, ServerRef> refsOnLocalRegistries =
        new ConcurrentHashMap<String, ServerRef>();

    /**
     * References on the cluster view provider for each protocol.
     */
    private final Map<String, Remote> clientClusterViewProviders =
        new ConcurrentHashMap<String, Remote>();

    /**
     * References on the context for each protocol to perform bindings or unbindings.
     */
    private final Map<String, Context> contexts = new ConcurrentHashMap<String, Context>();

    /**
     * Address of the local registry.
     */
    private InetAddress inetAddress = null;

    /**
     * Informations to replicate the dummy registry.
     */
    private ClusteredObjectInfo clusteredObjectInfoForDummyRegistry;

    /**
     * True if the replication manager is started.
     */
    private boolean replicationManagerStarted = false;

    /**
     * True if the server-side manager is started.
     */
    private static boolean started = false;

    /**
     * Store each interfaces.
     */
    private final ConcurrentHashMap<String, Class<?>> interfaces = new ConcurrentHashMap<String, Class<?>>();

    /**
     * Store each class of Policy.
     */
    @SuppressWarnings("unchecked")
    private final ConcurrentHashMap<String, Class<? extends IPolicy>> policyMap  =
        new ConcurrentHashMap<String, Class<? extends IPolicy>>();

    /**
     * Store each class of Strategy.
     */
    @SuppressWarnings("unchecked")
    private final ConcurrentHashMap<String, Class<? extends IStrategy>> strategyMap =
        new ConcurrentHashMap<String, Class<?extends IStrategy>>();

    /**
     * Embedded Policy classes.
     */
    private final Class<?>[] embeddedPolicyClasses =
        {FirstAvailable.class, HASingleton.class, Random.class, RoundRobin.class};

    /**
     * Embedded Strategy classes.
     */
    private final Class<?>[] embeddedStrategyClasses =
        {NoStrategy.class, LoadFactorSort.class, LoadFactorComparator.class, LocalPreference.class};

    /**
     * Start the server-side manager.
     */
    public static synchronized void start() {
        if(!started && AbsClusterViewManager.getClusterViewManager() != null) {
            LOGGER.warn("CMI has been already started with the creation of a new initial context.");
            started = true;
        } else if(!started) {
            ((AbsServerClusterViewManager) getServerClusterViewManager()).doStart();
            started = true;
        }
    }

    /**
     * Stop the server-side manager.
     */
    public static synchronized void stop() {
        if(started) {
            AbsServerClusterViewManager serverClusterViewManager =   (AbsServerClusterViewManager) getServerClusterViewManager();
            // Unregister the CMI MBean
            try {
                MBeanUtils.unregisterCMIMBean();
            } catch (CMIMBeanConfigException e) {
                LOGGER.error("Cannot unregister CMIMBean", e);
            }
            // Unbind and unexport cmi objects
            for(String protocol : serverClusterViewManager.initialContextFactories.keySet()) {
                try {
                    serverClusterViewManager.contexts.get(protocol).unbind(CMIConfig.getBindNameForProvider());
                } catch (NamingException e) {
                    LOGGER.error("Cannot unbind the instance of ClientClusterViewProvider for the protocol {0}",
                            protocol, e);
                }
                // Unexport the connector for only this protocol
                // So disable the MultiPRODelegate provided by Carol
                System.setProperty("carol.multipro.protocol", protocol);
                try {
                    PortableRemoteObject.unexportObject(serverClusterViewManager.clientClusterViewProviders.get(protocol));
                } catch (NoSuchObjectException e) {
                    LOGGER.error("Cannot unexport the instance of ClientClusterViewProvider for the protocol {0}",
                            protocol, e);
                } finally {
                    System.setProperty("carol.multipro.protocol", "any");
                }
            }
            serverClusterViewManager.doStop();
            AbsClusterViewManager.setClusterViewManager(null);
            started = false;
            LOGGER.info("The server-side manager is now stopped.");
        }
    }

    /**
     * Start the server-side manager.
     * This method is overridden by the implementation of the server.
     */
    public abstract void doStart();

    /**
     * Stop the server-side manager.
     * This method is overridden by the implementation of the server.
     */
    public abstract void doStop();

    /**
     * @return a ServerClusterViewManager instance.
     * @throws ServerClusterViewManagerException if we cannot get a ServerClusterViewManager instance.
     */
    public static final synchronized ServerClusterViewManager getServerClusterViewManager()
    throws ServerClusterViewManagerException {

        // Checks if an instance already exists
        ClusterViewManager clusterViewManager = AbsClusterViewManager.getClusterViewManager();
        if (clusterViewManager == null) {

            // Initializes CMIMBean
            try {
                MBeanUtils.initCMIMBean();
            } catch (CMIMBeanConfigException e) {
                LOGGER.error("Cannot initializes CMIMBean", e);
            }

            // Loads the implementation of ServerClusterViewManager via CMIConfig
            Class<? extends ServerClusterViewManager> serverClusterViewManagerClass =
                CMIConfig.getServerClusterViewManagerClass();
            LOGGER.debug("The ServerClusterViewManager is: {0}", serverClusterViewManagerClass.getName());

            AbsServerClusterViewManager serverClusterViewManager;
            try {
                // Gets the factory to construct an instance of ServerClusterViewManager
                Method factory = serverClusterViewManagerClass.getDeclaredMethod("getJGroupsClusterViewManager");
                if(!factory.isAccessible()) {
                    factory.setAccessible(true);
                }
                serverClusterViewManager = (AbsServerClusterViewManager) factory.invoke(null);
            } catch (Exception e) {
                LOGGER.error("Cannot create the instance (singleton) of ServerClusterViewManager", e);
                throw new ServerClusterViewManagerException(
                        "Cannot get an instance of ServerClusterViewManager", e);
            }

            LOGGER.debug("ServerClusterViewManager has been created");

            serverClusterViewManager.loadEmbeddedLBClasses();

            // Extracts informations on clustering of dummy context
            try {
                serverClusterViewManager.clusteredObjectInfoForDummyRegistry =
                    CMIInfoExtractor.extractClusteringInfoFromAnnotatedPOJO(
                            CMIConfig.getBindNameForDummyRegistry(), null,
                            ClusteredDummyRegistry.class, false, false, null);
            } catch (CMIInfoExtractorException e) {
                LOGGER.error("Cannot get infos for dummy context", e);
                throw new ServerClusterViewManagerException("Cannot get infos for dummy context", e);
            }

            // Shares delay to refresh
            serverClusterViewManager.setDelayToRefresh(CMIConfig.getRefreshTime());

            // Registers CMIMBean
            try {
                MBeanUtils.registerCMIMBean(serverClusterViewManager);
            } catch (CMIMBeanConfigException e) {
                LOGGER.error("Cannot register CMIMBean", e);
            }

            serverClusterViewManager.initStats();

            clusterViewManager = serverClusterViewManager;
            AbsClusterViewManager.setClusterViewManager(clusterViewManager);

            LOGGER.info("The server-side manager was successfully started");
        } else {
            if(!(clusterViewManager instanceof ServerClusterViewManager)){
                LOGGER.error("An instance of the manager that is not a ServerClusterViewManager already exists in the JVM");
                throw new ServerClusterViewManagerException(
                "An instance of the manager that is not a ServerClusterViewManager already exists in the JVM");
            }
        }
        return (ServerClusterViewManager) clusterViewManager;
    }

    /**
     * Adds a new protocol. This method also binds a provider of the cluster view for clients
     * and a dummy context, into the given instance of CMIContext.
     * @param initialContextFactoryName a InitialContextFactory for this protocol
     * @param serverRef a reference onto the local registry
     * @param cmiContext a instance of CMIContext to bind a provider of the cluster view for clients and a dummy context
     * @throws ServerClusterViewManagerException if the protocol cannot be added
     */
    public final void addProtocol(final String initialContextFactoryName, final ServerRef serverRef,
            final Context cmiContext) throws ServerClusterViewManagerException {

        String protocol = serverRef.getProtocol();
        String providerURL = serverRef.getProviderURL();

        synchronized (initialContextFactoryName) {
            // Checks if the protocol has been already added
            if(!initialContextFactories.containsKey(protocol)) {
                LOGGER.debug("New protocol {0} added", protocol);
                initialContextFactories.put(protocol, initialContextFactoryName);

                // Binds a provider of the cluster view depending on the configuration
                if(CMIConfig.isProviderBound()) {
                    LOGGER.debug("Binds a provider of the cluster view for protocol {0}", protocol);
                    bindClientClusterViewProvider(cmiContext, protocol);
                }

                // Bind a dummy registry to enable the load-balancing of JNDI accesses for unclustered objects
                if(CMIConfig.isRegistryBound()) {
                    LOGGER.debug("Binds a dummy object that represents the registry for protocol {0}", protocol);
                    bindDummyRegistry(serverRef);
                }

                // Keeps a reference on the local registry (for local preference)
                refsOnLocalRegistries.put(protocol, serverRef);
                InetAddress newInetAddress = serverRef.getInetAddress();
                try {
                    if(NetworkInterface.getByInetAddress(newInetAddress) == null) {
                        LOGGER.error("The referenced server is not local");
                        throw new ServerClusterViewManagerException("The referenced server is not local");
                    }
                } catch (SocketException e) {
                    LOGGER.error("Cannot know if the IP is local", e);
                    throw new ServerClusterViewManagerException("Cannot know if the IP is local", e);
                }
                if(inetAddress == null) {
                    LOGGER.debug("InetAdress of manager is {0}", newInetAddress);
                    inetAddress = newInetAddress;
                } else if(!newInetAddress.equals(inetAddress)) {
                    LOGGER.error(
                            "Host name expected: {0} - Host name found : {1}. All the protocol have to use the same host name !",
                            inetAddress, newInetAddress);
                    throw new ServerClusterViewManagerException(
                            "Host name expected: "+inetAddress.getHostName()+" - Host name found : "
                            +newInetAddress.getHostName()+". All the protocol have to use the same host name !");
                }

                // Set load factor
                setLoadFactor(serverRef, CMIConfig.getLoadFactor());

                // Bind a JMX connector server for this protocol, if CMI is not embedded and if the property
                if(!CMIConfig.isEmbedded() && CMIConfig.isConnectorEnabled(protocol)) {
                    try {
                        CMIAdminConnectorManager.startConnector(protocol, providerURL);
                    } catch (CMIMBeanConfigException e) {
                        LOGGER.error("The connector for the protocol {0} cannot be added", protocol, e);
                        throw new ServerClusterViewManagerException(
                                "The connector for the protocol " + protocol + " cannot be added", e);
                    }
                }
            }
        }
    }

    /**
     * Binds an instance of {@link ClientClusterViewProvider} into a CMIContext to enable replication of the provider.
     * @param cmiContext a context that enables replication of the provider
     * @param protocol the protocol name
     * @throws ServerClusterViewManagerException if the provider cannot be bound
     * @see ClientClusterViewProvider
     */
    private void bindClientClusterViewProvider(final Context cmiContext, final String protocol) throws ServerClusterViewManagerException {

        ClientClusterViewProvider clientClusterViewProvider = null;

        // Export the connector for only this protocol
        // So disable the MultiPRODelegate provided by Carol
        System.setProperty("carol.multipro.protocol", protocol);
        try {
            clientClusterViewProvider =
                new ClusteredClientClusterViewProvider(this);
        } catch (RemoteException e) {
            LOGGER.error("Cannot export the instance of ClientClusterViewProvider for the protocol {0}",
                    protocol, e);
            throw new ServerClusterViewManagerException(
                    "Cannot export the instance of ClientClusterViewProvider for the protocol " + protocol, e);
        } finally {
            System.setProperty("carol.multipro.protocol", "any");
        }

        String bindName = CMIConfig.getBindNameForProvider();

        // Extracts data on load-balancing from the annotated class
        ClusteredObjectInfo clusteredObjectInfo;
        try {
            clusteredObjectInfo =
                CMIInfoExtractor.extractClusteringInfoFromAnnotatedPOJO(
                        bindName, ClientClusterViewProvider.class,
                        ClusteredClientClusterViewProvider.class, false, false, null);
        } catch (CMIInfoExtractorException e) {
            LOGGER.error("Cannot get infos for client provider", e);
            throw new ServerClusterViewManagerException("Cannot get infos for client provider", e);
        }

        // Registers the data into the repository to enable replication
        CMIInfoRepository.addClusteredObjectInfo(bindName, clusteredObjectInfo);

        // Performs the binding into the CMIContext
        try {
            cmiContext.rebind(bindName, clientClusterViewProvider);
        } catch (NamingException e) {
            LOGGER.error("Cannot rebind a ClientClusterViewProvider for protocol {0}", protocol, e);
            throw new ServerClusterViewManagerException("Cannot rebind a ClientClusterViewProvider " + protocol, e);
        }
        // Keep a reference on this pro in order to unexport it
        clientClusterViewProviders.put(protocol, clientClusterViewProvider);
        // Keep a reference on this pro in order to unbind it
        contexts.put(protocol, cmiContext);

        LOGGER.debug("ClientClusterViewProvider has been rebound for the protocol {0} with the name {1}", protocol, bindName);
    }

    /**
     * Binds a dummy registry to enable the load-balancing of JNDI accesses to unclustered objects.
     * @param serverRef a reference on the local registry
     */
    private void bindDummyRegistry(final ServerRef serverRef) {

        String bindName = CMIConfig.getBindNameForDummyRegistry();
        // Create an instance of CMIReference for this object
        CMIReference cmiReference = new CMIReference(serverRef, bindName);
        addObjectInstance(clusteredObjectInfoForDummyRegistry, cmiReference);
    }

    /**
     * Adds an object with the given name to a set of objects that need to have their state up-to-date.
     * @param objectName a name of object
     * @throws ObjectNotFoundException if none object has the given name
     */
    public final synchronized void addObjectToWatch(final String objectName)
    throws ObjectNotFoundException {
        if(!isWatched(objectName)) {
            LOGGER.debug("Adding {0} to the set of watched object", objectName);
            watch(objectName);
            updatePolicy(objectName);
        }
    }

    /**
     * Adds an instance of a clustered object.
     * If an other instance already exists, the current configuration is used.
     * @param clusteredObjectInfo informations on a clustered object
     * @param cmiReference a reference on a clustered object
     */
    @SuppressWarnings("unchecked")
    public final synchronized void addObjectInstance(
            final ClusteredObjectInfo clusteredObjectInfo,
            final CMIReference cmiReference) {

        // Retrieves the informations for the given clustered object
        Class<?> itfClass = clusteredObjectInfo.getItfClass();
        String businessName = null;
        String itfName = null;

        if(itfClass != null) {
            Class<? extends EJBObject> businessClass = clusteredObjectInfo.getBusinessClass();
            itfName = itfClass.getName();

            // Keep the class
            interfaces.putIfAbsent(itfName, itfClass);
            if(businessClass != null) {
                businessName = businessClass.getName();
                interfaces.putIfAbsent(businessName, businessClass);
            }
        }

        Class<? extends IPolicy> policyClass = clusteredObjectInfo.getPolicyType();
        Class<? extends IStrategy> strategyClass = clusteredObjectInfo.getStrategyType();

        String clusterName = clusteredObjectInfo.getClusterName();
        IPoolConfiguration poolConfiguration = clusteredObjectInfo.getPoolConfiguration();
        String policyType = policyClass.getName();
        String strategyType = strategyClass.getName();
        Map<String, Object> properties = clusteredObjectInfo.getProperties();
        boolean hasState = clusteredObjectInfo.hasState();
        boolean replicated = clusteredObjectInfo.isReplicated();
        Set<String> applicationExceptionNames = clusteredObjectInfo.getApplicationExceptionNames();

        // Check correctness of policy by creating it
        new PolicyFactory<CMIReference>(this).getPolicy(policyClass, strategyClass, properties);

        // Encapsulates data on load-balancing
        PolicyData policyData = new PolicyData(policyType, strategyType, properties);

        // Encapsulates data to replicate
        String objectName = cmiReference.getObjectName();

        DistributedObjectInfo distributedObjectInfo =
            new DistributedObjectInfo(clusterName, objectName, itfName,
                    businessName, policyData,
                    hasState, replicated, applicationExceptionNames,
                    poolConfiguration);

        /* Sets the informations that will be replicated.
         */
        addDistributedObjectInfo(objectName, distributedObjectInfo);

        // Adds the new reference
        LOGGER.debug("Adding {0}...", cmiReference);
        addCMIReference(cmiReference);
    }

    /**
     * Returns true if the given object is already replicated.
     * @param objectName a name of object
     * @return true if the given object is already replicated
     */
    protected abstract boolean containObject(String objectName);

    /**
     * Adds a CMIReference to the cluster view.
     * @param cmiReference a reference on an instance
     */
    protected abstract void addCMIReference(CMIReference cmiReference);

    /**
     * Returns informations on this object.
     * @param objectName a name of object
     * @return informations on this object
     * @throws ObjectNotFoundException if the given object is not found
     */
    protected abstract DistributedObjectInfo getDistributedObjectInfo(String objectName) throws ObjectNotFoundException;

    /**
     * Add informations on the clustered object with the given name.
     * @param objectName a name of object
     * @param distributedObjectInfo informations on the clustered object
     */
    protected abstract void addDistributedObjectInfo(String objectName, DistributedObjectInfo distributedObjectInfo);

    /**
     * Sets informations on the clustered object with the given name.
     * @param objectName a name of object
     * @param distributedObjectInfo informations on the clustered object
     */
    protected abstract void setDistributedObjectInfo(String objectName, DistributedObjectInfo distributedObjectInfo);

    /**
     * Returns a name of interface of this object.
     * @param objectName a name of object
     * @return a name of interface of this object
     * @throws ObjectNotFoundException if no object is bound with the given name
     */
    public final String getItfName(final String objectName) throws ObjectNotFoundException {
        return getDistributedObjectInfo(objectName).getItfName();
    }

    /**
     * Returns the interface of an object bound with the given name.
     * @param objectName a name of object
     * @return the interface of an object bound with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public final Class<?> getInterface(final String objectName) throws ObjectNotFoundException {
        return interfaces.get(getItfName(objectName));
    }

    /**
     * Returns a name of business interface of this object (for ejb2 only).
     * @param objectName a name of object
     * @return a name of business interface of this object
     * @throws ObjectNotFoundException if no object is bound with the given name
     */
    public final String getBusinessName(final String objectName) throws ObjectNotFoundException {
        return getDistributedObjectInfo(objectName).getBusinessName();
    }

    /**
     * Returns the business interface of an object bound with the given name (for ejb2 only).
     * @param objectName a name of object
     * @return the business interface of an object bound with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    @SuppressWarnings("unchecked")
    public final Class<? extends EJBObject> getRemoteClass(final String objectName)
    throws ObjectNotFoundException {
        return (Class<? extends EJBObject>) interfaces.get(getBusinessName(objectName));
    }

    /**
     * Returns the list of Provider URL.
     * @param protocolName a name of protocol
     * @return providers of the cluster view for the protocol with the given name
     * @throws ServerClusterViewManagerException if none provider exists for the protocol with the given name
     */
    public final List<String> getProviderURLs(final String protocolName) throws ServerClusterViewManagerException {
        String providerName = CMIConfig.getBindNameForProvider();
        ArrayList<String> providerURLs = new ArrayList<String>();
        try {
            for(CMIReference cmiReference : getCMIReferences(providerName, protocolName)) {
                providerURLs.add(cmiReference.getServerRef().getProviderURL());
            }
        } catch (ObjectNotFoundException e) {
            LOGGER.error("Cannot get CMIReferences for the provider whith name {0}", providerName, e);
            throw new ServerClusterViewManagerException(
                    "Cannot get CMIReferences for the provider whith name " + providerName, e);
        }
        return providerURLs;
    }

    /**
     * Returns the class that defines the policy for an object with the given name.
     * @param objectName a name of object
     * @return the class that defines the policy for an object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     * @throws ServerClusterViewManagerException if the class cannot be loaded
     */
    @SuppressWarnings("unchecked")
    public final Class<? extends IPolicy<?>> getPolicyClass(final String objectName)
    throws ObjectNotFoundException, ServerClusterViewManagerException {

        String policyClassName = getPolicyClassName(objectName);
        try {
            Class<? extends IPolicy<?>> policyClass = (Class<? extends IPolicy<?>>) Class.forName(policyClassName);
            policyMap.putIfAbsent(policyClassName, policyClass);
            return policyClass;
        } catch (ClassNotFoundException e) {
            LOGGER.error("Cannot load the class for policy " + policyClassName, e);
            throw new ServerClusterViewManagerException(
                    "Cannot load the class for policy " + policyClassName, e);
        }
    }


    /**
     * Returns the class that defines the strategy for an object with the given name.
     * @param objectName a name of object
     * @return the class that defines the strategy for an object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     * @throws ServerClusterViewManagerException if the class cannot be loaded
     */
    @SuppressWarnings("unchecked")
    public final Class<? extends IStrategy<?>> getStrategyClass(final String objectName)
    throws ObjectNotFoundException, ServerClusterViewManagerException {

        String strategyClassName = getStrategyClassName(objectName);
        try {
            Class<? extends IStrategy<?>> strategyClass =
                (Class<? extends IStrategy<?>>)  Class.forName(strategyClassName);
            strategyMap.putIfAbsent(strategyClassName, strategyClass);
            return strategyClass;
        } catch (ClassNotFoundException e) {
            LOGGER.error("Cannot load the class for strategy " + strategyClassName, e);
            throw new ServerClusterViewManagerException(
                    "Cannot load the class for strategy " + strategyClassName, e);
        }
    }

    /**
     * Returns the date of properties for an object with the given name.
     * @param objectName a name of object
     * @return the date of properties for an object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public final long getDateOfProperties(final String objectName) throws ObjectNotFoundException {
        return getDistributedObjectInfo(objectName).getPolicyData().getDateOfProperties();
    }

    /**
     * Returns the properties of the LB policy for an object with the given name.
     * @param objectName a name of object
     * @return the properties of the LB policy for an object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public final Map<String, Object> getPropertiesForPolicy(final String objectName)
    throws ObjectNotFoundException {
        return getDistributedObjectInfo(objectName).getPolicyData().getProperties();
    }

    /**
     * Returns a value property of the LB policy for an object with the given name.
     * @param objectName a name of object
     * @param propertyName a name of property
     * @return a value property of the LB policy for an object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public final Object getPropertyForPolicy(final String objectName, final String propertyName)
    throws ObjectNotFoundException {
        return getDistributedObjectInfo(objectName).getPolicyData().getProperties().get(propertyName);
    }

    /**
     * Sets properties for a given object.
     * @param objectName a name of object
     * @param properties properties for the LB policy of the given object
     * @throws ObjectNotFoundException if the specified object doesn't exist
     */
    public final void setPropertiesForPolicy(final String objectName, final Map<String, Object> properties)
    throws ObjectNotFoundException  {
        DistributedObjectInfo distributedObjectInfo = getDistributedObjectInfo(objectName);
        synchronized (distributedObjectInfo) {
            for(String propertyName : properties.keySet()) {
                distributedObjectInfo.getPolicyData().setProperty(propertyName, properties.get(propertyName));
            }
            setDistributedObjectInfo(objectName, distributedObjectInfo);
        }
    }

    /**
     * Sets a property for a given object.
     * @param objectName a name of object
     * @param propertyName a name of property for the LB policy of the given object
     * @param valueName a value for the given name of property
     * @throws ObjectNotFoundException if the specified object doesn't exist
     */
    public final void setPropertyForPolicy(
            final String objectName, final String propertyName, final Object valueName)
    throws ObjectNotFoundException {
        DistributedObjectInfo distributedObjectInfo = getDistributedObjectInfo(objectName);
        synchronized (distributedObjectInfo) {
            distributedObjectInfo.getPolicyData().setProperty(propertyName, valueName);
            setDistributedObjectInfo(objectName, distributedObjectInfo);
        }
    }

    /**
     * Returns a name of class that implements the interface InitialContextFactory for the given name of protocol.
     * @param protocolName a name of protocol
     * @return a name of class that implements the interface InitialContextFactory for the given name of protocol
     */
    public final String getInitialContextFactoryName(final String protocolName) {
        return initialContextFactories.get(protocolName);
    }

    /**
     * Returns true if the object with the specified name is clustered.
     * @param objectName a name of object
     * @return true if the object with the specified name is clustered
     */
    public final boolean isClustered(final String objectName) {
        return containObject(objectName);
    }

    /**
     * Returns the name of cluster for the object with the given name.
     * @param objectName a name of object
     * @return the name of cluster for a object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public final String getClusterName(final String objectName) throws ObjectNotFoundException {
        return getDistributedObjectInfo(objectName).getClusterName();
    }

    /**
     * Returns the name of class of policy for the object with the given name.
     * @param objectName a name of object
     * @return the name of class of policy for the object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public final String getPolicyClassName(final String objectName) throws ObjectNotFoundException {
        return getDistributedObjectInfo(objectName).getPolicyData().getPolicyType();
    }

    /**
     * Sets a new policy for a given object.
     * @param objectName a name of object
     * @param policyType a name of class of policy
     * @throws ObjectNotFoundException if no object is bound with the given name
     */
    public final void setPolicyClassName(final String objectName, final String policyType)
    throws ObjectNotFoundException {
        DistributedObjectInfo distributedObjectInfo = getDistributedObjectInfo(objectName);
        synchronized (distributedObjectInfo) {
            distributedObjectInfo.getPolicyData().setPolicyType(policyType);
            setDistributedObjectInfo(objectName, distributedObjectInfo);
        }
    }

    /**
     * Returns the name of class of strategy for the object with the given name.
     * @param objectName a name of object
     * @return the name of class of strategy for the object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public final String getStrategyClassName(final String objectName) throws ObjectNotFoundException {
        return getDistributedObjectInfo(objectName).getPolicyData().getStrategyType();
    }

    /**
     * Sets a new policy for a given object.
     * @param objectName a name of object
     * @param strategyClassName a name of class of strategy
     * @throws ObjectNotFoundException if no object is bound with the given name
     */
    public final void setStrategyClassName(final String objectName, final String strategyClassName)
    throws ObjectNotFoundException {
        DistributedObjectInfo distributedObjectInfo = getDistributedObjectInfo(objectName);
        synchronized (distributedObjectInfo) {
            distributedObjectInfo.getPolicyData().setStrategyType(strategyClassName);
            setDistributedObjectInfo(objectName, distributedObjectInfo);
        }
    }

    /**
     * Sets the algorithm of load-balancing for the object with the given name.
     * @param objectName a name of object
     * @param policyClassName a name of class of policy
     * @param strategyClassName a name of class of strategy
     * @param properties a set of properties
     * @throws ObjectNotFoundException if none object has the given name
     */
    public final void setAlgorithmForPolicy(final String objectName,
            final String policyClassName, final String strategyClassName,
            final Map<String, Object> properties) throws ObjectNotFoundException {
        DistributedObjectInfo distributedObjectInfo = getDistributedObjectInfo(objectName);
        synchronized (distributedObjectInfo) {
            PolicyData policyData = distributedObjectInfo.getPolicyData();
            policyData.setPolicyType(policyClassName);
            policyData.setStrategyType(strategyClassName);
            policyData.setProperties(properties);
            setDistributedObjectInfo(objectName, distributedObjectInfo);
        }
    }

    /**
     * Returns the configuration of pool of CMIReferenceable for a object with the given name.
     * @param objectName a name of object
     * @return the configuration of pool of CMIReferenceable for a object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public IPoolConfiguration getPoolConfiguration(final String objectName) throws ObjectNotFoundException {
        return getDistributedObjectInfo(objectName).getPoolConfiguration();
    }

    /**
     * Set the configuration of pool of CMIReferenceable for a object with the given name.
     * @param objectName a name of object
     * @param the configuration of pool of CMIReferenceable for a object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public void setPoolConfiguration(final String objectName, final IPoolConfiguration poolConfiguration) throws ObjectNotFoundException {
        DistributedObjectInfo distributedObjectInfo = getDistributedObjectInfo(objectName);
        synchronized (distributedObjectInfo) {
            distributedObjectInfo.setPoolConfiguration(poolConfiguration);
            setDistributedObjectInfo(objectName, distributedObjectInfo);
        }
    }

    /**
     * Returns the address of the local registries.
     * @return the address of the local registries
     */
    public final InetAddress getInetAddress() {
        return inetAddress;
    }

    /**
     * @return the protocols registered in the manager
     */
    public final Set<String> getProtocols() {
        return new HashSet<String>(refsOnLocalRegistries.keySet());
    }

    /**
     * @param protocolName a name of protocol
     * @return the JMX service URL to access to this MBean or null if the protocol doesn't exist
     */
    public final JMXServiceURL getJMXServiceURL(final String protocolName) {
        return CMIAdminConnectorManager.getJMXServiceURL(protocolName);
    }

    /**
     * @param protocolName a name of protocol
     * @return the reference on the local registry for the given protocol
     */
    public final ServerRef getRefOnLocalRegistry(final String protocolName) {
        return refsOnLocalRegistries.get(protocolName);
    }

    /**
     * Initialize the statistics.
     */
    protected abstract void initStats();

    /**
     * Return true if the object with the given name is replicated for high-availability.
     * The module 'ha' is so required.
     * @param objectName a name of object
     * @return true if the object with the given name is replicated for high-availability
     * @throws ObjectNotFoundException if none object has the given name
     */
    public final boolean isReplicated(final String objectName)
    throws ObjectNotFoundException {
        return isReplicationManagerStarted() && getDistributedObjectInfo(objectName).isReplicated();
    }

    /**
     * Return classnames of the application exceptions.
     * @param objectName a name of object
     * @return classnames of the application exceptions
     * @throws ObjectNotFoundException if none object has the given name
     */
    public final Set<String> getApplicationExceptionNames(final String objectName) throws ObjectNotFoundException {
        return getDistributedObjectInfo(objectName).getApplicationExceptionNames();
    }

    /**
     * Return true if the object with the given name is stateful.
     * @param objectName a name of object
     * @return true if the object with the given name is stateful
     * @throws ObjectNotFoundException if none object has the given name
     */
    public boolean hasState(final String objectName) throws ObjectNotFoundException {
        return getDistributedObjectInfo(objectName).hasState();
    }

    /**
     * @return true if the replication manager is started
     */
    public final boolean isReplicationManagerStarted() {
        return replicationManagerStarted;
    }

    /**
     * Set if the replication manager is started.
     * @param replicationManagerStarted true if the replication manager is started
     */
    public final void setReplicationManagerStarted(final boolean replicationManagerStarted) {
        this.replicationManagerStarted = replicationManagerStarted;
    }

    /**
     * Gets available load balancing policies and strategies.
     */
    public Map<String, Set<String>> getAvailablePoliciesAndStrategies() {
        //TODO Load user defined policies and strategies.
        Map<String, Set<String>> ret = new HashMap<String, Set<String>>();
        ret.put("policies", new HashSet<String>(policyMap.keySet()));
        ret.put("strategies", new HashSet<String>(strategyMap.keySet()));
        return ret;
    }

    /**
     *	Load classes embedded in the CMI distribution.
     */
    @SuppressWarnings("unchecked")
    private void loadEmbeddedLBClasses() {
        for (Class<?> embeddedPolicyClass : embeddedPolicyClasses) {
            try {
                policyMap.put(embeddedPolicyClass.getName(), (Class<? extends IPolicy<CMIReference>>) embeddedPolicyClass);
            } catch (Exception e) {
                LOGGER.error("Cannot load the class for policy " + embeddedPolicyClass.getName(), e);
                throw new ServerClusterViewManagerException(
                        "Cannot load the class for policy " + embeddedPolicyClass.getName(), e);
            }
        }
        for (Class<?> embeddedStrategyClass : embeddedStrategyClasses) {
            try {
                strategyMap.put(embeddedStrategyClass.getName(), (Class<? extends IStrategy<CMIReference>>) embeddedStrategyClass);
            } catch (Exception e) {
                LOGGER.error("Cannot load the class for strategy " + embeddedStrategyClass.getName(), e);
                throw new ServerClusterViewManagerException(
                        "Cannot load the class for startegy " + embeddedStrategyClass.getName(), e);
            }
        }
    }

    /**
     * Return true if the given class name is embedded policy class.
     * @param className a name of class
     * @return true if the given class name is embedded policy class
     */
    public boolean isEmbeddedPolicy(final String className) {
        for (Class<?> embeddedPolicyClass : embeddedPolicyClasses) {
            if (embeddedPolicyClass.getName().equals(className)) {
                return true;
            }
        }
        return false;
    }


    /**
     * Return true if the given class name is embedded strategy class.
     * @param className a name of class
     * @return true if the given class name is embedded strategy class
     */
    public boolean isEmbeddedStrategy(final String className) {
        for (Class<?> embeddedStrategyClass : embeddedStrategyClasses) {
            if (embeddedStrategyClass.getName().equals(className)) {
                return true;
            }
        }
        return false;
    }

}
