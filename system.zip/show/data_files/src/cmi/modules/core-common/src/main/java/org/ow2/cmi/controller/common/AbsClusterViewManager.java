/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007,2008 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id: AbsClusterViewManager.java 1695 2008-03-20 13:27:55Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.controller.common;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

import net.jcip.annotations.ThreadSafe;

import org.ow2.cmi.controller.client.ClientClusterViewManager;
import org.ow2.cmi.ha.SessionId;
import org.ow2.cmi.lb.policy.IPolicy;
import org.ow2.cmi.lb.util.PolicyFactory;
import org.ow2.cmi.lb.util.PolicyFactoryException;
import org.ow2.cmi.reference.CMIReference;
import org.ow2.cmi.reference.CMIReferenceable;
import org.ow2.cmi.reference.ObjectNotFoundException;
import org.ow2.util.log.Log;
import org.ow2.util.log.LogFactory;
import org.ow2.util.pool.api.Pool;

/**
 * Common abstraction of a manager of the cluster view.
 * This class defines local data of a manager, so the class {@link org.ow2.cmi.admin.CMIAdmin} should not access it.
 * @author The new CMI team
 */
@ThreadSafe
public abstract class AbsClusterViewManager implements ClusterViewManager {

    /**
     * Logger.
     */
    private static final Log LOGGER = LogFactory.getLog(AbsClusterViewManager.class);

    /**
     * Singleton.
     */
    private static volatile ClusterViewManager clusterViewManager;

    /**
     * Map local data for each clustered RMI object.
     */
    private final ConcurrentHashMap<String, LocalObjectData> localObjectData =
        new ConcurrentHashMap<String, LocalObjectData>();

    private final Set<String> watchedObjects =
        Collections.synchronizedSet(new HashSet<String>());

    /**
     * A factory of daemon.
     */
    private final CMIThreadFactory cmiThreadFactory;

    /**
     * Universally Unique Identifier.
     */
    private final UUID uuid;

    /**
     * The last identifier of session.
     */
    private final AtomicLong sessionNb = new AtomicLong(0);


    /**
     * Creates a new instance of AbsClusterViewManager with initializing a factory of daemon.
     */
    protected AbsClusterViewManager() {
        String managerName;
        if(this instanceof ClientClusterViewManager) {
            managerName = "ClientClusterViewManager";
        } else {
            managerName = "ServerClusterViewManager";
        }
        cmiThreadFactory = new CMIThreadFactory(managerName);

        // Identify this manager
        uuid = UUID.randomUUID();
    }

    /**
     * Set the manager of the cluster view.
     * @param clusterViewManager a manager of the cluster view or null
     */
    protected static final void setClusterViewManager(final ClusterViewManager clusterViewManager) {
        if(clusterViewManager == null || AbsClusterViewManager.clusterViewManager == null) {
            AbsClusterViewManager.clusterViewManager = clusterViewManager;
        } else {
            LOGGER.warn("The cluster view manager is already initialized");
        }
    }

    /**
     * Returns the instance of LB policy associated with the given name of object.
     * @param objectName a name of object
     * @return the instance of LB policy associated with the given name of object
     */
    public final IPolicy<CMIReference> getPolicy(final String objectName) {
        localObjectData.putIfAbsent(objectName, new LocalObjectData(objectName));
        return localObjectData.get(objectName).getPolicy();
    }

    /**
     * Associates a name of of object with an instance of LB policy.
     * @param objectName a name of object
     * @param lbPolicy an instance of LB policy to associate with the given object
     */
    private void setPolicy(final String objectName, final IPolicy<CMIReference> lbPolicy) {
        localObjectData.putIfAbsent(objectName, new LocalObjectData(objectName));
        localObjectData.get(objectName).setPolicy(lbPolicy);
    }

    /**
     * Returns true if the object with the given name has a pool of CMIReferenceable.
     * @param objectName a name of object
     * @return true if the object with the given name has a pool of CMIReferenceable
     */
    protected final boolean hasPool(final String objectName) throws ObjectNotFoundException {
        localObjectData.putIfAbsent(objectName, new LocalObjectData(objectName));
        return localObjectData.get(objectName).getPool() != null;
    }

    /**
     * Returns a pool of CMIReferenceable for an object with the given name.
     * @param objectName a name of object
     * @return a pool of CMIReferenceable for an object with the given name
     */
    public final Pool<CMIReferenceable<?>, CMIReference> getPool(final String objectName) {
        localObjectData.putIfAbsent(objectName, new LocalObjectData(objectName));
        return localObjectData.get(objectName).getPool();
    }

    /**
     * Associates a name of object with a pool of CMIReferenceable.
     * @param objectName a name of object
     * @param pool a pool of CMIReferenceable
     */
    public final void setPool(final String objectName, final Pool<CMIReferenceable<?>, CMIReference> pool) {
        localObjectData.putIfAbsent(objectName, new LocalObjectData(objectName));
        localObjectData.get(objectName).setPool(pool);
    }

    /**
     * Updates a policy of load-balancing for a object with the given name.
     * @param objectName a name of object
     * @throws ObjectNotFoundException if none object has the given name
     * @throws PolicyFactoryException if the policy cannot be updated
     */
    protected final void updatePolicy(final String objectName) throws ObjectNotFoundException, PolicyFactoryException {
        LOGGER.debug("Updating policy for {0}", objectName);
        PolicyFactory<CMIReference> policyFactory = new PolicyFactory<CMIReference>(this);
        IPolicy<CMIReference> policy = policyFactory.getPolicy(objectName);
        setPolicy(objectName, policy);
    }

    /**
     * Returns true if the local data for the object with the given name has been initialized.
     * @param objectName a name of object
     * @return true if the local data for the object with the given name has been initialized
     */
    protected final boolean isWatched(final String objectName) {
        return watchedObjects.contains(objectName);
    }

    protected final void watch(final String objectName) {
        watchedObjects.add(objectName);
    }

    /**
     * Returns the set of names of object that has been initialized.
     * @return the set of names of object that has been initialized
     */
    protected final Set<String> getNamesOfWatchedObject() {
        return new HashSet<String>(watchedObjects);
    }

    /**
     * Returns this instance (singleton) of manager, if it exists, null otherwise.
     * @return this instance (singleton) of manager, if it exists, null otherwise
     */
    public static final ClusterViewManager getClusterViewManager() {
        return clusterViewManager;
    }

    /**
     * Returns the factory to create CMI daemons.
     * @return the factory to create CMI daemons
     */
    protected final CMIThreadFactory getCmiThreadFactory() {
        return cmiThreadFactory;
    }

    /**
     * @return the UUID for this manager
     */
    public UUID getUUID() {
        return uuid;
    }

    /**
     * @return a new identifier of session
     */
    public SessionId getSessionId() {
        return new SessionId(AbsClusterViewManager.getClusterViewManager().getUUID(),
                sessionNb.incrementAndGet());
    }

}
