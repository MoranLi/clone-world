/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007,2008 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id: MyClass.java 1668 2008-03-09 16:39:40Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.test;

import java.rmi.RemoteException;

import javax.rmi.PortableRemoteObject;

import org.ow2.cmi.annotation.ArrayProperty;
import org.ow2.cmi.annotation.Cluster;
import org.ow2.cmi.annotation.Policy;
import org.ow2.cmi.annotation.Properties;
import org.ow2.cmi.annotation.SimpleProperty;
import org.ow2.cmi.annotation.Strategy;
import org.ow2.cmi.lb.strategy.LocalPreference;
import org.ow2.util.pool.annotation.Pool;

/**
 * Simple class used in test.
 * @author Florent Benoit
 */
@Cluster(name="test_cluster", pool=@Pool(max=2))
@Policy(DummyPolicy.class)
@Strategy(LocalPreference.class)
@Properties(
        simpleProperties={@SimpleProperty(name="prop1", value="val1"),
                @SimpleProperty(name="prop2", value="38")},
        arrayProperties={@ArrayProperty(name="prop3", values="true"),
                @ArrayProperty(name="prop4", values={"java.util.LinkedList", "java.util.ArrayList"}),
                @ArrayProperty(name="prop5", values={"http://www.ow2.org"})})
public class MyClass extends PortableRemoteObject implements MyItf {

    private String content = null;

    protected MyClass(final String content) throws RemoteException {
        super();
        this.content = content;
    }

    public void display() throws RemoteException {
        System.out.println("Hey " + content + "!");

    }

}
