/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2008 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id: CMIMapping.java 1659 2008-03-07 17:46:48Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.info.mapping;

/**
 * @author Loris Bouzonnet
 */
public class CMIMapping {

    private ClusteredObjects clusteredObjects;

    public ClusteredObjects getClusteredObjects() {
        return clusteredObjects;
    }

    public void setClusteredObjects(final ClusteredObjects clusteredObjects) {
        this.clusteredObjects = clusteredObjects;
    }

}
