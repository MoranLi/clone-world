/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2008 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id: CMIInvocationHandlerByPool.java 1695 2008-03-20 13:27:55Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.rpc;

import org.ow2.cmi.controller.common.ClusterViewManager;
import org.ow2.cmi.reference.CMIReference;
import org.ow2.cmi.reference.CMIReferenceable;
import org.ow2.util.log.Log;
import org.ow2.util.log.LogFactory;
import org.ow2.util.pool.api.Pool;

/**
 * An abstract specialization of the interface {@link CMIInvocationHandler} using a {@link Pool} to store stubs and proxies.
 * @param <T> the type of the remote object.
 * @author Loris Bouzonnet
 */
public abstract class CMIInvocationHandlerByPool<T> extends CMIInvocationHandler<T> {

    /**
     * Logger.
     */
    private static final Log LOGGER = LogFactory.getLog(CMIInvocationHandlerByPool.class);

    protected CMIInvocationHandlerByPool(final ClusterViewManager clusterViewManager,
            final String objectName, final String protocolName, final boolean keepCurrentRef,
            final Class<? extends T> itf) {
        super(clusterViewManager, objectName, protocolName, keepCurrentRef, itf);
    }

    @SuppressWarnings("unchecked")
    @Override
    protected CMIReferenceable<T> getCMIReferenceable(final CMIReference cmiReference) throws Exception {
        return (CMIReferenceable<T>) clusterViewManager.getPool(objectName).get(cmiReference);
    }

    @Override
    protected void onExceptionHook(final String objectName, final CMIReferenceable<T> cmiReferenceable)
    throws Exception {
        try {
            clusterViewManager.getPool(objectName).discard(cmiReferenceable);
        } catch (Exception e) {
            LOGGER.debug("Cannot discard the reference {0}", cmiReferenceable, e);
        }
    }

    @Override
    protected void onFinallyHook(final String objectName, final CMIReferenceable<T> cmiReferenceable) {
        try {
            clusterViewManager.getPool(objectName).release(cmiReferenceable);
        } catch (Exception e) {
            LOGGER.debug("Cannot release the reference {0}", cmiReferenceable, e);
        }
    }

}
