/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007,2008 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id: LocalObjectData.java 1695 2008-03-20 13:27:55Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.controller.common;

import net.jcip.annotations.ThreadSafe;

import org.ow2.cmi.lb.policy.IPolicy;
import org.ow2.cmi.reference.CMIReference;
import org.ow2.cmi.reference.CMIReferenceable;
import org.ow2.util.pool.api.Pool;

/**
 * Represents local data on a clustered object.
 * @author The new CMI team
 */
@ThreadSafe
public final class LocalObjectData {

    /**
     * A name of clustered object.
     */
    private final String objectName;

    /**
     * Pool that manage CMIReferenceable (ie stubs and proxies) to access at the clustered object.
     */
    private volatile Pool<CMIReferenceable<?>, CMIReference> pool;

    /**
     * A policy of load-balancing to use to access at the clustered object.
     */
    private volatile IPolicy<CMIReference> policy;

    /**
     *
     * @param objectName a name of object
     */
    public LocalObjectData(final String objectName) {
        this.objectName = objectName;
    }

    /**
     * @return the policy
     */
    public IPolicy<CMIReference> getPolicy() {
        return policy;
    }

    /**
     * @param policy the policy to set
     */
    public void setPolicy(final IPolicy<CMIReference> policy) {
        this.policy = policy;
    }

    /**
     * @return the objectName
     */
    public String getObjectName() {
        return objectName;
    }

    /**
     * @return the pool
     */
    public Pool<CMIReferenceable<?>, CMIReference> getPool() {
        return pool;
    }

    /**
     * @param pool the pool to set
     */
    public void setPool(final Pool<CMIReferenceable<?>, CMIReference> pool) {
        this.pool = pool;
    }

}
