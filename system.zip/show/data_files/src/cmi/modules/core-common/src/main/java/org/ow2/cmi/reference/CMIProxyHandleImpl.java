/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id: CMIProxyHandleImpl.java 1659 2008-03-07 17:46:48Z loris $
 * --------------------------------------------------------------------------
 */
package org.ow2.cmi.reference;

import java.rmi.RemoteException;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionBindingEvent;

import org.ow2.cmi.reference.CMIProxyHandle;
import org.ow2.cmi.rpc.CMIProxy;

/**
 * Implementation of a {@link CMIProxyHandle} that uses a lazy unserialization.
 * @author Loris Bouzonnet
 */
public class CMIProxyHandleImpl implements CMIProxyHandle, Cloneable {

    /**
     * Id for serializable class.
     */
    private static final long serialVersionUID = -7287239564023221363L;

    /**
     * The cmi proxy.
     */
    private transient CMIProxy cmiProxy;

    /**
     * The serialized form of the cmi proxy.
     */
    private byte[] serializedProxy;

    /**
     * The object name.
     */
    final String objectName;

    /**
     * The interface name.
     */
    private final String interfaceName;

    /**
     * Indicates if the associated Handle is bounded to a HTTP session.
     */
    private transient boolean httpBound = false;

    /**
     * HTTP session to which is bound.
     */
    private transient HttpSession httpSession = null;

    /**
     * Attribute name with which is bound in the HTTP session.
     */
    private transient String attributeName = null;

    /**
     * Construct a new handler of {@link CMIProxy}.
     * @param objectName the object name
     * @param interfaceName the name of the interface implemented by the handled proxy
     * @param cmiProxy the cmi proxy
     */
    public CMIProxyHandleImpl(final String objectName, final String interfaceName, final CMIProxy cmiProxy) {
        this.objectName = objectName;
        this.cmiProxy = cmiProxy;
        this.interfaceName = interfaceName;
        serializedProxy = CMIProxySerializer.serialize(cmiProxy);
    }

    /* (non-Javadoc)
     * @see org.ow2.cmi.reference.CMIProxyHandle#getCMIProxy()
     */
    public CMIProxy getCMIProxy() throws RemoteException {
        if(cmiProxy == null) {
            if(serializedProxy == null) {
                throw new RemoteException("The handle is empty !");
            }
            Object object = CMIProxySerializer.unserialize(this);
            if(object == null) {
                throw new RemoteException("Cannot unserialize the EJBHome");
            }
            cmiProxy = (CMIProxy) object;
        }
        return cmiProxy;
    }

    // Implements HttpSessionBindingListener

    /* (non-Javadoc)
     * @see javax.servlet.http.HttpSessionBindingListener#valueBound(javax.servlet.http.HttpSessionBindingEvent)
     */
    /* (non-Javadoc)
     * @see org.ow2.cmi.reference.CMIProxyHandle#valueBound(javax.servlet.http.HttpSessionBindingEvent)
     */
    public void valueBound(final HttpSessionBindingEvent arg0) {

        httpBound = true;
        httpSession = arg0.getSession();
        attributeName = arg0.getName();
    }

    /* (non-Javadoc)
     * @see javax.servlet.http.HttpSessionBindingListener#valueUnbound(javax.servlet.http.HttpSessionBindingEvent)
     */
    /* (non-Javadoc)
     * @see org.ow2.cmi.reference.CMIProxyHandle#valueUnbound(javax.servlet.http.HttpSessionBindingEvent)
     */
    public void valueUnbound(final HttpSessionBindingEvent arg0) {

        httpBound = false;
        httpSession = null;
        attributeName = null;
    }

    /* (non-Javadoc)
     * @see org.ow2.cmi.reference.CMIProxyHandle#updateHttpSession()
     */
    public CMIProxyHandle updateHttpSession() {
        CMIProxyHandle cmiProxyHandle = null;
        if (httpBound) {
            serializedProxy = CMIProxySerializer.serialize(cmiProxy);
            try {
                cmiProxyHandle = (CMIProxyHandle) clone();
            } catch (CloneNotSupportedException e) {
                e.printStackTrace();
            }
            // when we call setAttribute on the httpSession
            httpSession.setAttribute(attributeName, cmiProxyHandle);
        }
        return cmiProxyHandle;
    }

    public byte[] getSerializedCMIInvocationHandler() {
        return serializedProxy;
    }

    public String getInterfaceName() {
        return interfaceName;
    }

    public String getObjectName() {
        return objectName;
    }

}
