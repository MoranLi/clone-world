/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id: CMIProxySerializer.java 1659 2008-03-07 17:46:48Z loris $
 * --------------------------------------------------------------------------
 */
package org.ow2.cmi.reference;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectStreamClass;
import java.lang.reflect.Proxy;

import org.ow2.cmi.controller.common.AbsClusterViewManager;
import org.ow2.cmi.controller.common.ClusterViewManager;
import org.ow2.cmi.reference.CMIProxyHandle;
import org.ow2.cmi.rpc.CMIInvocationHandler;
import org.ow2.cmi.rpc.CMIProxy;
import org.ow2.util.log.Log;
import org.ow2.util.log.LogFactory;

/**
 * Utility class providing methods to serialize and unserialize the instance of {@link CMIProxy}.
 * @author Loris Bouzonnet
 */
public final class CMIProxySerializer {

    /**
     * Logger.
     */
    private static final Log LOGGER = LogFactory.getLog(CMIProxySerializer.class);

    private static ClusterViewManager clusterViewManager = null;

    /**
     * Utility class, so no public constructor.
     */
    private CMIProxySerializer() {
    }

    /**
     * Serialize an instance of {@link CMIProxy}.
     * @param object a cmi proxy
     * @return the serialized cmi proxy
     */
    public static byte[] serialize(final CMIProxy object) {
        ByteArrayOutputStream bOutputStream = new ByteArrayOutputStream();
        ObjectOutputStream objectOutputStream;
        try {
            objectOutputStream = new ObjectOutputStream(bOutputStream);
            objectOutputStream.writeObject(Proxy.getInvocationHandler(object));
            objectOutputStream.flush();
            return bOutputStream.toByteArray();
        } catch (IOException e) {
            LOGGER.error("Cannot serialize the object {0}", object, e);
            return null;
        }
    }

    /**
     * Unserialize an instance of {@link CMIProxy}.
     * @param proxyHandle
     * @return the cmi proxy
     */
    public static CMIProxy unserialize(final CMIProxyHandle proxyHandle) {
        final ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        if(clusterViewManager == null) {
            clusterViewManager = AbsClusterViewManager.getClusterViewManager();
        }
        String objectName = proxyHandle.getObjectName();
        try {
            clusterViewManager.addObjectToWatch(objectName);
        } catch (Exception e) {
            LOGGER.error("Cannot retrieve the object for name {0}", objectName, e);
            return null;
        }
        String classname = proxyHandle.getInterfaceName();
        Class<?> interf;
        try {
            interf = Class.forName(classname, true, classLoader);
        } catch (ClassNotFoundException e) {
            LOGGER.error("Cannot load the interface with name {0}", classname, e);
            return null;
        }
        try {
            ObjectInputStream stream = new ObjectInputStream(
                    new ByteArrayInputStream(proxyHandle.getSerializedCMIInvocationHandler())) {
                @Override
                protected Class<?> resolveClass(final ObjectStreamClass desc) throws IOException, ClassNotFoundException {
                    String name = desc.getName();
                    return Class.forName(name, false, classLoader);
                }
            };
            CMIInvocationHandler<?> invocationHandler = (CMIInvocationHandler<?>) stream.readObject();
            invocationHandler.setCmiProxyHandle(proxyHandle);
            return (CMIProxy) Proxy.newProxyInstance(classLoader, new Class[] {interf, CMIProxy.class}, invocationHandler);
        } catch (Exception e) {
            LOGGER.error("Cannot unserialize", e);
            return null;
        }
    }
}
