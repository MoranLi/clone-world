/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007,2008 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id: TestCommonCore.java 1695 2008-03-20 13:27:55Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.test;

import java.net.URL;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;

import org.ow2.cmi.info.CMIInfoExtractor;
import org.ow2.cmi.info.ClusteredObjectInfo;
import org.ow2.cmi.lb.policy.IPolicy;
import org.ow2.cmi.lb.strategy.IStrategy;
import org.ow2.cmi.lb.strategy.LocalPreference;
import org.ow2.cmi.pool.StubOrProxyFactory;
import org.ow2.cmi.reference.CMIReference;
import org.ow2.cmi.reference.CMIReferenceable;
import org.ow2.util.log.Log;
import org.ow2.util.log.LogFactory;
import org.ow2.util.pool.api.IPoolConfiguration;
import org.ow2.util.pool.impl.JPool;
import org.ow2.util.pool.impl.PoolConfiguration;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;


/**
 * Test of the module core common.
 * @author The new CMI team
 */
public class TestCommonCore {

    /**
     * Logger.
     */
    private static Log logger = LogFactory.getLog(TestCommonCore.class);

    private CMIReference cmiRef;

    private String providerURL = "rmi://localhost:3000";

    private String protocol = "jrmp";

    private ClusteredObjectInfo clusteredObjectInfoFromPOJO;

    private Context c;

    private final Class<? extends IPolicy> policyType = DummyPolicy.class;

    private final Class<? extends IStrategy> strategyType = LocalPreference.class;

    private final String prop1 = "val1";

    private final int prop2 = 38;

    private final List<Boolean> prop3 = new ArrayList<Boolean>();

    private final List<Class<? extends List>> prop4 = new ArrayList<Class<? extends List>>();

    private final List<URL> prop5 = new ArrayList<URL>();

    private final Map<String, Object> properties = new HashMap<String, Object>();

    private final String objectName = "dummyObject";

    private final String clusterName = "test_cluster";

    private final IPoolConfiguration poolConfiguration = new PoolConfiguration();

    /**
     * Registry object.
     */
    private Registry registry = null;

    /**
     * RMi registry port.
     */
    public static final int RMI_REGISTRY_PORT = 3000;

    /**
     * Initialize a rmi registry and create a context.
     *
     * @throws Exception
     *             if the registry can not be successfully started or the
     *             context can not be created
     */
    @BeforeClass
    public void init() throws Exception {
        Hashtable<String, Object> env = new Hashtable<String, Object>();
        this.registry = LocateRegistry.createRegistry(RMI_REGISTRY_PORT);

        env.put(Context.INITIAL_CONTEXT_FACTORY,
                "com.sun.jndi.rmi.registry.RegistryContextFactory");
        env.put(Context.PROVIDER_URL, providerURL);
        this.c = new InitialContext(env);
        prop3.add(true);
        prop4.add(LinkedList.class);
        prop4.add(ArrayList.class);
        prop5.add(new URL("http://www.ow2.org"));
        properties.put("prop1", prop1);
        properties.put("prop2", prop2);
        properties.put("prop3", prop3);
        properties.put("prop4", prop4);
        properties.put("prop5", prop5);
        poolConfiguration.setMax(2);
    }

    /**
     * Test of getting the informations brought by the annotations of an object.
     */
    @Test
    public void testGetInfo() {
        logger.debug("Begin the test for getting the cluster informations of an annotated class");

        try {
            clusteredObjectInfoFromPOJO =
                CMIInfoExtractor.extractClusteringInfoFromAnnotatedPOJO(
                    objectName, MyItf.class, MyClass.class, false, false, null);
            Assert.assertTrue(clusteredObjectInfoFromPOJO.getClusterName().equals(clusterName)
                    && clusteredObjectInfoFromPOJO.getPolicyType().equals(policyType)
                    && clusteredObjectInfoFromPOJO.getStrategyType().equals(strategyType)
                    && clusteredObjectInfoFromPOJO.getProperties().equals(properties)
                    && clusteredObjectInfoFromPOJO.getPoolConfiguration().equals(poolConfiguration),
                    "The extracted informations are not valid");
            ClusteredObjectInfo clusteredObjectInfoFromDD =
                CMIInfoExtractor.extractClusteringInfoFromDD(
                        objectName, MyItf.class, null,
                        Thread.currentThread().getContextClassLoader().getResource("test_policy.xml"),
                        false, false, null);
            Assert.assertEquals(clusteredObjectInfoFromDD, clusteredObjectInfoFromPOJO);
        } catch(Throwable e) {
            e.printStackTrace();
            Assert.fail("Cannot extract infos", e);
        }
    }

    @Test
    public void testCreateCMIReferencable() {
        String itfname = MyItf.class.getName();
        try {
            DummyClusterViewManager dcvm = new DummyClusterViewManager();
            dcvm.setInitialContextFactoryName("jrmp",
            "com.sun.jndi.rmi.registry.RegistryContextFactory");
            dcvm.setItfClassName(objectName, itfname);
            MyClass mclz2 = new MyClass("puppy");
            c.bind(objectName, mclz2);

            Object stub = c.lookup(objectName);

            this.cmiRef = new CMIReference(this.protocol, this.providerURL, objectName);

            StubOrProxyFactory cmiRF = new StubOrProxyFactory(dcvm);
            JPool<CMIReferenceable<?>, CMIReference> jpool = new JPool<CMIReferenceable<?>, CMIReference>(cmiRF);
            CMIReferenceable cmiReferenceable = jpool.get(cmiRef);
            Object stubgen = cmiReferenceable.getReferencedObject();

            if (stub.equals(stubgen)) {
                logger.info("the stub created by the pool factory is equals with the stub original!");
            } else {
                logger.info("the result is not correct!");
            }
        } catch(Throwable thr) {
            thr.printStackTrace();
            Assert.fail("Cannot create a CMIReferenceable", thr);
        }
    }

    /**
     * Stop the started registry.
     * @throws Exception if registry is not stopped
     */
    @AfterClass(alwaysRun = true)
    public void stopRegistry() throws Exception {
        if (registry != null) {
            UnicastRemoteObject.unexportObject(registry, true);
            registry = null;
        }
    }

}
