/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007,2008 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id:Util.java 914 2007-05-25 16:48:16Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.info;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ejb.EJBObject;

import net.jcip.annotations.Immutable;

import org.ow2.cmi.annotation.ArrayProperty;
import org.ow2.cmi.annotation.Cluster;
import org.ow2.cmi.annotation.Policy;
import org.ow2.cmi.annotation.Properties;
import org.ow2.cmi.annotation.SimpleProperty;
import org.ow2.cmi.annotation.Strategy;
import org.ow2.cmi.info.mapping.ArrayPropertyInfo;
import org.ow2.cmi.info.mapping.CMIMapping;
import org.ow2.cmi.info.mapping.ClusteredObjects;
import org.ow2.cmi.info.mapping.PropertiesInfo;
import org.ow2.cmi.info.mapping.SimplePropertyInfo;
import org.ow2.cmi.lb.PropertyConfigurationException;
import org.ow2.cmi.lb.policy.IPolicy;
import org.ow2.cmi.lb.strategy.IStrategy;
import org.ow2.cmi.lb.strategy.NoStrategy;
import org.ow2.cmi.lb.util.PolicyFactory;
import org.ow2.util.log.Log;
import org.ow2.util.log.LogFactory;
import org.ow2.util.pool.annotation.Pool;
import org.ow2.util.pool.api.IPoolConfiguration;
import org.ow2.util.pool.impl.PoolConfigurationHelper;
import org.ow2.util.xmlconfig.XMLConfiguration;
import org.ow2.util.xmlconfig.XMLConfigurationException;


/**
 * Utility class which provides methods to extract clustering informations.
 * @author The new CMI team
 */
@Immutable
public final class CMIInfoExtractor {

    /**
     * Logger.
     */
    private static Log logger = LogFactory.getLog(CMIInfoExtractor.class);

    /**
     * Utility class, so not public constructor.
     */
    private CMIInfoExtractor() {
    }

    /**
     * Return informations on a clustered POJO from its interface and his annotated implementation.
     * @param objectName the object name
     * @param itfClass the interface of the POJO
     * @param impl a class which implements the interface
     * @param stateful true if the object with the given name has a state
     * @param replicated true if the object with the given name is replicated for high-availability
     * @param applicationExceptionNames classnames of the application exceptions
     * @return informations on a clustered POJO from its interface and his annotated implementation
     * @throws CMIInfoExtractorException if the given class is badly annotated
     */
    @SuppressWarnings("unchecked")
    public static ClusteredObjectInfo extractClusteringInfoFromAnnotatedPOJO(
            final String objectName, final Class<?> itfClass, final Class<?> impl, final boolean stateful,
            final boolean replicated, final Set<String> applicationExceptionNames)
    throws CMIInfoExtractorException {

        // Get the annotation @Cluster
        Cluster cluster = impl.getAnnotation(Cluster.class);
        if(cluster == null) {
            logger.info("No annotation @Cluster found");
            return null;
        }

        // Check if a descriptor is present
        String descriptor = cluster.descriptor();
        if(descriptor != null) {
            // Try to load it
            try {
                return extractClusteringInfoFromDD(
                        objectName, itfClass, null,
                        Thread.currentThread().getContextClassLoader().getResource(descriptor),
                        stateful, replicated, applicationExceptionNames);
            } catch(Exception e) {
                logger.debug("Cannot extract clustering infos from the descriptor {0}", descriptor, e);
            }
        }

        String clusterName = cluster.name();

        // Extract the configuration of pool
        Pool poolAnnotation = cluster.pool();
        IPoolConfiguration poolConfiguration = null;
        if(poolAnnotation != null) {
            poolConfiguration = PoolConfigurationHelper.getConfiguration(poolAnnotation);
        }

        // Get the annotation @Policy
        Policy policy = impl.getAnnotation(Policy.class);
        if(policy == null) {
            logger.error("No annotation @Policy found !");
            throw new CMIInfoExtractorException("No annotation @Policy found !");
        }

        Class<? extends IPolicy> policyType = policy.value();

        // Get @Strategy if it exists
        Strategy strategy = impl.getAnnotation(Strategy.class);
        Class<? extends IStrategy> strategyType = null;
        if(strategy != null) {
            strategyType = strategy.value();
        } else {
            strategyType = NoStrategy.class;
        }

        HashMap<String, Object> policyProperties = null;
        // Get properties if they exist
        Properties properties = impl.getAnnotation(Properties.class);
        if(properties != null) {
            SimpleProperty[] simpleProperties = properties.simpleProperties();
            ArrayProperty[] arrayProperties = properties.arrayProperties();
            policyProperties = new HashMap<String, Object>();
            for(SimpleProperty property : simpleProperties) {
                String propertyName = property.name();
                String svalue = property.value();
                Object propertyValue;
                try {
                    propertyValue = PolicyFactory.convertString(policyType, propertyName, svalue);
                } catch (PropertyConfigurationException e) {
                    throw new CMIInfoExtractorException("Cannot cast property " + propertyName, e);
                }
                logger.debug("Adding pair ({0},{1})", propertyName, propertyValue);
                policyProperties.put(propertyName, propertyValue);
            }
            for(ArrayProperty arrayProperty : arrayProperties) {
                String propertyName = arrayProperty.name();
                String[] svalues = arrayProperty.values();
                List<?> propertyValues;
                try {
                    propertyValues = PolicyFactory.convertStrings(policyType, propertyName, Arrays.asList(svalues));
                } catch (PropertyConfigurationException e) {
                    throw new CMIInfoExtractorException("Cannot cast property " + propertyName, e);
                }
                logger.debug("Adding pair ({0},{1})", propertyName, propertyValues);
                policyProperties.put(propertyName, propertyValues);
            }
        }
        return new ClusteredObjectInfo(
                itfClass, null, clusterName, poolConfiguration,
                (Class<? extends IPolicy<?>>) policyType,
                (Class<? extends IStrategy<?>>) strategyType,
                policyProperties, stateful, replicated, applicationExceptionNames);
    }

    /**
     * Return informations on a clustered POJO from its interface and a given descriptor of deployment.
     * @param objectName the object name
     * @param itfName the interface of the POJO
     * @param businessName the name of the business interface (only for ejb2)
     * @param url the URL of the descriptor of deployment
     * @param stateful true if the object with the given name has a state
     * @param replicated true if the object with the given name is replicated for high-availability
     * @param applicationExceptionNames classnames of the application exceptions
     * @return informations extracted from its interface and a given descriptor of deployment
     * @throws CMIInfoExtractorException if the mapping cannot be done
     */
    @SuppressWarnings("unchecked")
    public static ClusteredObjectInfo extractClusteringInfoFromDD(
            final String objectName, final Class<?> itfClass, final Class<? extends EJBObject> businessClass,
            final URL url, final boolean stateful, final boolean replicated, final Set<String> applicationExceptionNames)
    throws CMIInfoExtractorException {

        XMLConfiguration xmlConfiguration = new XMLConfiguration(url, "cmi-mapping.xml");
        CMIMapping cmiMapping = new CMIMapping();
        try {
            xmlConfiguration.configure(cmiMapping);
        } catch (XMLConfigurationException e) {
            logger.error("Cannot set informations for the clustered object with interface {0}", itfClass.getName(), e);
            throw new CMIInfoExtractorException(
                    "Cannot set informations for the clustered object with interface " + itfClass.getName(), e);
        }
        ClusteredObjects clusteredObjects = cmiMapping.getClusteredObjects();
        logger.debug("Clustered objects found: {0}", clusteredObjects);

        org.ow2.cmi.info.mapping.Cluster clusteredObject = null;
        for(org.ow2.cmi.info.mapping.Cluster clusteredObj : clusteredObjects.getClusteredObjects()) {
            if(clusteredObj.getObjectName() == null || clusteredObj.getObjectName().equals(objectName)) {
                clusteredObject = clusteredObj;
                break;
            }
        }
        if(clusteredObject == null) {
            logger.error("No definition of clustered object for {0}", objectName);
            throw new CMIInfoExtractorException("No definition of clustered object for " + objectName);
        }

        String clusterName = clusteredObject.getClusterName();
        if(clusterName == null || clusterName.equals("")) {
            logger.error("The cluster name is not set");
            throw new CMIInfoExtractorException("The cluster name is not set");
        }
        String policyClassName = clusteredObject.getPolicyType();
        if(policyClassName == null || policyClassName.equals("")) {
            logger.error("The LB policy name is not set");
            throw new CMIInfoExtractorException("The LB policy name is not set");
        }
        Class<? extends IPolicy> policyClass;
        try {
            policyClass = (Class<? extends IPolicy>) Class.forName(policyClassName);
        } catch (ClassNotFoundException e) {
            logger.error("Cannot load the class {0} that define a policy", policyClassName, e);
            throw new CMIInfoExtractorException(
                    "Cannot load the class " + policyClassName + " that define a policy", e);
        }

        String strategyClassName = clusteredObject.getStrategyType();
        Class<? extends IStrategy> strategyClass;
        if(strategyClassName == null || strategyClassName.equals("")) {
            strategyClass = NoStrategy.class;
        } else {
            try {
                strategyClass = (Class<? extends IStrategy>) Class.forName(strategyClassName);
            } catch (ClassNotFoundException e) {
                logger.error("Cannot load the class {0} that define a strategy", strategyClassName, e);
                throw new CMIInfoExtractorException(
                        "Cannot load the class " + strategyClassName + " that define a strategy", e);
            }
        }

        IPoolConfiguration poolConfiguration = clusteredObject.getPoolConfiguration();

        PropertiesInfo propertiesInfo = clusteredObject.getPropertiesInfo();
        Map<String, Object> policyProperties = null;
        if(propertiesInfo != null) {
            try {
                policyProperties = extractProperties((Class<? extends IPolicy<?>>) policyClass, propertiesInfo);
            } catch (PropertyConfigurationException e) {
                logger.error("Cannot convert properties", e);
                throw new CMIInfoExtractorException("Cannot convert properties", e);
            }
        }
        return new ClusteredObjectInfo(
                itfClass, businessClass, clusterName, poolConfiguration,
                (Class<? extends IPolicy<?>>) policyClass,
                (Class<? extends IStrategy<?>>) strategyClass,
                policyProperties, stateful, replicated, applicationExceptionNames);
    }

    /**
     * Extract and convert properties from the objects instanced for the mapping with the xml deployment descriptor.
     * @param policyClass the class that defines the policy to retrieve the types of properties
     * @param propertiesInfo the objects instanced for the mapping with the xml deployment descriptor
     * @return properties extracted from the objects instanced for the mapping with the xml deployment descriptor
     * @throws PropertyConfigurationException if a property cannot be converted
     */
    private static Map<String, Object> extractProperties(
            final Class<? extends IPolicy<?>> policyClass, final PropertiesInfo propertiesInfo)
            throws PropertyConfigurationException {
        HashMap<String, Object> policyProperties = new HashMap<String, Object>();
        for(SimplePropertyInfo simplePropertyInfo : propertiesInfo.getSimplePropertyInfos()) {
            String propertyName = simplePropertyInfo.getName();
            String svalue = simplePropertyInfo.getValue();
            Object propertyValue = PolicyFactory.convertString(policyClass, propertyName, svalue);
            logger.debug("Adding pair ({0},{1})", propertyName, propertyValue);
            policyProperties.put(propertyName, propertyValue);
        }
        for(ArrayPropertyInfo arrayPropertyInfo : propertiesInfo.getArrayPropertyInfos()) {
            String propertyName = arrayPropertyInfo.getName();
            List<String> svalues = new ArrayList<String>();
            for(String lbValue : arrayPropertyInfo.getValues()) {
                svalues.add(lbValue);
            }
            List<?> propertyValues = PolicyFactory.convertStrings(policyClass, propertyName, svalues);
            logger.debug("Adding pair ({0},{1})", propertyName, propertyValues);
            policyProperties.put(propertyName, propertyValues);
        }
        return policyProperties;
    }

}
