/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id: RemoteCMIReferenceableWrapper.java 1659 2008-03-07 17:46:48Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.reference;

import java.io.InvalidObjectException;
import java.io.ObjectStreamException;
import java.rmi.Remote;

import javax.naming.NamingException;

import org.ow2.cmi.reference.CMIReference;

/**
 * Wrap a stub with the cmi reference on its associated remote object.
 * @author Loris Bouzonnet
 */
public class RemoteCMIReferenceableWrapper<T extends Remote> extends CMIReferenceableWrapper<T> {

    /**
     *  Id for serializable class.
     */
    private static final long serialVersionUID = 1192398491336031370L;

    private String ior;


    public RemoteCMIReferenceableWrapper(final CMIReference cmiRef, final T referencedObject) {
        super(cmiRef, referencedObject);
    }

    public RemoteCMIReferenceableWrapper(final CMIReference cmiRef, final String ior) {
        super(cmiRef, null);
        this.ior = ior;
    }

    @SuppressWarnings("unchecked")
    private Object readResolve() throws ObjectStreamException {
        CMIReference ref = getReference();
        if(ref.getServerRef().getProtocol().equals("iiop")) {
            T remote;
            try {
                remote = (T) Utility.string_to_remote(ior);
            } catch (NamingException e) {
                throw new InvalidObjectException("Cannot get the stub from the ior " + ior);
            }
            return new RemoteCMIReferenceableWrapper<T>(ref, remote);
        } else {
            return this;
        }
    }

    private Object writeReplace() throws ObjectStreamException {
        CMIReference ref = getReference();
        if(ref.getServerRef().getProtocol().equals("iiop")) {
            String ior;
            try {
                ior = Utility.remote_to_string(getReferencedObject());
            } catch (NamingException e) {
                throw new InvalidObjectException("Cannot get the ior from the stub " + getReferencedObject());
            }
            return new RemoteCMIReferenceableWrapper<T>(ref, ior);
        } else {
            return this;
        }
    }

}
