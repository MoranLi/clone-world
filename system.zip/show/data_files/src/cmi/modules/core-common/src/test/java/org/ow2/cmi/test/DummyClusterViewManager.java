/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007,2008 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id: DummyClusterViewManager.java 1695 2008-03-20 13:27:55Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.ejb.EJBObject;

import org.ow2.cmi.controller.common.ClusterViewManager;
import org.ow2.cmi.ha.SessionId;
import org.ow2.cmi.lb.policy.IPolicy;
import org.ow2.cmi.lb.strategy.IStrategy;
import org.ow2.cmi.reference.CMIReference;
import org.ow2.cmi.reference.CMIReferenceable;
import org.ow2.cmi.reference.ObjectNotFoundException;
import org.ow2.cmi.reference.ServerNotFoundException;
import org.ow2.cmi.reference.ServerRef;
import org.ow2.util.pool.api.IPoolConfiguration;
import org.ow2.util.pool.api.Pool;

/**
 * The dummy cluster view manager used for the test.
 * @author The new CMI team
 *
 */
public class DummyClusterViewManager implements ClusterViewManager {

    /**
     * The map of protocols and theirs corresponded factory name.
     */
    private Map<String, String> protofactoryname = new HashMap<String, String>();

    /**
     * The map of the object name and its corresponded interface name.
     */
    private Map<String, String> objandItfname = new HashMap<String, String>();

    /**
     * Returns a name of class that implements the interface InitialContextFactory for the given name of protocol.
     * @param protocolName a name of protocol
     * @return a name of class that implements the interface InitialContextFactory for the given name of protocol
     */
    public String getInitialContextFactoryName(final String protocolName){
        return this.protofactoryname.get(protocolName);
    }

    /**
     * Set the initial context factory name.
     * @param protocolName the given protocol name.
     * @param factoryName the initial context factory name.
     */
    public void setInitialContextFactoryName(final String protocolName,
            final String factoryName) {
        this.protofactoryname.put(protocolName, factoryName);
    }

    /**
     * Returns the interface of an object bound with the given name.
     * @param objectName a name of object
     * @return the interface of an object bound with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public Class<?> getInterface(final String objectName) throws ObjectNotFoundException {
        String itfname = this.objandItfname.get(objectName);
        try {
            return Class.forName("org.ow2.cmi.test.MyItf");
        } catch (ClassNotFoundException e) {
            throw new Error();
        }
    }

    /**
     * Set the object its interface name.
     * @param objectName the given object name.
     * @param itfName the given interface name.
     */
    public void setItfClassName(final String objectName, final String itfName){

        this.objandItfname.put(objectName, itfName);
    }

    /**
     * Adds an object with the given name to a set of objects that need to have their state up-to-date.
     * @param objectName a name of object
     * @throws ObjectNotFoundException if none object has the given name
     */
    public void addObjectToWatch(final String objectName) throws ObjectNotFoundException {
        // TODO Auto-generated method stub

    }

    /**
     * Returns a list of CMIReference for an object with the given name and protocol.
     * @param objectName a name of object
     * @param protocolName a name of protocol
     * @return a list of CMIReference for an object with the given name and protocol
     * @throws ObjectNotFoundException if none object has the given name for the given protocol
     */
    public List<CMIReference> getCMIReferences(final String objectName, final String protocolName)
    throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * Returns the name of cluster for the object with the given name.
     * @param objectName a name of object
     * @return the name of cluster for a object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public String getClusterName(final String objectName) throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * Returns the date of properties for an object with the given name.
     * @param objectName a name of object
     * @return the date of properties for an object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public long getDateOfProperties(final String objectName) throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return 0;
    }

    /**
     * Returns the time between each update of the cluster view by clients.
     * @return the time between each update of the cluster view by clients
     */
    public int getDelayToRefresh() {
        // TODO Auto-generated method stub
        return 0;
    }

    /**
     * Returns an instance of LB policy for the object that have the given name.
     * @param objectName a name of object
     * @return an instance of LB policy for the object that have the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public IPolicy<CMIReference> getPolicy(final String objectName) throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * Returns the class that defines the policy for an object with the given name.
     * @param objectName a name of object
     * @return the class that defines the policy for an object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public Class<? extends IPolicy<CMIReference>> getPolicyClass(final String objectName)
    throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * Returns the name of class of strategy for the object with the given name.
     * @param objectName a name of object
     * @return the name of class of strategy for the object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public String getPolicyClassName(final String objectName) throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * Returns the class that defines the strategy for an object with the given name.
     * @param objectName a name of object
     * @return the class that defines the strategy for an object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public Class<? extends IStrategy<CMIReference>> getStrategyClass(final String objectName)
    throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * Returns the name of class of strategy for the object with the given name.
     * @param objectName a name of object
     * @return the name of class of strategy for the object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public String getStrategyClassName(final String objectName) throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * Returns a pool of CMIReferenceable for an object with the given name.
     * @param objectName a name of object
     * @return a pool of CMIReferenceable for an object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public Pool<CMIReferenceable<?>, CMIReference> getPool(final String objectName) throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * Returns the properties of the LB policy for an object with the given name.
     * @param objectName a name of object
     * @return the properties of the LB policy for an object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public Map<String, Object> getPropertiesForPolicy(final String objectName) throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * Returns a value property of the LB policy for an object with the given name.
     * @param objectName a name of object
     * @param propertyName a name of property
     * @return a value property of the LB policy for an object with the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public Object getPropertyForPolicy(final String objectName, final String propertyName) throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * Returns true if the object with the specified name is clustered.
     * @param objectName a name of object
     * @return true if the object with the specified name is clustered
     */
    public boolean isClustered(final String objectName) {
        // TODO Auto-generated method stub
        return false;
    }

    /**
     * Returns true if the pool for object with the given name should be empty.
     * @param objectName a name of object
     * @return true if the pool for object with the given name should be empty
     * @throws ObjectNotFoundException if no object is bound with the given name
     */
    public boolean isPoolToEmpty(final String objectName) throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return false;
    }

    /**
     * Associates a name of object with a pool of CMIReferenceable.
     * @param objectName a name of object
     * @param pool a pool of CMIReferenceable
     * @throws ObjectNotFoundException if none object has the given name
     */
    public void setPool(final String objectName, final Pool<CMIReferenceable<?>, CMIReference> pool) throws ObjectNotFoundException {
        // TODO Auto-generated method stub

    }

    public int getLoadFactor(final ServerRef serverRef)
            throws ServerNotFoundException {
        // TODO Auto-generated method stub
        return 0;
    }

    public Class<? extends EJBObject> getRemoteClass(final String objectName)
            throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    public boolean isReplicated(final String objectName)
            throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return false;
    }

    public Pool<CMIReferenceable, CMIReference> getPoolForEJBObject(final String objectName)
            throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    public void setPoolForEJB2(final String objectName,
            final Pool<CMIReferenceable, CMIReference> pool)
            throws ObjectNotFoundException {
        // TODO Auto-generated method stub

    }

    public UUID getUUID() {
        // TODO Auto-generated method stub
        return null;
    }

    public SessionId getSessionId() {
        // TODO Auto-generated method stub
        return null;
    }

    public Set<String> getObjectNames() {
        // TODO Auto-generated method stub
        return null;
    }

    public Set<String> getProtocols() {
        // TODO Auto-generated method stub
        return null;
    }

    public ClassLoader getClassLoader(final String objectName)
            throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    public boolean hasState(final String objectName) throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return false;
    }

    public Set<String> getApplicationExceptionNames(final String objectName)
            throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    public IPoolConfiguration getPoolConfiguration(final String objectName)
            throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

}
