/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007,2008 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id:CMIReferenceableFactory.java 1114 2007-07-16 07:16:27Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.pool;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;

import net.jcip.annotations.ThreadSafe;

import org.ow2.cmi.controller.common.ClusterViewManager;
import org.ow2.cmi.reference.CMIReference;
import org.ow2.cmi.reference.CMIReferenceable;
import org.ow2.cmi.reference.CMIReferenceableWrapper;
import org.ow2.cmi.reference.ServerRef;
import org.ow2.util.log.Log;
import org.ow2.util.log.LogFactory;
import org.ow2.util.pool.api.PoolException;
import org.ow2.util.pool.impl.PoolEntryStatistics;
import org.ow2.util.pool.impl.PoolFactory;

/**
 * Provides methods for implementation of the pool for each lifecycle on an CMIReferencable.
 * @author The new CMI team
 */
@ThreadSafe
public class StubOrProxyFactory implements PoolFactory<CMIReferenceable<?>, CMIReference> {

    /**
     * Logger.
     */
    private static final Log LOGGER = LogFactory.getLog(StubOrProxyFactory.class);

    /**
     * Delegate to access at the cluster view.
     */
    private final ClusterViewManager clusterViewManager;

    /**
     * @param clusterViewManager a delegate to access at the cluster view
     */
    public StubOrProxyFactory(final ClusterViewManager clusterViewManager) {
        this.clusterViewManager = clusterViewManager;
    }

    /**
     * Creates an instance of CMIReferenceable with the given hint.
     * @param cmiReference a clue given by the Pool. Could be null.
     * @throws PoolException if instance cannot be created.
     * @return the created instance.
     */
    public CMIReferenceable<?> create(final CMIReference cmiReference) throws PoolException {

        ServerRef serverRef = cmiReference.getServerRef();
        String protocol = serverRef.getProtocol();
        // Get a context to perform a lookup
        Hashtable<String, Object> env = new Hashtable<String, Object>();
        env.put(Context.INITIAL_CONTEXT_FACTORY, clusterViewManager.getInitialContextFactoryName(protocol));
        env.put(Context.PROVIDER_URL, serverRef.getProviderURL());
        Context chosenContext;
        try{
            chosenContext = new InitialContext(env);
        } catch (NamingException e) {
            LOGGER.error("Cannot get a real context", e);
            throw new PoolException("Cannot get a real context", e);
        }
        if(chosenContext == null) {
            LOGGER.error("Cannot get a real context");
            throw new PoolException("Cannot get a real context");
        }

        // Get a JNDI name to perform a lookup
        String bindName = cmiReference.getObjectName();
        Class<?> interfaceClass;
        try {
            interfaceClass = clusterViewManager.getInterface(bindName);
        } catch (Exception e) {
            LOGGER.error("Cannot get interface for name {0}", bindName, e);
            throw new PoolException("Cannot get interface for name " + bindName, e);
        }

        // Lookup...
        Object object = null;
        try {
            LOGGER.debug("Lookup {0} on {1}", bindName, serverRef.getProviderURL());
            object = PortableRemoteObject.narrow(chosenContext.lookup(bindName), interfaceClass);
        } catch (NamingException e) {
            LOGGER.debug("No ClientClusterViewProvider is bound with the name {0} at the url {1}",
                    bindName, serverRef.getProviderURL(), e);
            throw new NamingPoolException(
                    "No ClientClusterViewProvider is bound with the name " + bindName
                    + " at the url "+serverRef.getProviderURL(), e);
        }

        // Construct a CMIReferenceable with the given CMIReference and the retrieved object
        return getCMIReferenceable(cmiReference, object);
    }

    /**
     * Checks if the given object with the given clue is matching.
     * @param cmiReferenceable given object against which the check should be done.
     * @param cmiReference the object used as clue to check the matching.
     * @return true if it is matching, else false.
     */
    public boolean isMatching(final CMIReferenceable<?> cmiReferenceable, final CMIReference cmiReference) {
        LOGGER.debug("{0} == {1} ?", cmiReferenceable.getReference(), cmiReference);
        return cmiReferenceable.getReference().equals(cmiReference);
    }

    /**
     * Callback called when object is gonna be removed.
     * @param cmiReferenceable that is being removed from the pool.
     */
    public void remove(final CMIReferenceable<?> cmiReferenceable) {
    }

    /**
     * Validate an instance by giving some statistics.
     * @param cmiReferenceable the instance to validate
     * @param stats some statistics to help in the validating process.
     * @return true if the element is valid, else false.
     */
    public boolean validate(final CMIReferenceable<?> cmiReferenceable, final PoolEntryStatistics stats) {
        return true;
    }

    protected CMIReferenceable<?> getCMIReferenceable(final CMIReference cmiRef, final Object stubOrProxy) {
        return new CMIReferenceableWrapper<Object>(cmiRef, stubOrProxy);
    }
}
