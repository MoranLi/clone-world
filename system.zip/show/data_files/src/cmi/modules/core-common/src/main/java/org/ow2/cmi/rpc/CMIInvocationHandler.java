/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007,2008 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id: CMIInvocationHandler.java 1664 2008-03-09 12:18:41Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.rpc;

import java.io.Serializable;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.ArrayList;
import java.util.List;

import net.jcip.annotations.ThreadSafe;

import org.ow2.cmi.controller.client.ClientClusterViewManager;
import org.ow2.cmi.controller.common.AbsClusterViewManager;
import org.ow2.cmi.controller.common.ClusterViewManager;
import org.ow2.cmi.controller.provider.ClientClusterViewProvider;
import org.ow2.cmi.controller.server.ServerClusterViewManager;
import org.ow2.cmi.lb.NoLoadBalanceableException;
import org.ow2.cmi.lb.decision.DecisionManager;
import org.ow2.cmi.lb.decision.DecisionManager.Decision;
import org.ow2.cmi.lb.policy.IPolicy;
import org.ow2.cmi.reference.CMIProxyHandle;
import org.ow2.cmi.reference.CMIReference;
import org.ow2.cmi.reference.CMIReferenceable;
import org.ow2.cmi.reference.ObjectNotFoundException;
import org.ow2.util.log.Log;
import org.ow2.util.log.LogFactory;

/**
 * An abstract implementation of the interface {@link InvocationHandler} allowing the choice of the mandatory to perform an invocation.
 * @param <T> the type of the remote object.
 * @author Loris Bouzonnet
 */
@ThreadSafe
public abstract class CMIInvocationHandler<T> implements InvocationHandler, Serializable {

    /**
     * Logger.
     */
    private static final Log LOGGER = LogFactory.getLog(CMIInvocationHandler.class);

    /**
     * The classloader to use for the invocation.
     */
    private transient ClassLoader classLoader;

    /**
     * A CMI handler is relative to a object.
     */
    protected final String objectName;

    /**
     * A CMI handler is relative to a protocol.
     */
    protected final String protocolName;

    /**
     * An instance of ClientClusterViewManager to access to the cluster view.
     */
    protected transient ClusterViewManager clusterViewManager;

    /**
     * The object to use for the invocation.
     */
    private CMIReferenceable<T> currentRef;

    /**
     * Interface of the object.
     */
    protected transient Class<? extends T> itf;

    /**
     * True if the previous object must be reused.
     */
    private boolean keepCurrentRef;

    /**
     * Keep a trace of the handle in order to update the HTTP session that reference it.
     */
    protected transient CMIProxyHandle cmiProxyHandle = null;


    /**
     * Construct an invocation handler allowing the choice of the mandatory to perform an invocation.
     * @param clusterViewManager an instance of ClientClusterViewManager to access to the cluster view
     * @param objectName the name of the object on which performing invocations
     * @param protocolName the protocol used to perform invocations
     * @param keepCurrentRef true if the previous object must be reused
     */
    protected CMIInvocationHandler(
            final ClusterViewManager clusterViewManager,
            final String objectName,
            final String protocolName,
            final boolean keepCurrentRef,
            final Class<? extends T> itf) {
        this.clusterViewManager = clusterViewManager;
        this.protocolName = protocolName;
        this.objectName = objectName;
        this.keepCurrentRef = keepCurrentRef;
        this.itf = itf;
    }

    /**
     * Set the classloader to use for the invocations
     * @param classLoader the classloader to use for the invocations
     */
    protected void setClassLoader(final ClassLoader classLoader) {
        this.classLoader = classLoader;
    }

    /**
     * Invoke a method through the CMI proxy.
     * @param proxy The proxy to use.
     * @param method The method to call.
     * @param args The arguments of the method.
     * @return the value to return from the method invocation on the proxy instance
     * @throws Throwable
     */
    @SuppressWarnings("unchecked")
    public Object invoke(final Object proxy, final Method method, final Object[] args) throws Throwable {

        if(clusterViewManager == null) {
            clusterViewManager = AbsClusterViewManager.getClusterViewManager();
        }
        if(classLoader == null) {
            classLoader = Thread.currentThread().getContextClassLoader();
        }
        if(itf == null) {
            try {
                itf = (Class<T>) clusterViewManager.getInterface(objectName);
            } catch (ObjectNotFoundException e) {
                LOGGER.error("Cannot retrieve the interface for object with name " + objectName, e);
                throw new CMIInvocationHandlerException(
                        "Cannot retrieve the interface for object with name " + objectName, e);
            }
        }
        checkInitialized();

        if (method.getDeclaringClass() == Object.class) {
            return invokeObjectMethod(proxy, method, args);
        } else {
            String methodName = method.getName();
            if(methodName.equals("getObjectName")) {
                return objectName;
            } else if(methodName.equals("getProtocolName")) {
                return protocolName;
            } else if(methodName.equals(getHandleMethodName())) {
                return getHandle((CMIProxy) proxy);
            }
            return invokeRemoteMethod(proxy, method, args);
        }
    }

    /**
     * Because a {@link CMIProxy} can be serialized, this method restores lazily the transient fields.
     * @throws CMIInvocationHandlerException if some fields cannot be retrieved
     */
    protected abstract void checkInitialized() throws CMIInvocationHandlerException;

    /**
     * Handles java.lang.Object methods.
     **/
    private Object invokeObjectMethod(final Object proxy, final Method method, final Object... args) {
        String name = method.getName();

        if (name.equals("hashCode")) {
            return new Integer(hashCode());

        } else if (name.equals("equals")) {
            Object obj = args[0];
            boolean b =
                proxy == obj
                || (obj != null
                        && Proxy.isProxyClass(obj.getClass())
                        && equals(Proxy.getInvocationHandler(obj)));
            return Boolean.valueOf(b);

        } else if (name.equals("toString")) {
            return proxyToString(proxy);

        } else {
            LOGGER.error("unexpected Object method: {0}", method);
            throw new IllegalArgumentException("unexpected Object method: " + method);
        }
    }

    /**
     * Returns a string representation for a proxy that uses this invocation
     * handler.
     **/
    protected String proxyToString(final Object proxy) {
        return "object:" + objectName
        + ", protocol:" + protocolName
        + ", object:" + currentRef
        + ", keepCurrentRef:" + keepCurrentRef
        + ", itf:" + itf;
    }

    @SuppressWarnings("unchecked")
    protected Object invokeRemoteMethod(
            final Object proxy, final Method method, final Object... args) throws Throwable {
        String methodName = method.getName();
        List<CMIReference> cmiReferences = null;
        IPolicy<CMIReference> policy = null;

        // Retrieve required data
        try {
            cmiReferences = new ArrayList<CMIReference>(clusterViewManager.getCMIReferences(objectName, protocolName));
            LOGGER.debug("Object:{0}-Invoke:{1}> CMIReferences:{2}", objectName, methodName, cmiReferences);
            policy = clusterViewManager.getPolicy(objectName);
            LOGGER.debug("Object:{0}-Invoke:{1}> Policy:{2}", objectName, methodName, policy);
        } catch (ObjectNotFoundException e) {
            // A client could have not downloaded the cluster view: don't throw exception for a client
            if(clusterViewManager instanceof ServerClusterViewManager) {
                throw new CMIInvocationHandlerException("Cannot get data for object with name " + objectName, e);
            }
        }

        if(clusterViewManager instanceof ClientClusterViewManager) {
            // If the LB policy or the node list is missing, we update the informations for this object
            synchronized (this) {
                if(cmiReferences == null || policy == null) {
                    LOGGER.debug("Object:{0}-Invoke:{1}> Forcing an update...", objectName, methodName);
                    ((ClientClusterViewManager) clusterViewManager).pullAndupdateObjectInfos(objectName);
                    cmiReferences =
                        new ArrayList<CMIReference>(clusterViewManager.getCMIReferences(objectName, protocolName));
                    LOGGER.debug("Object:{0}-Invoke:{1}> CMIReferences is now:{2}", objectName, methodName, cmiReferences);
                    policy = clusterViewManager.getPolicy(objectName);
                    LOGGER.debug("Object:{0}-Invoke:{1}> LBPolicy is now:{2}", objectName, methodName, policy);
                }
            }
        }

        CMIReference cmiReference;
        CMIReferenceable<T> cmiReferenceable;
        Object result;

        // While the invocation is not done and some mandatories are still available, try to invoke...
        do {
            cmiReference = null;
            cmiReferenceable = null;

            // Check if a previous mandatory should be reused
            if(keepCurrentRef && currentRef != null) {
                cmiReference = currentRef.getReference();
                cmiReferenceable = currentRef;
            }
            if(cmiReferenceable == null) {
                // Choose a new mandatory
                LOGGER.debug("Object:{0}-Invoke:{1}> Choosing a node...", objectName, methodName);
                try {
                    cmiReference = policy.choose(cmiReferences);
                } catch (NoLoadBalanceableException e) {
                    LOGGER.error("Invoke: {0} - Cannot get a CMIReference for objectname {1} and protocol {2}",
                            methodName, objectName, protocolName, e);
                    throw new CMIInvocationHandlerException(
                            "Invoke: " + methodName + " - Cannot get a CMIReference for objectname "
                            + objectName + " and protocol " + protocolName, e);
                }
                LOGGER.debug("Object:{0}-Invoke:{1}> Trying to get a CMIReferenceable for {1}...",
                        objectName, methodName, cmiReference);
                try {
                    // Get the CMIReferenceable stating for a proxy or a stub.
                    cmiReferenceable = getCMIReferenceable(cmiReference);
                    // Keep a trace of this mandatory
                    currentRef = cmiReferenceable;
                } catch (Exception e) {
                    LOGGER.debug("Invoke: {0} - onLookup Exception: ", methodName, e);
                    // Check if the policy allows failover
                    DecisionManager<Void> decisionManager = policy.onLookupException(cmiReference, e);
                    if(decisionManager.getDecision().equals(Decision.THROW)) {
                        // Failover is not allowed, rethrow the exception
                        LOGGER.debug("Invoke: {0} - Cannot get a CMIReferenceable for the CMIReference {1}",
                                methodName, cmiReference, e);
                        throw e.getCause();
                    }
                    // Failover is allowed, delete the last reference
                    LOGGER.debug("Invoke: {0} - Removing node {1}", methodName, cmiReference);
                    cmiReferences.remove(cmiReference);
                    currentRef = null;
                    // Check if others mandatories can be download
                    if(cmiReferences.isEmpty()) {
                        LOGGER.debug("Invoke: {0} - No more CMI reference - Throw: ", methodName, e);
                        // No more mandatory is available, rethrow the exception
                        throw e.getCause();
                    }
                    // Retry one more time...
                    continue;
                }
            }

            if(cmiReferenceable == null) {
                // Invalid state
                LOGGER.error("Invoke: {0} - The current manadatory for reference {1} should not be null !",
                        methodName, cmiReference);
                throw new CMIInvocationHandlerException(
                        "Invoke: " + methodName + " - The current manadatory for reference "
                        + cmiReference + " should not be null !");
            }

            // Perform the invocation
            preInvokeHook(cmiReferenceable);
            ClassLoader oldClassLoader = null;
            // Use the classloader dedicated to the invocation
            if(classLoader != null) {
                oldClassLoader = Thread.currentThread().getContextClassLoader();
                Thread.currentThread().setContextClassLoader(classLoader);
            }
            LOGGER.debug("Invoking {0}", methodName);
            try {
                try {
                    result = method.invoke(cmiReferenceable.getReferencedObject(), args);
                } finally {
                    // Reuse the previous classloader
                    if(classLoader != null) {
                        Thread.currentThread().setContextClassLoader(oldClassLoader);
                    }
                }
                postInvokeHook();
                break;
            } catch(Exception e) {
                LOGGER.debug("Invoke: {0} - onInvoke Exception: ", methodName, e);
                // Check if the policy allows failover
                DecisionManager<Void> decisionManager =
                    policy.onInvokeException(method, args, cmiReference, e);

                if(decisionManager.getDecision().equals(Decision.THROW)) {
                    // Failover is not allowed, rethrow the exception
                    LOGGER.debug("Throw: ", e);
                    throw e;
                }

                if(clusterViewManager instanceof ClientClusterViewManager && !itf.equals(ClientClusterViewProvider.class)) {
                    // Force a update of the node to avoid a reconnection on this bad server.
                    synchronized (this) {
                        LOGGER.debug("Object:{0}-Invoke:{1}> Forcing an update...", objectName, methodName);
                        ((ClientClusterViewManager) clusterViewManager).pullAndupdateObjectInfos(objectName);
                    }
                }

                cmiReferences =
                    new ArrayList<CMIReference>(clusterViewManager.getCMIReferences(objectName, protocolName));
                LOGGER.debug("Object:{0}-Invoke:{1}> CMIReferences is now:{2}", objectName, methodName, cmiReferences);

                // Delete the last reference
                LOGGER.debug("Invoke: {0} - Removing node {1}", methodName, cmiReference);
                cmiReferences.remove(cmiReference);

                currentRef = null;

                onExceptionHook(objectName, cmiReferenceable);

                // Check if others mandatories can be download
                if(cmiReferences.isEmpty()) {
                    LOGGER.debug("Invoke: {0} - No more CMI reference - Throw: ", methodName, e);
                    throw e;
                }
            } finally {
                onFinallyHook(objectName, cmiReferenceable);
            }
        } while(true);

        // Use the callback before returning the value
        DecisionManager<Object> decisionManager = policy.onReturn(method, args, cmiReference, result);
        if(cmiProxyHandle != null) {
            cmiProxyHandle = cmiProxyHandle.updateHttpSession();
        }
        return decisionManager.getRetVal();
    }

    /**
     * @return the object to use for the invocation
     */
    public CMIReferenceable<T> getCurrentRef() {
        return currentRef;
    }

    /**
     * Set the object to use for the invocation.
     * @param currentRef the object to use for the invocation
     */
    public void setCurrentRef(final CMIReferenceable<T> currentRef) {
        this.currentRef = currentRef;
    }

    /**
     * Preinvocation callback.
     * @param cmiReferenceable the mandatory that will be used for the invocation
     */
    protected void preInvokeHook(final CMIReferenceable<T> cmiReferenceable){}

    /**
     * Postinvocation callback.
     */
    protected void postInvokeHook(){}

    /**
     * Onexception callback.
     * @throws Exception
     */
    protected abstract void onExceptionHook(
            final String objectName, final CMIReferenceable<T> cmiReferenceable) throws Throwable;

    /**
     * @return the method name to get an handle
     */
    protected String getHandleMethodName() {
        return "getHandle";
    }

    /**
     * @param cmiProxy a cmi proxy
     * @return an handle for the given proxy
     */
    protected abstract CMIProxyHandle getHandle(CMIProxy cmiProxy);

    public void setCmiProxyHandle(final CMIProxyHandle cmiProxyHandle) {
        this.cmiProxyHandle = cmiProxyHandle;
    }

    protected abstract CMIReferenceable<T> getCMIReferenceable(CMIReference cmiReference) throws Exception;

    protected abstract void onFinallyHook(String objectName, CMIReferenceable<T> cmiReferenceable);

}
