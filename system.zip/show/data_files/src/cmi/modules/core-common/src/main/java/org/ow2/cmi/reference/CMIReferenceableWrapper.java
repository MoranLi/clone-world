/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id: CMIReferenceableWrapper.java 1659 2008-03-07 17:46:48Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.reference;

import org.ow2.cmi.reference.CMIReference;
import org.ow2.cmi.reference.CMIReferenceable;

/**
 * Define a wrapper in order to associate a stub or proxy with a {@link CMIReference}.
 * @author Loris Bouzonnet
 * @param <T> the type of surrogate
 */
public class CMIReferenceableWrapper<T> implements CMIReferenceable<T> {

    /**
     * Id for serializable class.
     */
    private static final long serialVersionUID = 5740798456454826029L;

    /**
     * A reference on its associated remote object.
     */
    private CMIReference cmiRef;

    /**
     * The surrogate object.
     */
    private T referencedObject;

    /**
     * Wrap a surrogate object with the reference on its associated remote object.
     * @param cmiRef a reference on its associated remote object
     * @param referencedObject the surrogate object
     */
    public CMIReferenceableWrapper(final CMIReference cmiRef, final T referencedObject) {
        this.cmiRef = cmiRef;
        this.referencedObject = referencedObject;
    }

    public CMIReference getReference() {
        return cmiRef;
    }

    public void setReference(final CMIReference cmiRef) {
        this.cmiRef = cmiRef;
    }

    public T getReferencedObject() {
        return referencedObject;
    }

    public void setReferencedObject(final T referencedObject) {
        this.referencedObject = referencedObject;
    }

    @Override
    public String toString() {
        return "CMIReferenceableWrapper[cmiRef:"
                + cmiRef + ", referencedObject:" + referencedObject + "]";
    }

    @Override
    public boolean equals(final Object obj) {
        if(obj == null || !(obj instanceof CMIReferenceable)) {
            return false;
        }
        CMIReferenceable<?> cmiReferenceable = (CMIReferenceable<?>) obj;
        return referencedObject.equals(cmiReferenceable.getReferencedObject());
    }

}
