/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id: PropertiesInfo.java 1664 2008-03-09 12:18:41Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.info.mapping;

import java.util.ArrayList;
import java.util.List;

import net.jcip.annotations.NotThreadSafe;

/**
 * Encapsulate properties for a policy of load-balancing.
 * @author Loris Bouzonnet
 */
@NotThreadSafe
public final class PropertiesInfo {

    /**
     * Simple properties.
     */
    private List<SimplePropertyInfo> simplePropertyInfos;

    /**
     * Array properties.
     */
    private List<ArrayPropertyInfo> arrayPropertyInfos;

    public PropertiesInfo() {
        simplePropertyInfos = new ArrayList<SimplePropertyInfo>();
        arrayPropertyInfos = new ArrayList<ArrayPropertyInfo>();
    }

    public void addSimplePropertyInfo(final SimplePropertyInfo simplePropertyInfo) {
        simplePropertyInfos.add(simplePropertyInfo);
    }

    /**
     * @return properties for a LB policy
     */
    public List<SimplePropertyInfo> getSimplePropertyInfos() {
        return simplePropertyInfos;
    }

    public void addArrayPropertyInfo(final ArrayPropertyInfo arrayPropertyInfo) {
        arrayPropertyInfos.add(arrayPropertyInfo);
    }

    /**
     * @return properties for a LB policy
     */
    public List<ArrayPropertyInfo> getArrayPropertyInfos() {
        return arrayPropertyInfos;
    }

    @Override
    public String toString() {
        return "PropertiesInfo["
            + "simplePropertyInfos:" + simplePropertyInfos
            + ",arrayPropertyInfos:" + arrayPropertyInfos
            + "]";
    }

}
