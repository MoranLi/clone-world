/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id: CMIThreadFactory.java 1659 2008-03-07 17:46:48Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.controller.common;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

import net.jcip.annotations.ThreadSafe;

import org.ow2.util.log.Log;
import org.ow2.util.log.LogFactory;

/**
 * Factory to create a new daemon for the managers of cluster view.
 * @author The new CMI team
 */
@ThreadSafe
public final class CMIThreadFactory implements ThreadFactory {

    /**
     * Logger.
     */
    private static final Log LOGGER = LogFactory.getLog(CMIThreadFactory.class);

    /**
     * Name of the manager of cluster view to use a common thread name.
     */
    private final String managerName;

    /**
     * Identifier of a created thread.
     */
    private static final AtomicInteger COUNTER = new AtomicInteger();

    /**
     * Creates a factory of thread for a given name of provider of cluster view.
     * @param managerName a name of provider of cluster view
     */
    public CMIThreadFactory(final String managerName) {
        this.managerName = managerName;
    }

    public Thread newThread(final Runnable r) {
        LOGGER.debug("Creating a new daemon...");
        Thread thread = new Thread(r, managerName+"-"+COUNTER.incrementAndGet());
        thread.setDaemon(true);
        thread.setUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            public void uncaughtException(final Thread t, final Throwable e) {
                LOGGER.error("UNCAUGHT in thread {0}", t.getName(), e);
            }
        });
        return thread;
    }

}
