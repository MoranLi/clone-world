/**
 * JOnAS: Java(TM) Open Application Server
 * Copyright (C) 1999-2007 Bull S.A.S.
 * Contact: jonas-team@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: Utility.java 1659 2008-03-07 17:46:48Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.reference;

import java.rmi.Remote;

import javax.ejb.spi.HandleDelegate;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.rmi.PortableRemoteObject;
import javax.rmi.CORBA.Util;

import org.omg.CORBA.ORB;
import org.omg.PortableServer.Servant;


/**
 * Utility class for System Value Classes.
 * @author pelletib
 */
public final class Utility  {

    /**
     * orb instance.
     */
    private static ORB orb = null;

    /**
     * Handledelegate.
     */
    private static HandleDelegate hdlDel = null;

    /**
     * private constructor.
     */
    private Utility() {
    }

    /**
     * Get the Handle Delegate implementation, registered in java:comp.
     * @return The HandleDelegate object.
     * @throws NamingException Cannot get the HandleDelegate
     */
    public static HandleDelegate getHandleDelegate() throws NamingException {
        if (hdlDel == null) {
            InitialContext ictx = new InitialContext();
            hdlDel = (HandleDelegate) ictx.lookup("java:comp/HandleDelegate");
        }
        return hdlDel;
     }
    /**
     * Get the Handle Delegate implementation, registered in java:comp.
     * @return The HandleDelegate object.
     * @throws NamingException Cannot get the HandleDelegate
     */
    public static ORB getORB() throws NamingException {
        if(orb == null) {
            InitialContext ictx = new InitialContext();
            orb = (ORB) PortableRemoteObject.narrow(ictx.lookup("java:comp/ORB"), ORB.class);
        }
        return orb;
    }

    public static String remote_to_string(final Remote remote) throws NamingException {
        Servant servant = (Servant) Util.getTie(remote);
        org.omg.CORBA.Object o = servant._this_object();
        return getORB().object_to_string(o);
    }

    public static Remote string_to_remote(final String ior) throws NamingException {
        return (Remote) PortableRemoteObject.narrow(
                getORB().string_to_object(ior), Remote.class);
    }
}
