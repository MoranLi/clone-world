/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2008 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id: DummyPolicy.java 1664 2008-03-09 12:18:41Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.test;

import java.net.URL;
import java.util.List;

import org.ow2.cmi.lb.LoadBalanceable;
import org.ow2.cmi.lb.NoLoadBalanceableException;
import org.ow2.cmi.lb.policy.AbstractPolicy;

/**
 * @param <T>
 * @author Loris Bouzonnet
 */
@SuppressWarnings("unchecked")
public class DummyPolicy<T extends LoadBalanceable> extends AbstractPolicy<T> {

    private String prop1;

    private int prop2;

    private List<Boolean> prop3;

    private List<Class<? extends List>> prop4;

    private List<URL> prop5;

    @Override
    public T choose(final List<T> loadBalanceables)
            throws NoLoadBalanceableException {
        return loadBalanceables.get(0);
    }

    public String getProp1() {
        return prop1;
    }

    public void setProp1(final String prop1) {
        this.prop1 = prop1;
    }

    public int getProp2() {
        return prop2;
    }

    public void setProp2(final int prop2) {
        this.prop2 = prop2;
    }

    public List<Boolean> getProp3() {
        return prop3;
    }

    public void setProp3(final List<Boolean> prop3) {
        this.prop3 = prop3;
    }

    public List<Class<? extends List>> getProp4() {
        return prop4;
    }

    public void setProp4(final List<Class<? extends List>> prop4) {
        this.prop4 = prop4;
    }

    public List<URL> getProp5() {
        return prop5;
    }

    public void setProp5(final List<URL> prop5) {
        this.prop5 = prop5;
    }

}
