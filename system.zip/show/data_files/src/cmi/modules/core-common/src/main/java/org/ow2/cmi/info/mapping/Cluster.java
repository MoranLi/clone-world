/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007,2008 Bull S.A.S.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: Cluster.java 1664 2008-03-09 12:18:41Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.info.mapping;

import net.jcip.annotations.NotThreadSafe;

import org.ow2.cmi.info.CMIInfoExtractor;
import org.ow2.util.pool.api.IPoolConfiguration;

/**
 * Contain informations on a clustered object.
 * @author The new CMI team
 * @see CMIInfoExtractor
 */
@NotThreadSafe
public final class Cluster {

    /**
     * Name of the object.
     */
    private String objectName;

    /**
     * Name of the cluster where is deployed this object.
     */
    private String clusterName;

    /**
     * Type of policy to use to access at this object.
     */
    private String policyType;

    /**
     * Type of strategy to use to access at this object.
     * Can be null if no strategy is used.
     */
    private String strategyType;

    /**
     * Properties of the policy.
     * All the values are not casted and are instance of the class String.
     * Used only for mapping xml<->object, so not used with annotation.
     * Null if the policy doesn't support properties.
     */
    private PropertiesInfo propertiesInfo;

    /**
     * Pool's configuration.
     */
    private IPoolConfiguration poolConfiguration = null;

    /**
     * Constructs an empty instance of ClusteredObjectInfo.
     */
    public Cluster() {
    }

    public String getObjectName() {
        return objectName;
    }

    public void setObjectName(final String objectName) {
        this.objectName = objectName;
    }

    /**
     * @return a name of the cluster where is deployed this object
     */
    public String getClusterName() {
        return clusterName;
    }

    /**
     * Set the cluster name that contains this clustered object.
     * @param clusterName the cluster name
     */
    public void setClusterName(final String clusterName) {
        this.clusterName = clusterName;
    }

    /**
     * @return the propertiesInfo
     */
    public PropertiesInfo getPropertiesInfo() {
        return propertiesInfo;
    }

    /**
     * @param propertiesInfo the propertiesInfo to set
     */
    public void setPropertiesInfo(final PropertiesInfo propertiesInfo) {
        this.propertiesInfo = propertiesInfo;
    }

    /**
     * @return the policyType
     */
    public String getPolicyType() {
        return policyType;
    }

    /**
     * @param policyType the policyType to set
     */
    public void setPolicyType(final String policyType) {
        this.policyType = policyType;
    }

    /**
     * @return the strategyType
     */
    public String getStrategyType() {
        return strategyType;
    }

    /**
     * @param strategyType the strategyType to set
     */
    public void setStrategyType(final String strategyType) {
        this.strategyType = strategyType;
    }

    /**
     * @return the configuration of the pool.
     */
    public IPoolConfiguration getPoolConfiguration() {
        return poolConfiguration;
    }

    /**
     * Sets the pool's configuration.
     * @param poolConfiguration the given configuration
     */
    public void setPoolConfiguration(final IPoolConfiguration poolConfiguration) {
        this.poolConfiguration = poolConfiguration;
    }

    @Override
    public String toString() {
        return "ClusteredObject["
            + "objectName:" + objectName
            + ",clusterName:" + clusterName
            + ",policyType:" + policyType
            + ",strategyType:" + strategyType
            + ",propertiesInfo:" + propertiesInfo
            + ",poolConfiguration:" + poolConfiguration
            + "]";
    }

}
