/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id: CMIInfoRepository.java 1659 2008-03-07 17:46:48Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.info;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.ow2.cmi.info.ClusteredObjectInfo;

import net.jcip.annotations.ThreadSafe;

/**
 * Represent repository of ClusteredObjectInfo.
 * @author The new CMI team
 */
@ThreadSafe
public final class CMIInfoRepository {

    /**
     * Private default constructor.
     */
    private CMIInfoRepository() {}

    /**
     * Repository of ClusteredObjectInfo.
     */
    private static final Map<String, ClusteredObjectInfo> clusteredObjectInfos =
        new ConcurrentHashMap<String, ClusteredObjectInfo>();

    /**
     * @param name a name of bound object
     * @param clusteredObjectInfo informations on clustering for the given name
     */
    public static void addClusteredObjectInfo(final String name, final ClusteredObjectInfo clusteredObjectInfo) {
        clusteredObjectInfos.put(name, clusteredObjectInfo);
    }

    /**
     * @param name a name of bound object
     * @return informations on clustering for the given name
     */
    public static ClusteredObjectInfo getClusteredObjectInfo(final String name) {
        return clusteredObjectInfos.get(name);
    }

    /**
     * @param name
     * @return
     */
    public static boolean containClusteredObjectInfo(final String name) {
        return clusteredObjectInfos.containsKey(name);
    }

}
