/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007,2008 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id: ClusteredClientClusterViewProvider.java 1695 2008-03-20 13:27:55Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.controller.provider;

import java.io.IOException;
import java.io.InputStream;
import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.rmi.PortableRemoteObject;

import net.jcip.annotations.ThreadSafe;

import org.ow2.cmi.annotation.Cluster;
import org.ow2.cmi.annotation.Policy;
import org.ow2.cmi.annotation.Strategy;
import org.ow2.cmi.controller.server.ServerClusterViewManager;
import org.ow2.cmi.lb.policy.FirstAvailable;
import org.ow2.cmi.lb.policy.IPolicy;
import org.ow2.cmi.lb.strategy.IStrategy;
import org.ow2.cmi.lb.strategy.LocalPreference;
import org.ow2.cmi.reference.CMIReference;
import org.ow2.cmi.reference.ObjectNotFoundException;
import org.ow2.cmi.reference.ServerNotFoundException;
import org.ow2.cmi.reference.ServerRef;
import org.ow2.util.log.Log;
import org.ow2.util.log.LogFactory;
import org.ow2.util.pool.api.IPoolConfiguration;

/**
 * Implementation of a clustered provider which offers cluster view to the clients.
 * @author The new CMI team
 */
@Cluster(name="System")
@Policy(FirstAvailable.class)
@Strategy(LocalPreference.class)
@ThreadSafe
public class ClusteredClientClusterViewProvider extends PortableRemoteObject implements ClientClusterViewProvider {

    /**
     * Logger.
     */
    private static Log logger = LogFactory.getLog(ClusteredClientClusterViewProvider.class);

    /**
     * A manager to get the cluster view.
     */
    private final ServerClusterViewManager serverClusterViewManager;

    /**
     * Buffer length.
     */
    private static final int BUF_APPEND = 1000;

    /**
     * Construct a ClusteredClientClusterViewProvider with the given LB policy.
     * @param serverClusterViewManager a manager to get the cluster view
     * @throws RemoteException if there are errors on the protocol
     */
    public ClusteredClientClusterViewProvider(final ServerClusterViewManager serverClusterViewManager) throws RemoteException {
        this.serverClusterViewManager = serverClusterViewManager;
    }

    /**
     * Gets the class of a given policy.
     * @param objectName a name of object
     * @return The corresponding policy class
     * @throws RemoteException if there are errors on the protocol
     * @throws ObjectNotFoundException if none object has the given name
     */
    public Class<? extends IPolicy<?>> getPolicyClass(final String objectName)
    throws RemoteException, ObjectNotFoundException {
        return serverClusterViewManager.getPolicyClass(objectName);
    }

    /**
     * Gets a class of strategy for the object with the given name.
     * @param objectName a name of object
     * @return a class of strategy for the object with the given name
     * @throws RemoteException if there are errors on the protocol
     * @throws ObjectNotFoundException if none object has the given name
     * @throws ObjectNotFoundException if the class cannot be loaded
     */
    public Class<? extends IStrategy<?>> getStrategyClass(final String objectName)
    throws RemoteException, ObjectNotFoundException {
        return serverClusterViewManager.getStrategyClass(objectName);
    }

    /**
     * Gets the nodes list of a given object and protocol.
     * @param objectName The name of object
     * @param protocolName The protocol of the client
     * @return The nodes list of the given object
     * @throws RemoteException if there are errors on the protocol
     * @throws ObjectNotFoundException if none object has the given name
     */
    public List<CMIReference> getCMIReferences(final String objectName, final String protocolName)
    throws RemoteException, ObjectNotFoundException {
        return serverClusterViewManager.getCMIReferences(objectName, protocolName);
    }

    /**
     * Gets the interface name for a given object.
     * @param objectName The name of object
     * @return The correspond interface name of the given object
     * @throws RemoteException if there are errors on the protocol
     * @throws ObjectNotFoundException if none object has the given name
     */
    public String getItfName(final String objectName) throws RemoteException, ObjectNotFoundException {
        return serverClusterViewManager.getItfName(objectName);
    }

    /**
     * Gets the business interface name for a given object.
     * @param objectName The name of object
     * @return the business interface name of the given object
     * @throws RemoteException if there are errors on the protocol
     * @throws ObjectNotFoundException if none object has the given name
     */
    public String getBusinessName(final String objectName) throws RemoteException, ObjectNotFoundException {
        return serverClusterViewManager.getBusinessName(objectName);
    }

    /**
     * Returns the properties for the object with the given name.
     * @param objectName a name of object
     * @return the properties for the object with the given name
     * @throws RemoteException if there are errors on the protocol
     * @throws ObjectNotFoundException if none object has the given name
     */
    public Map<String, Object> getPropertiesForPolicy(final String objectName)
    throws RemoteException, ObjectNotFoundException {
        return serverClusterViewManager.getPropertiesForPolicy(objectName);
    }

    /**
     * Returns the date of the last properties for a given object.
     * @param objectName a name of object
     * @return date of the last properties for a given object
     * @throws RemoteException if there are errors on the protocol
     * @throws ObjectNotFoundException if none object has the given name
     */
    public long getDateOfProperties(final String objectName) throws RemoteException, ObjectNotFoundException {
        return serverClusterViewManager.getDateOfProperties(objectName);
    }

    /**
     * Returns the bytecode of the class that has the given binary name.
     * @param binaryName a binary name of a class
     * @return the bytecode of the class that has the given binary name
     * @throws RemoteException if the connection failed
     * @throws ClientClusterViewProviderException if an I/O exception happens on server over the reading of the bytecode
     */
    public byte[] getBytecode(final String binaryName)
    throws RemoteException, ClientClusterViewProviderException {
        String encodedClassName = binaryName.replaceAll("\\.", "/").concat(".class");
        // Find the resource from the classloader
        InputStream inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(encodedClassName);
        byte[] bytecode = null;
        try {
            // Get bytecode of the class
            bytecode = readClass(inputStream);
            inputStream.close();
        } catch (IOException e) {
            logger.error("Cannot read class {0}", binaryName, e);
            throw new ClientClusterViewProviderException("Cannot read class "+binaryName, e);
        }
        return bytecode;
    }

    /**
     * Gets the bytes from the given input stream.
     * @param is given input stream.
     * @return the array of bytes for the given input stream.
     * @throws IOException if class cannot be read.
     */
    private static byte[] readClass(final InputStream is) throws IOException {
        if (is == null) {
            throw new IOException("Given input stream is null");
        }
        byte[] b = new byte[is.available()];
        int len = 0;
        while (true) {
            int n = is.read(b, len, b.length - len);
            if (n == -1) {
                if (len < b.length) {
                    byte[] c = new byte[len];
                    System.arraycopy(b, 0, c, 0, len);
                    b = c;
                }
                return b;
            }
            len += n;
            if (len == b.length) {
                byte[] c = new byte[b.length + BUF_APPEND];
                System.arraycopy(b, 0, c, 0, len);
                b = c;
            }
        }
    }

    /**
     * Returns true if the specified object is clustered.
     * @param name a name of object
     * @return true if the specified object is clustered
     * @throws RemoteException if there are errors on the protocol
     */
    public boolean isClustered(final String name) throws RemoteException {
        return serverClusterViewManager.isClustered(name);
    }

    /**
     * Return classnames of the application exceptions.
     * @param objectName a name of object
     * @return classnames of the application exceptions
     * @throws RemoteException if there are errors on the protocol
     * @throws ObjectNotFoundException if none object has the given name
     */
    public Set<String> getApplicationExceptions(final String objectName)
    throws RemoteException, ObjectNotFoundException {
        return serverClusterViewManager.getApplicationExceptionNames(objectName);
    }

    /**
     * Returns the name of the class of policy for the object with the given name.
     * @param objectName a name of object
     * @return the name of the class of policy for the object with the given name
     * @throws RemoteException if there are errors on the protocol
     * @throws ObjectNotFoundException if none object has the given name
     */
    public String getPolicyClassName(final String objectName) throws RemoteException, ObjectNotFoundException {
         return serverClusterViewManager.getPolicyClassName(objectName);
    }

    /**
     * Returns the delay to refresh the cluster view.
     * @return the delay to refresh the cluster view
     * @throws RemoteException if there are errors on the protocol
     */
    public int getDelayToRefresh() throws RemoteException {
       return serverClusterViewManager.getDelayToRefresh();
    }

    /**
     * Return  the name of cluster that contains the specified object.
     * @param objectName a name of object
     * @return the name of cluster that contains the specified object
     * @throws RemoteException if there are errors on the protocol
     * @throws ObjectNotFoundException if none object has the given name
     */
    public String getClusterName(final String objectName)
    throws RemoteException, ObjectNotFoundException {
            return serverClusterViewManager.getClusterName(objectName);
    }

    /**
     * Returns the configuration of pool of CMIReferenceable for a object with the given name.
     * @param objectName a name of object
     * @return the configuration of pool of CMIReferenceable for a object with the given name
     * @throws RemoteException  if there are errors on the protocol
     * @throws ObjectNotFoundException if none object has the given name
     */
    public IPoolConfiguration getPoolConfiguration(final String objectName)
    throws RemoteException, ObjectNotFoundException {
        return serverClusterViewManager.getPoolConfiguration(objectName);
    }

    /**
     * Returns the name of the class of strategy for the object with the given name.
     * @param objectName a name of object
     * @return the name of the class of strategy for the object with the given name
     * @throws RemoteException if there are errors on the protocol
     * @throws ObjectNotFoundException if none object has the given name
     */
    public String getStrategyClassName(final String objectName)
    throws RemoteException, ObjectNotFoundException {
        return serverClusterViewManager.getStrategyClassName(objectName);
    }

    /**
     * Returns true if the pool for object with the given name should be empty.
     * @param objectName a name of object
     * @return true if the pool for object with the given name should be empty
     * @throws RemoteException if there are errors on the protocol
     * @throws ObjectNotFoundException if none object has the given name
     * @throws ObjectNotFoundException if none object has the given name
     */
    public boolean isPoolToEmpty(final String objectName) throws RemoteException, ObjectNotFoundException {
        return serverClusterViewManager.isPoolToEmpty(objectName);
    }

    /**
     * Returns the load-factor for the server with the given address.
     * @param serverRef a reference on a server
     * @return the load-factor for the server with the given address
     * @throws RemoteException if there are errors on the protocol
     * @throws ServerNotFoundException if none server has the given address
     */
    public int getLoadFactor(final ServerRef serverRef) throws RemoteException, ServerNotFoundException {
        return serverClusterViewManager.getLoadFactor(serverRef);
    }

    /**
     * Register a new client (for statistic purposes).
     * @param uuid the Universally Unique Identifier of the client
     * @throws RemoteException if there are errors on the protocol
     */
    public void registerClient(final UUID uuid) throws RemoteException {
        serverClusterViewManager.registerClient(uuid);
    }

    /**
     * Return true if the object with the given name is replicated for high-availability.
     * @param objectName a name of object
     * @return true if the object with the given name is replicated for high-availability
     * @throws RemoteException if there are errors on the protocol
     * @throws ObjectNotFoundException if none object has the given name
     */
    public boolean isReplicated(final String objectName) throws RemoteException, ObjectNotFoundException {
        return serverClusterViewManager.isReplicated(objectName);
    }

    /**
     * Return true if the object with the given name is stateful
     * @param objectName a name of object
     * @return true if the object with the given name is stateful
     * @throws RemoteException if there are errors on the protocol
     * @throws ObjectNotFoundException if none object has the given name
     */
    public boolean hasState(final String objectName) throws RemoteException, ObjectNotFoundException {
        return serverClusterViewManager.hasState(objectName);
    }
}

