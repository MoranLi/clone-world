/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007,2008 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id: DummyClusterViewManager.java 1695 2008-03-20 13:27:55Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.lb.test;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import javax.ejb.EJBObject;

import org.ow2.cmi.controller.common.ClusterViewManager;
import org.ow2.cmi.ha.SessionId;
import org.ow2.cmi.lb.policy.IPolicy;
import org.ow2.cmi.lb.strategy.IStrategy;
import org.ow2.cmi.reference.CMIReference;
import org.ow2.cmi.reference.CMIReferenceable;
import org.ow2.cmi.reference.ObjectNotFoundException;
import org.ow2.cmi.reference.ServerNotFoundException;
import org.ow2.cmi.reference.ServerRef;
import org.ow2.util.pool.api.IPoolConfiguration;
import org.ow2.util.pool.api.Pool;

/**
 * The dummy cluster view manger that is used to get an object ClusterViewManager.
 * @author The new CMI team
 */

public class DummyClusterViewManager implements ClusterViewManager {

    public static String policy;

    public void addObjectToWatch(final String objectName) throws ObjectNotFoundException {
        // TODO Auto-generated method stub

    }

    public List<CMIReference> getCMIReferences(final String objectName, final String protocolName) throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    public String getClusterName(final String objectName) throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    public long getDateOfProperties(final String objectName) throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return 0;
    }

    public int getDelayToRefresh() {
        // TODO Auto-generated method stub
        return 0;
    }

    public String getInitialContextFactoryName(final String protocolName) {
        // TODO Auto-generated method stub
        return null;
    }

    public Class<?> getInterface(final String objectName) throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    public IPolicy<CMIReference> getPolicy(final String objectName) throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    @SuppressWarnings("unchecked")
    public Class<? extends IPolicy<CMIReference>> getPolicyClass(final String objectName) throws ObjectNotFoundException {
        try {
            return (Class<? extends IPolicy<CMIReference>>) Class.forName(getPolicyClassName(objectName));
        } catch (ClassNotFoundException e) {
            throw new Error();
        }
    }

    public String getPolicyClassName(final String objectName) throws ObjectNotFoundException {
        return policy;
    }

    @SuppressWarnings("unchecked")
    public Class<? extends IStrategy<CMIReference>> getStrategyClass(final String objectName) throws ObjectNotFoundException {
         try {
            return (Class<? extends IStrategy<CMIReference>>) Class.forName(getStrategyClassName(objectName));
        } catch (ClassNotFoundException e) {
            ;throw new Error();
        }
    }

    public String getStrategyClassName(final String objectName) throws ObjectNotFoundException {
        return "org.ow2.cmi.lb.strategy.LoadFactor";
    }

    public Pool<CMIReferenceable<?>, CMIReference> getPool(final String objectName) throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    public Map<String, Object> getPropertiesForPolicy(final String objectName) throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    public Object getPropertyForPolicy(final String objectName, final String propertyName) throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    public boolean isClustered(final String objectName) {
        // TODO Auto-generated method stub
        return false;
    }

    public boolean isPoolToEmpty(final String objectName) throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return false;
    }

    public void setPool(final String objectName, final Pool<CMIReferenceable<?>, CMIReference> pool) throws ObjectNotFoundException {
        // TODO Auto-generated method stub
    }

    public int getLoadFactor(final ServerRef serverRef)
            throws ServerNotFoundException {
        // TODO Auto-generated method stub
        return 0;
    }

    public Class<? extends EJBObject> getRemoteClass(final String objectName)
            throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    public boolean isReplicated(final String objectName)
            throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return false;
    }

    public Pool<CMIReferenceable, CMIReference> getPoolForEJBObject(final String objectName)
            throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    public void setPoolForEJB2(final String objectName,
            final Pool<CMIReferenceable, CMIReference> pool)
            throws ObjectNotFoundException {
        // TODO Auto-generated method stub

    }

    public UUID getUUID() {
        // TODO Auto-generated method stub
        return null;
    }

    public SessionId getSessionId() {
        // TODO Auto-generated method stub
        return null;
    }

    public Set<String> getObjectNames() {
        // TODO Auto-generated method stub
        return null;
    }

    public Set<String> getProtocols() {
        // TODO Auto-generated method stub
        return null;
    }

    public ClassLoader getClassLoader(final String objectName)
            throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    public boolean hasState(final String objectName) throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return false;
    }

    public Set<String> getApplicationExceptionNames(final String objectName)
            throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }

    public IPoolConfiguration getPoolConfiguration(final String objectName)
            throws ObjectNotFoundException {
        // TODO Auto-generated method stub
        return null;
    }
}

