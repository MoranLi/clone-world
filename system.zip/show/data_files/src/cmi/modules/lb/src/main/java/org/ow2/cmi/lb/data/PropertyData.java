/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007,2008 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id:LBPropertyData.java 1334 2007-10-19 14:44:36Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.lb.data;

import java.lang.reflect.Method;
import java.lang.reflect.Type;

import net.jcip.annotations.Immutable;

import org.ow2.cmi.lb.PropertyConfigurationException;
import org.ow2.cmi.lb.policy.IPolicy;
import org.ow2.util.log.Log;
import org.ow2.util.log.LogFactory;

/**
 * Encapsulate data relatives to a property.
 * @author The new CMI team
 */
@Immutable
public class PropertyData {

    /**
     * Logger.
     */
    private static Log logger = LogFactory.getLog(PropertyData.class);

    private final String propertyName;

    private final Class<? extends IPolicy<?>> policyClass;

    private final Type propertyType;

    private final Method getter;

    private final Method setter;


    public PropertyData(
            final Method getter,
            final Class<? extends IPolicy<?>> policyClass)
    throws PropertyConfigurationException {
        this.getter = getter;
        this.policyClass = policyClass;
        String formattedPropertyName = getter.getName().substring(3);
        propertyName =
            formattedPropertyName.substring(0, 1).toLowerCase()
            + formattedPropertyName.substring(1);
        propertyType = getter.getGenericReturnType();
        try {
            setter =
                policyClass.getDeclaredMethod(
                        "set" + formattedPropertyName, getter.getReturnType());
        } catch (Exception e) {
            logger.error(
                    "The class for name {0} doesn't contain a setter for property {1}",
                    policyClass.getName(), propertyName, e);
            throw new PropertyConfigurationException(
                    "The class for name " + policyClass.getName()+
                    "doesn't contain a setter for property " + propertyName, e);
        }
        Type[] parameterTypes = setter.getGenericParameterTypes();
        if(!parameterTypes[0].equals(propertyType)) {
            logger.error("Setter and getter doesn't have the same type !");
            throw new PropertyConfigurationException(
            "Setter and getter doesn't have the same type !");
        }
    }

    public String getPropertyName() {
        return propertyName;
    }

    public Class<? extends IPolicy<?>> getPolicyClass() {
        return policyClass;
    }

    public Type getPropertyType() {
        return propertyType;
    }

    public Method getGetter() {
        return getter;
    }

    public Method getSetter() {
        return setter;
    }

}
