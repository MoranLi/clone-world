/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007,2008 Bull S.A.S.
 * Contact: carol@ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
 * --------------------------------------------------------------------------
 * $Id: PolicyTest.java 1664 2008-03-09 12:18:41Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.lb.test;

import java.util.ArrayList;
import java.util.List;

import org.ow2.cmi.controller.common.ClusterViewManager;
import org.ow2.cmi.lb.policy.IPolicy;
import org.ow2.cmi.lb.util.PolicyFactory;
import org.ow2.cmi.reference.CMIReference;
import org.ow2.cmi.reference.ServerRef;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * Automatic test for LBPolicy.
 * @author The new CMI team
 */
public class PolicyTest {

    private ClusterViewManager clusterViewManager = new DummyClusterViewManager();

    private PolicyFactory<CMIReference> lbPolicyFactory = new PolicyFactory<CMIReference>(clusterViewManager);

     /**
     * Tests the policy FirstAvailable.
     * @throws ObjectNotFoundException
     * @throws PolicyFactoryException
     * @throws ObjectNotFoundException
     * @throws PolicyFactoryException
     * @throws ClassNotFoundException
     * @throws ClassNotFoundException
     */
    @SuppressWarnings("unchecked")
    @Test
    public void testLBPolicyFirstAvailable() throws Throwable {

        List<CMIReference> cmiReferences = new ArrayList<CMIReference>();
        IPolicy<CMIReference> lbPolicy;

            lbPolicy = lbPolicyFactory.createPolicy((Class<? extends IPolicy>)org.ow2.cmi.lb.policy.FirstAvailable.class);

            CMIReference cmiReference1 = new CMIReference(new ServerRef("jrmp","rmi://localhost:10020"),"haha");
            CMIReference cmiReference2 = new CMIReference(new ServerRef("jrmp","rmi://localhost:10021"),"haha");
            cmiReferences.add(cmiReference1);
            cmiReferences.add(cmiReference2);
            cmiReference1 = lbPolicy.choose(cmiReferences);
            cmiReference2 = lbPolicy.choose(cmiReferences);
            Assert.assertEquals(cmiReference2, cmiReference1);
    }

    /**
     * Tests the policy RoundRobin.
     * @throws ObjectNotFoundException
     * @throws PolicyFactoryException
     * @throws ObjectNotFoundException
     * @throws PolicyFactoryException
     * @throws ClassNotFoundException
     * @throws ClassNotFoundException
     */
    @SuppressWarnings("unchecked")
    @Test(dependsOnMethods = "testLBPolicyFirstAvailable")
    public void testLBPolicyRoundRobin() throws Throwable {

        List<CMIReference> cmiReferences = new ArrayList<CMIReference>();
        IPolicy<CMIReference> lbPolicy;

            lbPolicy = lbPolicyFactory.createPolicy((Class<? extends IPolicy>) org.ow2.cmi.lb.policy.RoundRobin.class);

            CMIReference cmiReference1 = new CMIReference(new ServerRef("jrmp","rmi://localhost:10023"),"hehe");
            CMIReference cmiReference2 = new CMIReference(new ServerRef("jrmp","rmi://localhost:10024"),"hehe");
            cmiReferences.add(cmiReference1);
            cmiReferences.add(cmiReference2);
            cmiReference1 = lbPolicy.choose(cmiReferences);
            cmiReference2 = lbPolicy.choose(cmiReferences);
            cmiReference2 = lbPolicy.choose(cmiReferences);
            Assert.assertEquals(cmiReference2, cmiReference1);
    }

//    /**
//     * Tests the strategy LoadFactor.
//     * @throws ObjectNotFoundException
//     * @throws LBPolicyFactoryException
//     * @throws ObjectNotFoundException
//     * @throws LBPolicyFactoryException
//     * @throws ClassNotFoundException
//     * @throws ClassNotFoundException
//     */
//    @Test(dependsOnMethods = "testLBPolicyRandom")
//    public void testStrategieLoadFactor() throws Throwable {
//
//        List<CMIReference> cmiReferences = new ArrayList<CMIReference>();
//        CMIReference cmiReference;
//        ILBPolicy<CMIReference> lbPolicy;
//            DummyClusterViewManager.policy = "org.ow2.cmi.lb.policy.RoundRobinPolicy";
//
//            lbPolicy = lbPolicyFactory.getLBPolicy("hihi");
//
//            CMIReference cmiReference1 = new CMIReference(new ServerRef("jrmp","rmi://localhost:10029"),"hihi");
//            CMIReference cmiReference2 = new CMIReference(new ServerRef("jrmp","rmi://localhost:10030"),"hihi");
//            cmiReferences.add(cmiReference1);
//            cmiReferences.add(cmiReference2);
//            cmiReference = lbPolicy.choose(cmiReferences);
//
//            cmiReference = lbPolicy.choose(cmiReferences);
//    }

//    /**
//     * Tests build a policy by LBPolicyFactory.
//     */
//    @Test(dependsOnMethods = "testStrategieLoadFactor")
//    public void testBuildPolicy() throws Throwable {
//
//        List<CMIReference> cmiReferences = new ArrayList<CMIReference>();
//        CMIReference cmiReference;
//        ILBPolicy<CMIReference> lbPolicy;
//            DummyClusterViewManager.policy = "org.ow2.cmi.lb.policy.FirstAvailablePolicy";
//
//            System.out.println("Build a policy by LBPolicyFactory ...");
//            lbPolicy = lbPolicyFactory.getLBPolicy("hihi");
//
//            System.out.println("Compare the policy with the policy init: " +
//                    DummyClusterViewManager.policy.equals(lbPolicy.getClass().getName()));
//
//    }
}
