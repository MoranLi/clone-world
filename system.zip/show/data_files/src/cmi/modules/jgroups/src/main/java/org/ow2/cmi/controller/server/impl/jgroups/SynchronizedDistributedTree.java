/**
 * CMI : Cluster Method Invocation
 * Copyright (C) 2007,2008 Bull S.A.S.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: SynchronizedDistributedTree.java 1659 2008-03-07 17:46:48Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.cmi.controller.server.impl.jgroups;


import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jgroups.Address;
import org.jgroups.Channel;
import org.jgroups.JChannel;
import org.jgroups.MembershipListener;
import org.jgroups.Message;
import org.jgroups.MessageListener;
import org.jgroups.View;
import org.jgroups.blocks.GroupRequest;
import org.jgroups.blocks.MethodCall;
import org.jgroups.blocks.RpcDispatcher;
import org.jgroups.util.Util;
import org.ow2.externals.jgroups.IDistributedTree;

import java.io.Serializable;
import java.util.StringTokenizer;
import java.util.Vector;


/**
 * A tree-like structure that is replicated across several members. Updates will be multicast to all group
 * members reliably and in the same order.
 * @author Bela Ban
 * @author <a href="mailto:aolias@yahoo.com">Alfonso Olias-Sanz</a>
 */
public final class SynchronizedDistributedTree
implements MessageListener, MembershipListener, IDistributedTree, IIntercepted {

    private volatile Node root=null;
    private final Vector<DistributedTreeListener> listeners=new Vector<DistributedTreeListener>();
    private final Vector<ViewListener> view_listeners=new Vector<ViewListener>();
    private final Vector<Address> members=new Vector<Address>();
    private volatile Channel channel=null;
    private volatile RpcDispatcher disp=null;
    // rc is global and protected so that extensions can detect when
    // state has been transferred
    private volatile boolean rc = false;
    private volatile String groupname="SynchronizedDistributedTreeGroup";
    private volatile String channel_properties="UDP(mcast_addr=228.1.2.3;mcast_port=45566;ip_ttl=0):" +
    "PING(timeout=5000;num_initial_members=6):" +
    "FD_SOCK:" +
    "VERIFY_SUSPECT(timeout=1500):" +
    "pbcast.STABLE(desired_avg_gossip=10000):" +
    "pbcast.NAKACK(gc_lag=5;retransmit_timeout=3000;trace=true):" +
    "UNICAST(timeout=5000):" +
    "FRAG(down_thread=false;up_thread=false):" +
    "pbcast.GMS(join_timeout=5000;" +
    "shun=false;print_local_addr=true):" +
    // trace=true is not supported anymore
    "pbcast.STATE_TRANSFER()";

    /** Determines when the updates have to be sent across the network, avoids sending unnecessary
     * messages when there are no member in the group */

    // Make this protected so that extensions
    // can control whether or not to send
    private volatile boolean send_message = false;

    private static final Log log=LogFactory.getLog(SynchronizedDistributedTree.class);

    /**
     * A mutex.
     */
    private final Object lock = new Object();


    public SynchronizedDistributedTree() {
    }


    public SynchronizedDistributedTree(String groupname, String channel_properties) {
        this.groupname=groupname;
        if(channel_properties != null)
            this.channel_properties=channel_properties;
    }

    public Address getLocalAddress() {
        return channel != null? channel.getLocalAddress() : null;
    }

    public void setDeadlockDetection(boolean flag) {
        if(disp != null)
            disp.setDeadlockDetection(flag);
    }

    /* (non-Javadoc)
     * @see org.ow2.cmi.controller.server.impl.jgroups.IDistributedTree#start()
     */
    public void start() throws Exception {
        start(8000);
    }


    /* (non-Javadoc)
     * @see org.ow2.cmi.controller.server.impl.jgroups.IDistributedTree#start(long)
     */
    public void start(long timeout) throws Exception {
        if(channel != null) // already started
            return;
        channel = new JChannel(channel_properties);

        // Set the auto-reconnect option for enabling a node to leave and re-join the cluster
        channel.setOpt(Channel.AUTO_RECONNECT, true);

        disp = new RpcDispatcher(channel, this, this, this);
        channel.connect(groupname);
        rc = channel.getState(null, timeout);
        if(rc) {
            if(log.isInfoEnabled()) log.info("state was retrieved successfully");
        }
        else
            if(log.isInfoEnabled()) log.info("state could not be retrieved (must be first member in group)");
    }


    /* (non-Javadoc)
     * @see org.ow2.cmi.controller.server.impl.jgroups.IDistributedTree#stop()
     */
    public void stop() {
        if(channel != null) {
            channel.close();
            disp.stop();
        }
        channel=null;
        disp=null;
    }


    public void addDistributedTreeListener(IDistributedTree.DistributedTreeListener listener) {
        if(!listeners.contains(listener))
            listeners.addElement(listener);
    }


    public void removeDistributedTreeListener(IDistributedTree.DistributedTreeListener listener) {
        listeners.removeElement(listener);
    }


    public void addViewListener(ViewListener listener) {
        if(!view_listeners.contains(listener))
            view_listeners.addElement(listener);
    }


    public void removeViewListener(ViewListener listener) {
        view_listeners.removeElement(listener);
    }


    /* (non-Javadoc)
     * @see org.ow2.cmi.controller.server.impl.jgroups.IDistributedTree#add(java.lang.String)
     */
    public void add(String fqn) {
        //Changes done by <aos>
        //if true, propagate action to the group
        if(send_message == true) {
            try {
                MethodCall call = new MethodCall("_add", new Object[] {fqn}, new String[] {String.class.getName()});
                disp.callRemoteMethods(null, call, GroupRequest.GET_ALL, 0);
            }
            catch(Exception ex) {
                if(log.isErrorEnabled()) log.error("exception=" + ex);
            }
        }
        else {
            _add(fqn);
        }
    }

    /* (non-Javadoc)
     * @see org.ow2.cmi.controller.server.impl.jgroups.IDistributedTree#add(java.lang.String, java.io.Serializable)
     */
    public void add(String fqn, Serializable element) {
        add(fqn, element, 0);
    }

    /* (non-Javadoc)
     * @see org.ow2.cmi.controller.server.impl.jgroups.IDistributedTree#reset(java.lang.String, java.io.Serializable)
     */
    public void reset(String fqn, Serializable element)
    {
        reset(fqn, element, 0);
    }

    /* (non-Javadoc)
     * @see org.ow2.cmi.controller.server.impl.jgroups.IDistributedTree#remove(java.lang.String)
     */
    public void remove(String fqn) {
        remove(fqn, 0);
    }

    /* (non-Javadoc)
     * @see org.ow2.cmi.controller.server.impl.jgroups.IDistributedTree#add(java.lang.String, java.io.Serializable, int)
     */
    public void add(String fqn, Serializable element, int timeout) {
        //Changes done by <aos>
        //if true, propagate action to the group
        if(send_message == true) {
            try {
                MethodCall call = new MethodCall("_add", new Object[] {fqn, element},
                        new String[] {String.class.getName(), Serializable.class.getName()});
                disp.callRemoteMethods(null, call, GroupRequest.GET_ALL, timeout);
            }
            catch(Exception ex) {
                if(log.isErrorEnabled()) log.error("exception=" + ex);
            }
        }
        else {
            _add(fqn, element);
        }
    }

    /* (non-Javadoc)
     * @see org.ow2.cmi.controller.server.impl.jgroups.IDistributedTree#reset(java.lang.String, java.io.Serializable, int)
     */
    public void reset(String fqn, Serializable element, int timeout)
    {
        //Changes done by <aos>
        //if true, propagate action to the group
        if(send_message == true) {
            try {
                MethodCall call = new MethodCall("_reset", new Object[] {fqn, element},
                        new String[] {String.class.getName(), Serializable.class.getName()});
                disp.callRemoteMethods(null, call, GroupRequest.GET_ALL, timeout);
            }
            catch(Exception ex) {
                if(log.isErrorEnabled()) log.error("exception=" + ex);
            }
        }
        else {
            _reset(fqn, element);
        }
    }

    /* (non-Javadoc)
     * @see org.ow2.cmi.controller.server.impl.jgroups.IDistributedTree#remove(java.lang.String, int)
     */
    public void remove(String fqn, int timeout) {
        //Changes done by <aos>
        //if true, propagate action to the group
        if(send_message == true) {
            try {
                MethodCall call = new MethodCall("_remove", new Object[] {fqn}, new String[] {String.class.getName()});
                disp.callRemoteMethods(null, call, GroupRequest.GET_ALL, timeout);
            }
            catch(Exception ex) {
                if(log.isErrorEnabled()) log.error("exception=" + ex);
            }
        }
        else {
            _remove(fqn);
        }
    }


    /* (non-Javadoc)
     * @see org.ow2.cmi.controller.server.impl.jgroups.IDistributedTree#exists(java.lang.String)
     */
    public boolean exists(String fqn) {
        synchronized (lock) {
            return fqn != null && (findNode(fqn) != null);
        }
    }


    /* (non-Javadoc)
     * @see org.ow2.cmi.controller.server.impl.jgroups.IDistributedTree#get(java.lang.String)
     */
    public Serializable get(String fqn) {
        Node n=null;
        if(fqn == null) return null;
        synchronized (lock) {
            n=findNode(fqn);
            if(n != null) {
                return n.element;
            }
        }
        return null;
    }


    /* (non-Javadoc)
     * @see org.ow2.cmi.controller.server.impl.jgroups.IDistributedTree#set(java.lang.String, java.io.Serializable)
     */
    public void set(String fqn, Serializable element) {
        set(fqn, element, 0);
    }

    /* (non-Javadoc)
     * @see org.ow2.cmi.controller.server.impl.jgroups.IDistributedTree#set(java.lang.String, java.io.Serializable, int)
     */
    public void set(String fqn, Serializable element, int timeout) {
        //Changes done by <aos>
        //if true, propagate action to the group
        if(send_message == true) {
            try {
                MethodCall call = new MethodCall("_set", new Object[] {fqn, element},
                        new String[] {String.class.getName(), Serializable.class.getName()});
                disp.callRemoteMethods(null, call, GroupRequest.GET_ALL, timeout);
            }
            catch(Exception ex) {
                if(log.isErrorEnabled()) log.error("exception=" + ex);
            }
        }
        else {
            _set(fqn, element);
        }
    }


    /** Returns all children of a Node as strings */
    public Vector<String> getChildrenNames(String fqn) {
        Vector<String> ret=new Vector<String>();
        Node n;

        if(fqn == null) return ret;
        synchronized (lock) {
            n=findNode(fqn);
            if(n == null || n.children == null) return ret;
            for(Node child : n.children)
                ret.addElement(child.name);
        }
        return ret;
    }


    public String print() {
        StringBuilder sb=new StringBuilder();
        int indent=0;

        synchronized (lock) {
            if(root == null)
                return "/";

            sb.append(root.print(indent));
        }
        return sb.toString();
    }


    /**
     * Returns the name of the group that the DistributedTree is connected to
     * @return String
     */
    public String  getGroupName()           {return groupname;}

    /**
     * Returns the Channel the DistributedTree is connected to
     * @return Channel
     */
    public Channel getChannel()             {return channel;}

    /**
     * Returns the number of current members joined to the group
     * @return int
     */
    public int getGroupMembersNumber()			{return members.size();}




    /*--------------------- Callbacks --------------------------*/

    public void _add(String fqn) {
        _add(fqn, null);
    }


    public void _add(String fqn, Serializable element) {
        Node curr, n;
        StringTokenizer tok;
        String child_name;
        String tmp_fqn="";

        synchronized (lock) {
            if(root == null) {
                root=new Node("/", null);
                notifyNodeAdded("/", null);
            }
            if(fqn == null)
                return;
            curr=root;
            tok=new StringTokenizer(fqn, "/");

            while(tok.hasMoreTokens()) {
                child_name=tok.nextToken();
                tmp_fqn=tmp_fqn + '/' + child_name;
                n=curr.findChild(child_name);
                if(n == null) {
                    n=new Node(child_name, null);
                    curr.addChild(n);
                    if(!tok.hasMoreTokens()) {
                        n.element=element;
                        notifyNodeAdded(tmp_fqn, element);
                        return;
                    }
                    else
                        notifyNodeAdded(tmp_fqn, null);
                }
                curr=n;
            }
            // If the element is not null, we install it and notify the
            // listener app that the node is modified.
            if(curr.element == null && element != null){
                curr.element=element;
                notifyNodeModified(fqn, null, element);
            } else if(curr.element != null) {
                log.debug("Cannot add " + element + " at "
                        + tmp_fqn + " because " + curr.element + " exists");
            }
        }
    }


    public void _remove(String fqn) {
        Node curr, n;
        StringTokenizer tok;
        String child_name=null;

        synchronized (lock) {
            if(fqn == null || root == null)
                return;
            curr=root;
            tok=new StringTokenizer(fqn, "/");

            while(tok.countTokens() > 1) {
                child_name=tok.nextToken();
                n=curr.findChild(child_name);
                if(n == null) // node does not exist
                    return;
                curr=n;
            }
            try {
                child_name=tok.nextToken();
                if(child_name != null) {
                    n=curr.removeChild(child_name);
                    if(n != null)
                        notifyNodeRemoved(fqn);
                }
            }
                catch(Exception ex) {
            }
        }
    }


    public void _set(String fqn, Serializable element) {
        Node n;
        Serializable old_el=null;

        synchronized (lock) {
            if(fqn == null || element == null) return;
            n=findNode(fqn);
            if(n == null) {
                if(log.isErrorEnabled()) log.error("node " + fqn + " not found");
                return;
            }
            old_el=n.element;
            n.element=element;
            notifyNodeModified(fqn, old_el, element);
        }
    }

    /** similar to set, but does not error if node does not exist, but rather does an add instead */
    public void _reset(String fqn, Serializable element) {
        Node n;
        Serializable old_el=null;

        synchronized (lock) {
            if(fqn == null || element == null) return;
            n=findNode(fqn);
            if(n == null) {
                _add(fqn, element);
            }
            else {
                old_el=n.element;
                n.element=element;
            }
            notifyNodeModified(fqn, old_el, element);
        }
    }

    /*----------------- End of  Callbacks ----------------------*/


    /*-------------------- State Exchange ----------------------*/

    public void receive(Message msg) {
    }

    /** Return a copy of the tree */
    public byte[] getState() {
        Object copy=root != null? root.copy() : null;
        try {
            return Util.objectToByteBuffer(copy);
        }
        catch(Throwable ex) {
            if(log.isErrorEnabled()) log.error("exception marshalling state: " + ex);
            return null;
        }
    }

    public void setState(byte[] data) {
        Object new_state;

        try {
            new_state=Util.objectFromByteBuffer(data);
        }
        catch(Throwable ex) {
            if(log.isErrorEnabled()) log.error("exception unmarshalling state: " + ex);
            return;
        }
        if(new_state == null) return;
        if(!(new_state instanceof Node)) {
            if(log.isErrorEnabled()) log.error("object is not of type 'Node'");
            return;
        }
        root=((Node)new_state).copy();

        // State transfer needs to notify listeners in the new
        // cluster member about everything that exists.  This
        // is working ok now.
        this.notifyAllNodesCreated(root, "");
    }



    /*------------------- Membership Changes ----------------------*/

    public void viewAccepted(View new_view) {
        Vector<Address> new_mbrs=new_view.getMembers();

        if(new_mbrs != null) {
            sendViewChangeNotifications(new_mbrs, members); // notifies observers (joined, left)
            members.removeAllElements();
            for(Address mbr : new_mbrs)
                members.addElement(mbr);
        }
        //if size is bigger than one, there are more peers in the group
        //otherwise there is only one server.
        send_message=true;
        send_message=members.size() > 1;
    }


    /** Called when a member is suspected */
    public void suspect(Address suspected_mbr) {
    }


    /** Block sending and receiving of messages until ViewAccepted is called */
    public void block() {
    }


    void sendViewChangeNotifications(Vector<Address> new_mbrs, Vector<Address> old_mbrs) {
        Vector<Address> joined, left;

        if(view_listeners.isEmpty() || old_mbrs == null || new_mbrs == null)
            return;


        // 1. Compute set of members that joined: all that are in new_mbrs, but not in old_mbrs
        joined=new Vector<Address>();
        for(Address mbr : new_mbrs) {
            if(!old_mbrs.contains(mbr))
                joined.addElement(mbr);
        }


        // 2. Compute set of members that left: all that were in old_mbrs, but not in new_mbrs
        left=new Vector<Address>();
        for(Address mbr : old_mbrs) {
            if(!new_mbrs.contains(mbr))
                left.addElement(mbr);
        }
        notifyViewChange(joined, left);
    }


    private Node findNode(String fqn) {
        Node curr=root;
        StringTokenizer tok;
        String child_name;

        if(fqn == null || root == null) return null;
        if("/".equals(fqn) || "".equals(fqn))
            return root;

        tok=new StringTokenizer(fqn, "/");
        while(tok.hasMoreTokens()) {
            child_name=tok.nextToken();
            curr=curr.findChild(child_name);
            if(curr == null) return null;
        }
        return curr;
    }


    void notifyNodeAdded(String fqn, Serializable element) {
        for(DistributedTreeListener distributedTreeListener : listeners)
            distributedTreeListener.nodeAdded(fqn, element);
    }

    void notifyNodeRemoved(String fqn) {
        for(DistributedTreeListener distributedTreeListener : listeners)
            distributedTreeListener.nodeRemoved(fqn);
    }

    void notifyNodeModified(String fqn, Serializable old_element, Serializable new_element) {
        for(DistributedTreeListener distributedTreeListener : listeners)
            distributedTreeListener.nodeModified(fqn, old_element, new_element);
    }

    /** Generates NodeAdded notifications for all nodes of the tree. This is called whenever the tree is
     initially retrieved (state transfer) */
    void notifyAllNodesCreated(Node curr, String tmp_fqn) {
        // We need a local string here to handle the empty string (root)
        // otherwise, we start off with two slashes in the path.
        String path = "";
        if(curr == null) return;
        if(curr.name == null) {
            if(log.isErrorEnabled()) log.error("curr.name is null");
            return;
        }
        // If we're the root node, then we supply a "starter" slash.
        // This lets us properly initiate the recursion with an empty
        // string, and then prepend a slash for each additional depth
        path = (curr.equals(root)) ? "/" : tmp_fqn;

        // Recursion must occur _before_ we look for children, or we
        // never notifyNodeAdded() for leaf nodes.
        notifyNodeAdded(path, curr.element);
        if(curr.children != null) {
            for(Node n : curr.children) {
                log.debug("*** nodeCreated(): tmp_fqn is " + tmp_fqn);
                notifyAllNodesCreated(n, tmp_fqn + '/' + n.name);
            }
        }
    }


    void notifyViewChange(Vector<Address> new_mbrs, Vector<Address> old_mbrs) {
        for(ViewListener viewListener : view_listeners)
            viewListener.viewChange(new_mbrs, old_mbrs);
    }


    private static class Node implements Serializable {
        final String name;
        volatile Vector<Node> children=null;
        volatile Serializable element=null;
        private static final long serialVersionUID=-635336369135391033L;


        Node(String name, Serializable element) {
            this.name=name;
            this.element=element;
        }


        void addChild(String relative_name, Serializable element) {
            if(relative_name == null)
                return;
            if(children == null)
                children=new Vector<Node>();
            else {
                if(!children.contains(relative_name))
                    children.addElement(new Node(relative_name, element));
            }
        }


        void addChild(Node n) {
            if(n == null) return;
            if(children == null)
                children=new Vector<Node>();
            if(!children.contains(n))
                children.addElement(n);
        }


        Node removeChild(String rel_name) {
            Node n=findChild(rel_name);

            if(n != null)
                children.removeElement(n);
            return n;
        }


        Node findChild(String relative_name) {
            if(children == null || relative_name == null)
                return null;
            for(Node child : children) {
                if(child.name == null) {
                    if(log.isErrorEnabled()) log.error("child.name is null for " + relative_name);
                    continue;
                }

                if(child.name.equals(relative_name))
                    return child;
            }

            return null;
        }

        @Override
        public boolean equals(Object other) {
            return other != null && ((Node)other).name != null && name != null && name.equals(((Node)other).name);
        }


        @SuppressWarnings("unchecked")
        Node copy() {
            Node ret=new Node(name, element);

            if(children != null)
                ret.children=(Vector<Node>)children.clone();
            return ret;
        }


        String print(int indent) {
            StringBuilder sb=new StringBuilder();
            boolean is_root=name != null && "/".equals(name);

            for(int i=0; i < indent; i++)
                sb.append(' ');
            if(!is_root) {
                if(name == null)
                    sb.append("/<unnamed>");
                else {
                    sb.append('/' + name);
                    // if(element != null) sb.append(" --> " + element);
                }
            }
            sb.append('\n');
            if(children != null) {
                if(is_root)
                    indent=0;
                else
                    indent+=4;
                for(Node child : children)
                    sb.append(child.print(indent));
            }
            return sb.toString();
        }

        @Override
        public String toString() {
            if(element != null)
                return "[name: " + name + ", element: " + element + ']';
            else
                return "[name: " + name + ']';
        }

    }

}
