/**
 * Copyright (C) 2002-2007 - INRIA (www.inria.fr)
 *
 * CAROL: Common Architecture for RMI ObjectWeb Layer
 *
 * This library is developed inside the OW2 Consortium,
 * http://www.ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: ProtocolInterceptorInitializer.java 1272 2007-09-11 11:43:56Z loris $
 * --------------------------------------------------------------------------
 */
package org.ow2.carol.rmi.jrmp.interceptor.protocol;

// carol import
import org.ow2.carol.rmi.jrmp.interceptor.api.JInitInfo;
import org.ow2.carol.rmi.jrmp.interceptor.spi.JInitializer;
import org.ow2.carol.util.configuration.TraceCarol;

/**
 * Class <code>ProtocolInterceptorInitializer</code> is a JRMP Interface for
 * Interceptor initialization This initializer add an interceptor for the multi
 * rmi management
 * @author Guillaume Riviere (Guillaume.Riviere@inrialpes.fr)
 * @version 1.0, 15/07/2002
 */
public class ProtocolInterceptorInitializer implements JInitializer {

    /**
     * In JRMP the 2 methods (pre and post init) have the same consequences...
     * @param JInitInfo the JInit Information
     */
    public void pre_init(JInitInfo info) {
        try {
            info.add_server_request_interceptor(new ProtocolInterceptor());
        } catch (Exception e) {
            TraceCarol.error(
                    "ProtocolInterceptorInitializer.pre_init(JInitInfo info) could'nt instantiate iiop Interceptor", e);
        }
    }

    /**
     * In JRMP the 2 methods (pre and post init) have the same consequences...
     * @param JInitInfo the JInit Information
     */
    public void post_init(JInitInfo info) {
        // do nothing
    }

}