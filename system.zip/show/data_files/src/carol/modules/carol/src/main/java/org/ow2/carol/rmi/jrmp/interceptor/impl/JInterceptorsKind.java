/**
 * Copyright (C) 2007 - Bull S.A.S.
 *
 * CAROL: Common Architecture for RMI ObjectWeb Layer
 *
 * This library is developed inside the OW2 Consortium,
 * http://www.ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: JInterceptorsKind.java 1515 2007-11-25 16:18:55Z loris $
 * --------------------------------------------------------------------------
 */
package org.ow2.carol.rmi.jrmp.interceptor.impl;

import java.util.List;

import org.ow2.carol.rmi.jrmp.interceptor.spi.JClientRequestInterceptor;
import org.ow2.carol.rmi.jrmp.interceptor.spi.JServerRequestInterceptor;

/**
 * Regroup some interceptors by kind.
 * @author Loris Bouzonnet
 */
public class JInterceptorsKind {

    private final List<String> jinitializers;
    private final List<JServerRequestInterceptor> sis;
    private final List<JClientRequestInterceptor> cis;

    public JInterceptorsKind(final List<String> jinitializers,
            final List<JServerRequestInterceptor> sis,
            final List<JClientRequestInterceptor> cis) {
        this.jinitializers = jinitializers;
        this.sis = sis;
        this.cis = cis;
    }

    public List<String> getInitializers() {
        return jinitializers;
    }

    public List<JServerRequestInterceptor> getJServerRequestInterceptors() {
        return sis;
    }

    public List<JClientRequestInterceptor> getJClientRequestInterceptors() {
        return cis;
    }

}
