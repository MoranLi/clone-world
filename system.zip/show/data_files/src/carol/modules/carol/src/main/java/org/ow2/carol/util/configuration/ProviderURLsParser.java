/**
 * Copyright (C) 2007 - Bull S.A.S.
 *
 * Carol : Common Architecture for RMI ObjectWeb Layer
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: ProviderURLsParser.java 1272 2007-09-11 11:43:56Z loris $
 * --------------------------------------------------------------------------
 */
package org.ow2.carol.util.configuration;

import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.ArrayList;
import java.util.Map;
import java.util.List;

/**
 * To parse a CMI URL.
 *
 * @author The new CMI team
 */
public final class ProviderURLsParser {

    /**
     * scheme.
     */
    private static String scheme = "";

    /**
     * Index if the '/' character when no host and no port are set in the url.
     */
    private static final int URL_HOSTPORT_INDEX = 2;

    /**
     * Hashtable mapping between protocols and schemes.
     */
    private static Map<String, String> mapping = new HashMap<String, String>();

    static {
        mapping.put("jrmp", "rmi");
        mapping.put("irmi", "rmi");
        mapping.put("iiop", "iiop");
    }

    /**
     * Private empty constructor because it's a utility class.
     */
    private ProviderURLsParser() {

    }

    /**
     * Parse scheme. We check that scheme is consistent with protocol.
     * @param protocol the protocol for this scheme
     * @param inputscheme schem
     * @throws MalformedURLException if malformed scheme
     */
    private static void parseScheme(final String protocol, final String inputscheme) throws MalformedURLException {
        if (inputscheme.length() == 0) { // scheme can be empty
            scheme = "";
        } else {
            if (inputscheme.length() > 1 && inputscheme.endsWith(":")) {
                // non-empty scheme must contain at least one character and end with :
                scheme =
                    inputscheme.substring(0, inputscheme.length() - 1);
            } else {
                throw new MalformedURLException("badly formed scheme");
            }
            if (!isConsistent(protocol, scheme)) {
                throw new MalformedURLException("Invalid scheme : " + scheme);
            }
        }
    }

    /**
     * Compare a scheme and a protocol to check if there are consistents.
     * @param protocol A protocol (ie: jrmp, irmi, iiop)
     * @param scheme A scheme of URL (ie: rmi, iiop)
     * @return true is the scheme and the protocol are consistents.
     * @throws MalformedURLException
     */
    private static boolean isConsistent(final String protocol, final String scheme) throws MalformedURLException {

        String sch = mapping.get(protocol);
        if(sch == null) {
            throw new MalformedURLException("Invalid protocol: "+protocol);
        }
        return sch.equals(scheme);
    }

    /**
     * Parse Name.
     * @param inputurl url
     * @return
     * @throws MalformedURLException  if malformed name
     */
    private static List<String> parseName(final String inputurl) throws MalformedURLException {
        // inputurl is expected to start with //
        String inputhostport = "";
        int n = inputurl.indexOf("/", URL_HOSTPORT_INDEX);
        if (n == -1 && inputurl.length() > URL_HOSTPORT_INDEX) {
            inputhostport = inputurl.substring(URL_HOSTPORT_INDEX);
        } else {
            throw new MalformedURLException("The syntax for URL is: <scheme>://<host>:<port>(,<host>:<port>)*");
        }
        return parseHostsPorts(inputhostport);
    }

    /**
     * Parse several [host,port].
     * @param inputhostsports host,port list
     * @return
     * @throws MalformedURLException if if parameters are malformed
     */
    private static List<String> parseHostsPorts(final String inputhostsports)
    throws MalformedURLException {
        int start = 0;
        List<String> providerURLs = new ArrayList<String>();
        do {
            int end = inputhostsports.indexOf(',', start);

            if (end < 0) {
                // the last url
                providerURLs.add(scheme+"://"+inputhostsports.substring(start));
            } else {
                providerURLs.add(scheme+"://"+inputhostsports.substring(start, end));
            }
            start = end + 1;
        } while (start > 0);
        return providerURLs;
    }

    /**
     * @param protocol
     * @param input
     * @return
     * @throws MalformedURLException
     */
    public static List<String> parse(final String protocol, final String input) throws MalformedURLException {
        if (input == null || input.length() == 0) {
            throw new MalformedURLException("null or empty registry URL");
        }
        if (input.indexOf("//") == -1) {
            throw new MalformedURLException(
                    "badly formed registry URL " + input);
        }
        try {
            parseScheme(protocol, input.substring(0, input.indexOf("//")));
            return parseName(input.substring(input.indexOf("//")));
        } catch (Exception e) {
            e.printStackTrace();
            throw new MalformedURLException(
                    "badly formed registry URL " + input);
        }
    }

}
