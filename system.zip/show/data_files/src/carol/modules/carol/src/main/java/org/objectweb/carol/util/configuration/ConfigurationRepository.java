/**
 * Copyright (C) 2005-2007 - Bull S.A.S.
 *
 * CAROL: Common Architecture for RMI ObjectWeb Layer
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: ConfigurationRepository.java 1272 2007-09-11 11:43:56Z loris $
 * --------------------------------------------------------------------------
 */
package org.objectweb.carol.util.configuration;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;



/**
 * This class handle all rmi configuration available at runtime for carol.<br>
 * Configurations could be added/removed after the startup of carol
 * @author Florent Benoit
 * @author Loris Bouzonnet
 */
@Deprecated
public final class ConfigurationRepository {

    /**
     * Logger
     */
    private static Log logger = LogFactory.getLog(ConfigurationRepository.class);

    /**
     * No public constructor.
     */
    private ConfigurationRepository() {
    }

    /**
     * @return a list of current configurations
     */
    public static ProtocolConfiguration[] getConfigurations() {
        org.ow2.carol.util.configuration.ProtocolConfiguration[] protoConfs =
            org.ow2.carol.util.configuration.ConfigurationRepository.getConfigurations();
        List<ProtocolConfiguration> protocolConfigurations = new ArrayList<ProtocolConfiguration>();
        ProtocolConfiguration[] result = new ProtocolConfiguration[protoConfs.length];
        for(org.ow2.carol.util.configuration.ProtocolConfiguration protocolConfiguration : protoConfs) {
            protocolConfigurations.add(getProxyForProtocolConfiguration(protocolConfiguration));
        }
        return protocolConfigurations.toArray(result);
    }

    /**
     * Gets a configuration with the given name
     * @param configName name of the configuration
     * @return configuration object associated to the given name
     */
    public static ProtocolConfiguration getConfiguration(final String configName) {
        return getProxyForProtocolConfiguration(
                org.ow2.carol.util.configuration.ConfigurationRepository.getConfiguration(configName));
    }

    /**
     * Gets a protocol with the given name
     * @param protocolName name of the protocol
     * @return protocol object associated to the given name
     */
    public static Protocol getProtocol(final String protocolName) {
        return new ProtocolWrapper(
                org.ow2.carol.util.configuration.ConfigurationRepository.getProtocol(protocolName));
    }

    /**
     * Build a new configuration for a given protocol
     * @param configurationName the name of the configuration
     * @param protocolName name of the protocol
     * @return a new configuration object for a given protocol
     * @throws ConfigurationException if no configuration can be built
     */
    public static ProtocolConfiguration newConfiguration(String configurationName, String protocolName)
            throws ConfigurationException {
        try {
            return getProxyForProtocolConfiguration(
                    org.ow2.carol.util.configuration.ConfigurationRepository.newConfiguration(configurationName, protocolName));
        } catch (org.ow2.carol.util.configuration.ConfigurationException e) {
            logger.error("Error on delegate", e);
            throw new ConfigurationException(e.getCause());
        }
    }

    /**
     * Set the current configuration object
     * @param config the configuration to set as current configuration
     * @return previous value of the configuration which was set
     */
    public static ProtocolConfiguration setCurrentConfiguration(ProtocolConfiguration config) {
        return getProxyForProtocolConfiguration(
                org.ow2.carol.util.configuration.ConfigurationRepository.setCurrentConfiguration(config));
    }

    /**
     * @return current carol configuration
     */
    public static ProtocolConfiguration getCurrentConfiguration() {
        return getProxyForProtocolConfiguration(
                org.ow2.carol.util.configuration.ConfigurationRepository.getCurrentConfiguration());
    }

    /**
     * Initialize Carol configurations with the carol.properties URL
     * @param carolPropertiesFileURL URL rerencing the configuration file
     * @throws ConfigurationException if no properties can be loaded
     */
    public static void init(URL carolPropertiesFileURL) throws ConfigurationException {
        try {
            org.ow2.carol.util.configuration.ConfigurationRepository.init(carolPropertiesFileURL);
        } catch (org.ow2.carol.util.configuration.ConfigurationException e) {
            logger.error("Error on delegate", e);
            throw new ConfigurationException(e.getCause());
        }
    }

    /**
     * Initialize Carol configurations with MBeans
     * @param domainName the name of the JOnAS domain
     * @param serverName the name of the server for creating mbeans
     * @throws ConfigurationException if no properties can be loaded
     */
    public static void init(String domainName, String serverName) throws ConfigurationException {
        try {
            org.ow2.carol.util.configuration.ConfigurationRepository.init(domainName, serverName);
        } catch (org.ow2.carol.util.configuration.ConfigurationException e) {
            logger.error("Error on delegate", e);
            throw new ConfigurationException(e.getCause());
        }
    }

    /**
     * } Initialize Carol configurations with the carol.properties URL
     * @param carolPropertiesFileURL URL referencing the configuration file
     * @param domainName the name of the JOnAS domain
     * @param serverName the name of the server for creating mbeans
     * @throws ConfigurationException if no properties can be loaded
     */
    public static void init(URL carolPropertiesFileURL, String domainName, String serverName)
            throws ConfigurationException {
        try {
            org.ow2.carol.util.configuration.ConfigurationRepository.init(carolPropertiesFileURL, domainName, serverName);
        } catch (org.ow2.carol.util.configuration.ConfigurationException e) {
            logger.error("Error on delegate", e);
            throw new ConfigurationException(e.getCause());
        }
    }

    /**
     * Add a configuration
     * @param protocolConfiguration the configuration to add
     * @throws ConfigurationException if the configuration exists
     */
    public static void addConfiguration(ProtocolConfiguration protocolConfiguration) throws ConfigurationException {
        try {
            org.ow2.carol.util.configuration.ConfigurationRepository.addConfiguration(protocolConfiguration);
        } catch (org.ow2.carol.util.configuration.ConfigurationException e) {
            logger.error("Error on delegate", e);
            throw new ConfigurationException(e.getCause());
        }
    }

    /**
     * Gets server configuration (made with carol-default.properties and
     * carol.properties file)
     * @return server configuration
     */
    public static ServerConfiguration getServerConfiguration() {
        return getProxyForServerConfiguration(
                org.ow2.carol.util.configuration.ConfigurationRepository.getServerConfiguration());
    }

    /**
     * Initialize Carol configurations with an URL of carol properties file
     * found with Classloader
     * @throws ConfigurationException if no properties can be loaded
     */
    public static void init() throws ConfigurationException {
        try {
            org.ow2.carol.util.configuration.ConfigurationRepository.init();
        } catch (org.ow2.carol.util.configuration.ConfigurationException e) {
            logger.error("Error on delegate", e);
            throw new ConfigurationException(e.getCause());
        }
    }


    /**
     * @return the default Configuration when no thread local is set.
     */
    public static ProtocolConfiguration getDefaultConfiguration() {
        return getProxyForProtocolConfiguration(
                org.ow2.carol.util.configuration.ConfigurationRepository.getDefaultConfiguration());
    }

    /**
     * @return the properties used by Carol configuration.
     */
    public static Properties getProperties() {
        return org.ow2.carol.util.configuration.ConfigurationRepository.getProperties();
    }

    /**
     * @return the number of active protocols
     */
    public static int getActiveConfigurationsNumber() {
        return org.ow2.carol.util.configuration.ConfigurationRepository.getActiveConfigurationsNumber();
    }

    /**
     * Add interceptor at runtime for a given protocol
     * @param protocolName protocol name
     * @param interceptorInitializer Interceptor Intializer class name
     * @throws ConfigurationException if interceptor cannot be added
     */
    public static void addInterceptors(String protocolName, String interceptorInitializer)
            throws ConfigurationException {
        try {
            org.ow2.carol.util.configuration.ConfigurationRepository.addInterceptors(protocolName, interceptorInitializer);
        } catch (org.ow2.carol.util.configuration.ConfigurationException e) {
            logger.error("Error on delegate", e);
            throw new ConfigurationException(e.getCause());
        }
    }

    private static ProtocolConfiguration getProxyForProtocolConfiguration(final org.ow2.carol.util.configuration.ProtocolConfiguration protocolConfiguration) {
        if(protocolConfiguration instanceof ProtocolConfiguration) {
            return (ProtocolConfiguration) protocolConfiguration;
        }
        return (ProtocolConfiguration) Proxy.newProxyInstance(Thread.currentThread().getContextClassLoader(), new Class[]{ProtocolConfiguration.class}, new ProtocolConfigurationInvocationHandler(protocolConfiguration));
    }

//    private static Protocol getProxyForProtocol(final org.ow2.carol.util.configuration.Protocol protocol) {
//        if(protocol instanceof Protocol) {
//            return (Protocol) protocol;
//        }
//        return (Protocol) Proxy.newProxyInstance(Thread.currentThread().getContextClassLoader(), new Class[]{Protocol.class}, new ProtocolInvocationHandler(protocol));
//    }

    private static ServerConfiguration getProxyForServerConfiguration(final org.ow2.carol.util.configuration.ServerConfiguration serverConfiguration) {
        if(serverConfiguration instanceof ServerConfiguration) {
            return (ServerConfiguration) serverConfiguration;
        }
        return (ServerConfiguration) Proxy.newProxyInstance(Thread.currentThread().getContextClassLoader(), new Class[]{ServerConfiguration.class}, new ServerConfigurationInvocationHandler(serverConfiguration));
    }

//    private static class ProtocolInvocationHandler implements InvocationHandler {
//
//        private org.ow2.carol.util.configuration.Protocol protocol;
//
//        public ProtocolInvocationHandler(final org.ow2.carol.util.configuration.Protocol protocol) {
//            this.protocol = protocol;
//        }
//
//        public Object invoke(final Object proxy, final Method method, final Object[] args)
//                throws Throwable {
//            return getCorrespondingMethod(org.ow2.carol.util.configuration.Protocol.class, method).invoke(protocol, args);
//        }
//
//    }

    private static class ProtocolConfigurationInvocationHandler implements InvocationHandler {

        private org.ow2.carol.util.configuration.ProtocolConfiguration protocolConfiguration;

        public ProtocolConfigurationInvocationHandler(final org.ow2.carol.util.configuration.ProtocolConfiguration protocolConfiguration) {
            this.protocolConfiguration = protocolConfiguration;
        }

        public Object invoke(final Object proxy, final Method method, final Object[] args)
                throws Throwable {
            Method correspondingMethod = getCorrespondingMethod(org.ow2.carol.util.configuration.ProtocolConfiguration.class, method);
            if(method.getName().equals("getProtocol")) {
                org.ow2.carol.util.configuration.Protocol protocol = (org.ow2.carol.util.configuration.Protocol) correspondingMethod.invoke(protocolConfiguration);
                return new ProtocolWrapper(protocol);
            }
            return correspondingMethod.invoke(protocolConfiguration, args);
        }

    }

    private static class ServerConfigurationInvocationHandler implements InvocationHandler {

        private org.ow2.carol.util.configuration.ServerConfiguration serverConfiguration;

        public ServerConfigurationInvocationHandler(final org.ow2.carol.util.configuration.ServerConfiguration serverConfiguration) {
            this.serverConfiguration = serverConfiguration;
        }

        public Object invoke(final Object proxy, final Method method, final Object[] args)
                throws Throwable {
            return getCorrespondingMethod(org.ow2.carol.util.configuration.ServerConfiguration.class, method).invoke(serverConfiguration, args);
        }

    }

    private static Method getCorrespondingMethod(final Class<?> klass, final Method method) {
        try {
            return klass.getMethod(method.getName(), method.getParameterTypes());
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
    }

}
