/**
 * Copyright (C) 2002,2005 - INRIA (www.inria.fr)
 *
 * CAROL: Common Architecture for RMI ObjectWeb Layer
 *
 * This library is developed inside the ObjectWeb Consortium,
 * http://www.objectweb.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: IrmiPRODelegate.java 1515 2007-11-25 16:18:55Z loris $
 * --------------------------------------------------------------------------
 */
package org.ow2.carol.rmi.multi;

import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.Collection;
import java.util.List;
import java.util.Properties;

import org.ow2.carol.irmi.ClientInterceptor;
import org.ow2.carol.irmi.Interceptor;
import org.ow2.carol.irmi.PRO;
import org.ow2.carol.irmi.Server;
import org.ow2.carol.rmi.jrmp.interceptor.api.JClientRequestInfo;
import org.ow2.carol.rmi.jrmp.interceptor.api.JServerRequestInfo;
import org.ow2.carol.rmi.jrmp.interceptor.impl.JInterceptorsKind;
import org.ow2.carol.rmi.jrmp.interceptor.impl.JInterceptorHelper;
import org.ow2.carol.rmi.jrmp.interceptor.impl.JInterceptorStore;
import org.ow2.carol.rmi.jrmp.interceptor.impl.JRMPClientRequestInfoImpl;
import org.ow2.carol.rmi.jrmp.interceptor.impl.JRMPServerRequestInfoImpl;
import org.ow2.carol.rmi.jrmp.interceptor.spi.JClientRequestInterceptor;
import org.ow2.carol.rmi.jrmp.interceptor.spi.JServerRequestInterceptor;
import org.ow2.carol.rmi.jrmp.interceptor.spi.JServiceContext;
import org.ow2.carol.rmi.util.PortNumber;
import org.ow2.carol.util.configuration.CarolDefaultValues;
import org.ow2.carol.util.configuration.ConfigurationRepository;

/**
 * IrmiPRODelegate
 *
 * @author Rafael H. Schloming &lt;rhs@mit.edu&gt;
 **/
public class IrmiPRODelegate extends PRO {

    private static class ServerInterceptorImpl implements Interceptor {

        private JServerRequestInterceptor[] sis;

        public ServerInterceptorImpl(final JServerRequestInterceptor[] sis) {
            this.sis = sis;
        }

        public void receive(final byte code, final ObjectInput in)
            throws IOException, ClassNotFoundException {
            JServerRequestInfo info = new JRMPServerRequestInfoImpl();
            int len = in.readShort();
            for (int i = 0; i < len; i++) {
                info.add_reply_service_context((JServiceContext) in.readObject());
            }
            for (JServerRequestInterceptor si : sis) {
                si.receive_request(info);
            }
        }

        public void send(final byte code, final ObjectOutput out) throws IOException {
            JServerRequestInfo info = new JRMPServerRequestInfoImpl();
            for (JServerRequestInterceptor si : sis) {
                switch (code) {
                case METHOD_RESULT:
                    si.send_reply(info);
                    break;
                case METHOD_ERROR:
                case SYSTEM_ERROR:
                    si.send_exception(info);
                    break;
                }
            }
            Collection<JServiceContext> c = info.get_all_reply_service_context();
            out.writeShort(c.size());
            for (JServiceContext jServiceContext : c) {
                out.writeObject(jServiceContext);
            }
        }

    }

    private static class ClientInterceptorImpl implements ClientInterceptor {

        /**
         * Id for serializable class.
         */
        private static final long serialVersionUID = -5212967521441892250L;

        private final JClientRequestInterceptor[] cis;

        public ClientInterceptorImpl(final JClientRequestInterceptor[] cis) {
            this.cis = cis;
        }

        public void send(final byte code, final ObjectOutput out) throws IOException {
            JClientRequestInfo info = new JRMPClientRequestInfoImpl();
            for (JClientRequestInterceptor ci : cis) {
                ci.send_request(info);
            }
            Collection<JServiceContext> c = info.get_all_request_service_context();
            out.writeShort(c.size());
            for (JServiceContext jServiceContext : c) {
                out.writeObject(jServiceContext);
            }
        }

        public void receive(final byte code, final ObjectInput in)
            throws IOException, ClassNotFoundException {
            JClientRequestInfo info = new JRMPClientRequestInfoImpl();
            int len = in.readShort();
            for (int i = 0; i < len; i++) {
                info.add_request_service_context((JServiceContext) in.readObject());
            }
            for (JClientRequestInterceptor ci : cis) {
                switch (code) {
                case METHOD_RESULT:
                    ci.receive_reply(info);
                    break;
                case METHOD_ERROR:
                case SYSTEM_ERROR:
                    ci.receive_exception(info);
                    break;
                }
            }
        }

    }

    private static Server getServer() {
        int port = 0;
        Properties prop = ConfigurationRepository.getProperties();
        if (prop != null) {
            String propertyName = CarolDefaultValues.SERVER_IRMI_PORT;
            port = PortNumber.strToint(prop.getProperty(propertyName, "0"), propertyName);
        }
        JInterceptorStore jiStore = JInterceptorStore.getJInterceptorStore();
        JInterceptorsKind interceptorsByType =
            JInterceptorHelper.getInterceptorsByType(jiStore.getJInterceptors());
        List<JServerRequestInterceptor> sistmp = interceptorsByType.getJServerRequestInterceptors();
        JServerRequestInterceptor[] sis = sistmp.toArray(new JServerRequestInterceptor[sistmp.size()]);
        List<JClientRequestInterceptor> cistmp = interceptorsByType.getJClientRequestInterceptors();
        JClientRequestInterceptor[] cis = cistmp.toArray(new JClientRequestInterceptor[cistmp.size()]);
        return new Server(port, new ClientInterceptorImpl(cis), new ServerInterceptorImpl(sis));
    }

    public IrmiPRODelegate() {
        super(getServer());
    }

}
