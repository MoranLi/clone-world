/**
 * Copyright (C) 2007,2008 - Bull S.A.S.
 *
 * CAROL: Common Architecture for RMI ObjectWeb Layer
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: JrmpProtocol.java 1622 2008-02-08 09:37:40Z loris $
 * --------------------------------------------------------------------------
 */
package org.ow2.carol.util.configuration;

import java.util.Properties;

import org.apache.commons.logging.Log;
import org.ow2.carol.rmi.jrmp.interceptor.impl.JInterceptorStore;
import org.ow2.carol.rmi.jrmp.interceptor.spi.JInitializer;

/**
 * Extend the default implementation of a protocol in order to define some methods allowing interceptors management.
 * @author Loris Bouzonnet
 */
public class JrmpProtocol extends Protocol {


    /**
     * Build a new protocol object with given parameters.
     * This protocol supports the dynamic management of interceptors.
     * @param name the name of this protocol
     * @param properties properties of this protocol
     * @param logger logger
     * @param domainName the name of the JOnAS domain
     * @param serverName the name of the server for creating mbeans
     * @throws ConfigurationException if properties are missing
     */
    public JrmpProtocol(final String name, final Properties properties, final Log logger,
            final String domainName, final String serverName)
    throws ConfigurationException {
        super(name, properties, logger, domainName, serverName);
    }

    /**
     * Add an interceptor for the given protocol by the dynamic way.
     * @param jinitClass the class of the interceptor initializer
     */
    @SuppressWarnings("unchecked")
    @Override
    public void addInterceptor(final Class<?> jinitClass) {
        JInterceptorStore.getJInterceptorStore().addLocalInterceptor(
                (Class<? extends JInitializer>) jinitClass);
    }

    /**
     * Remove an interceptor for the given protocol by the dynamic way.
     * @param jinitClass the class of the interceptor initializer
     */
    @SuppressWarnings("unchecked")
    @Override
    public void removeInterceptor(final Class<?> jinitClass) {
        JInterceptorStore.getJInterceptorStore().removeLocalInterceptor(
                (Class<? extends JInitializer>) jinitClass);
    }

}
