/**
 * Copyright (C) 2002-2007 - INRIA (www.inria.fr)
 *
 * CAROL: Common Architecture for RMI ObjectWeb Layer
 *
 * This library is developed inside the ObjectWeb Consortium,
 * http://www.ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: TraceCarol.java 1274 2007-09-11 16:34:54Z loris $
 * --------------------------------------------------------------------------
 */
package org.objectweb.carol.util.configuration;

/**
 * Class <code> TraceCarol </code> for Carol Trace configuration
 */
@Deprecated
public class TraceCarol {

    /**
     * Utility class, no constructor
     */
    private TraceCarol() {

    }

    /**
     * Configure the log for CAROL.
     */
    public static void configure() {
        org.ow2.carol.util.configuration.TraceCarol.configure();
    }

    /**
     * Log a verbose message
     * @param msg verbose message
     */
    public static void verbose(String msg) {
        org.ow2.carol.util.configuration.TraceCarol.verbose(msg);
    }

    /**
     * Log an error message.
     * @param msg error message
     */
    public static void error(String msg) {
        org.ow2.carol.util.configuration.TraceCarol.error(msg);
    }

    /**
     * Log an error message and a stack trace from a Throwable object.
     * @param msg error message
     * @param th Throwable object
     */
    public static void error(String msg, Throwable th) {
        org.ow2.carol.util.configuration.TraceCarol.error(msg, th);
    }

    /**
     * Test if Carol debug messages are logged.
     * @return boolean <code>true</code> if Carol debug messages are logged,
     *         <code>false</code> otherwise
     */
     public static boolean isDebugCarol() {
        return org.ow2.carol.util.configuration.TraceCarol.isDebugCarol();
    }

    /**
     * Log a Carol debug message.
     * @param msg CAROL debug message
     */
    public static void debugCarol(String msg) {
        org.ow2.carol.util.configuration.TraceCarol.debugCarol(msg);
    }

    /**
     * Test if Carol info messages are logged.
     * @return boolean <code>true</code> if Carol debug messages are logged,
     *         <code>false</code> otherwise
     */
     public static boolean isInfoCarol() {
        return org.ow2.carol.util.configuration.TraceCarol.isInfoCarol();
    }

    /**
     * Log a Carol Info message.
     * @param msg CAROL debug message
     */
    public static void infoCarol(String msg) {
        org.ow2.carol.util.configuration.TraceCarol.infoCarol(msg);
    }

    /**
     * Test if Jndi debug messages are logged.
     * @return boolean <code>true</code> if Jndi debug messages are logged,
     *         <code>false</code> otherwise
     */
     public static boolean isDebugJndiCarol() {
        return org.ow2.carol.util.configuration.TraceCarol.isDebugCarol();
    }

    /**
     * Log a Jndi debug message.
     * @param msg Jndi debug message
     */
    public static void debugJndiCarol(String msg) {
        org.ow2.carol.util.configuration.TraceCarol.debugCarol(msg);
    }

    /**
     * Test if Jndi ENC debug messages are logged.
     * @return boolean <code>true</code> if Jndi debug messages are logged,
     *         <code>false</code> otherwise
     */
     public static boolean isDebugjndiEncCarol() {
        return org.ow2.carol.util.configuration.TraceCarol.isDebugjndiEncCarol();
    }

    /**
     * Log a Jndi ENC debug message.
     * @param msg Jndi debug message
     */
    public static void debugjndiEncCarol(String msg) {
        org.ow2.carol.util.configuration.TraceCarol.debugjndiEncCarol(msg);
    }


    /**
     * Test if Rmi debug messages are logged.
     * @return boolean <code>true</code> if Rmi debug messages are logged,
     *         <code>false</code> otherwise
     */
     public static boolean isDebugRmiCarol() {
        return org.ow2.carol.util.configuration.TraceCarol.isDebugRmiCarol();
    }

    /**
     * Log a Rmi debug message.
     * @param msg Rmi debug message
     */
    public static void debugRmiCarol(String msg) {
        org.ow2.carol.util.configuration.TraceCarol.debugRmiCarol(msg);
    }

    /**
     * @return boolean true is is debug export
     */
    public static boolean isDebugExportCarol() {
        return org.ow2.carol.util.configuration.TraceCarol.isDebugExportCarol();
    }

    /**
     * Debug export
     * @param msg string
     */
    public static void debugExportCarol(String msg) {
        org.ow2.carol.util.configuration.TraceCarol.debugExportCarol(msg);
    }
}