/**
 * Copyright (C) 2002,2004 - INRIA (www.inria.fr)
 * Copyright (C) 2008 - Bull S.A.S. (www.bull.fr)
 *
 * CAROL: Common Architecture for RMI OW2 Layer
 *
 * This library is developed inside the ObjectWeb Consortium,
 * http://www.ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: JRMPContextWrapperFactory.java 1633 2008-02-22 12:27:38Z loris $
 * --------------------------------------------------------------------------
 */
package org.objectweb.carol.jndi.spi;

/**
 * Class <code> JRMPContextWrapperFactory </code> is the CAROL
 * JNDI Context factory. This context factory build the jrmp context for
 * reference wrapping to/from a remote object
 * @author Guillaume Riviere
 * @author Florent Benoit (refactoring)
 * @see javax.naming.spi.InitialContextFactory
 * @deprecated use {@link org.ow2.carol.rmi.jrmp.interceptor.impl.JRMPClientRequestInfoImpl}
 */
@Deprecated
public class JRMPContextWrapperFactory extends org.ow2.carol.rmi.jrmp.interceptor.impl.JRMPClientRequestInfoImpl {
    // Just extend to support legacy programs
}
