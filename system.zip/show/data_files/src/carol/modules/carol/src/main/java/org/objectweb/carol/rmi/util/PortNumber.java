/**
 * Copyright (C) 2007 - Bull S.A.S.
 *
 * CAROL: Common Architecture for RMI ObjectWeb Layer
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: PortNumber.java 1272 2007-09-11 11:43:56Z loris $
 * --------------------------------------------------------------------------
 */

package org.objectweb.carol.rmi.util;

@Deprecated
public final class PortNumber {

    /**
     * Utility class, no constructor
     */
    private PortNumber() {

    }

    /**
     * Return port number based on given string
     * @param portStr port number in stringified format
     * @param propertyName name of the property of the port number in carol.properties file (for error messages)
     * @return port number (or 0)
     */
    public static int strToint(String portStr, String propertyName) {
        return org.ow2.carol.rmi.util.PortNumber.strToint(portStr, propertyName);
    }

}
