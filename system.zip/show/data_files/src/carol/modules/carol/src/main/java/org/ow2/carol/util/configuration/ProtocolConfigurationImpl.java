/**
 * Copyright (C) 2005-2007 - Bull S.A.S.
 *
 * CAROL: Common Architecture for RMI ObjectWeb Layer
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: ProtocolConfigurationImpl.java 1572 2008-01-15 13:10:01Z eyindanga $
 * --------------------------------------------------------------------------
 */
package org.ow2.carol.util.configuration;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NameClassPair;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * This class manage a rmi configuration used by carol.<br>
 * The configuration is based on a protocol which contains required values and non modified values
 */
public class ProtocolConfigurationImpl implements ProtocolConfiguration, ProtocolConfigurationImplMBean {

    /**
     * Logger
     */
    private static Log logger = LogFactory.getLog(ProtocolConfigurationImpl.class);

    /**
     * Name of this configuration.
     */
    private final String name;

    /**
     * Protocol used by this configuration.
     */
    private final Protocol protocol;

    /**
     * Properties of this configuration.
     */
    private Properties properties = null;

    /**
     * JNDI env.
     */
    private Hashtable<Object, Object> jndiEnv = null;

    /**
     * CMI env.
     */
    private Hashtable<String, Object> cmiEnv = null;

    /**
     * Host for this protocol name service.
     */
    private String host = null;

    /**
     * port number for this protocol name service.
     */
    private int port = 0;

    /**
     * Object name.
     */
    private String objectName = null;

    /**
     * Flag to specify if CMI is enabled (false by default).
     */
    private volatile boolean cmiEnabled = false;

    /**
     * Server configuration.
     */
    private final ServerConfiguration sc;

    /**
     * providerURLs.
     */
    private List<String> providerURLs = null;

    /**
     * Build a new configuration with given parameters.
     * @param name the name of this protocol configuration
     * @param protocol the protocol object used by this configuration
     * @param properties for this object
     * @param serverConfiguration the configuration of the server (independent of protocol)
     * @throws ConfigurationException if configuration is not correct
     */
    public ProtocolConfigurationImpl(final String name, final Protocol protocol, final Properties properties,
            final ServerConfiguration serverConfiguration) throws ConfigurationException {
        this.name = name;
        this.protocol = protocol;
        sc = serverConfiguration;
        configure(properties);
    }

    /**
     * Configure this configuration with a given properties object.
     * @param properties given properties
     * @throws ConfigurationException if the given config is invalid
     */
    public void configure(final Properties properties) throws ConfigurationException {
        if (properties == null) {
            throw new ConfigurationException("Cannot build a configuration with a null properties object");
        }
        this.properties = properties;

        String protocolName = protocol.getName();
        String prefixProtocol = CarolDefaultValues.CAROL_PREFIX + "." + protocolName + ".";

        try {
            cmiEnabled = new Boolean(getValue(prefixProtocol + "cmi"));
        } catch(ConfigurationException e) {
            // If the property is missing, the default value false is used.
            cmiEnabled = false;
        }

        if(sc.isStartCMI() && cmiEnabled) {
            // extract CMI properties for InitialContext() creation
            extractCMIProperties();
        }

        // extract JNDI env for InitialContext() creation
        extractJNDIProperties();

        // extract host and port of URL
        parseURL();

    }

    /**
     * Extract CMI properties of properties.
     * @throws ConfigurationException if properties are missing
     */
    private void extractCMIProperties() throws ConfigurationException {
        String protocolName = protocol.getName();
        String prefixProtocol = CarolDefaultValues.CAROL_PREFIX + "." + protocolName + ".";

        cmiEnv = new Hashtable<String, Object>();

        // Firstly fix the properties specific at CMI
        cmiEnv.put("cmi.context.wrapped.protocol", protocolName);
        try {
            providerURLs = ProviderURLsParser.parse(protocolName, getValue(prefixProtocol + CarolDefaultValues.URL_PREFIX));
            if(sc.isServer() && providerURLs.size() != 1) {
                throw new ConfigurationException("In mode server, providerURLs must contain only one element.");
            }
        } catch (MalformedURLException e) {
            logger.error("Cannot parse provider URLs", e);
            throw new ConfigurationException("Cannot parse provider URLs", e);
        }
        cmiEnv.put("cmi.context.provider.urls", providerURLs);
        cmiEnv.put("cmi.context.wrapped.factory", protocol.getInitialContextFactoryClassName());
        cmiEnv.put("cmi.mode.server", sc.isServer());

        // Finally fix the JNDI properties to use CMI
        cmiEnv.put(Context.PROVIDER_URL, providerURLs.get(0));
        cmiEnv.put(Context.INITIAL_CONTEXT_FACTORY, sc.getCmiInitialContextFactory());

    }

    /**
     * Extract JNDI properties of properties.
     * @throws ConfigurationException if properties are missing
     */
    protected void extractJNDIProperties() throws ConfigurationException {
        jndiEnv = new Hashtable<Object, Object>();
        String prefixProtocol = CarolDefaultValues.CAROL_PREFIX + "." + protocol.getName() + ".";

        jndiEnv.put(Context.PROVIDER_URL, getValue(prefixProtocol + CarolDefaultValues.URL_PREFIX));
        jndiEnv.put(Context.INITIAL_CONTEXT_FACTORY, protocol.getInitialContextFactoryClassName());
    }

    /**
     * Parse URL to extract host and port.
     * @throws ConfigurationException if URL is not correct
     */
    protected void parseURL() throws ConfigurationException {
        String url = getProviderURL();
        port = ConfigurationUtil.getPortOfUrl(url);
        host = ConfigurationUtil.getHostOfUrl(url);
    }

    /**
     * Build an initial context with the given environment using our configuration.
     * @param env parameters for the initial context
     * @return an InitialContext
     * @throws NamingException if the context is not created
     */
    public Context getInitialContext(final Hashtable<?, ?> env) throws NamingException {
        Hashtable<Object, Object> newEnv = new Hashtable<Object, Object>(env);
        newEnv.putAll(jndiEnv);
        ProtocolConfiguration protocolConfiguration = null;
        if(sc.isStartCMI() && cmiEnabled) {
            if(cmiEnv == null) {
                // It's the first time that CMI is started, configure Carol to use it
                try {
                    extractCMIProperties();
                } catch (ConfigurationException e) {
                    logger.error("Cannot configure Carol to use CMI", e);
                    NamingException ne = new NamingException("Cannot configure Carol to use CMI");
                    ne.setRootCause(e);
                    throw ne;
                }
            }
            if(sc.isServer()) {
                // cmi needs to know the current configuration in order to call successfully the method PortableRemoteObject.toStub(Remote)
                protocolConfiguration = ConfigurationRepository.setCurrentConfiguration(this);
            }
            // Prefer the environment specific at CMI
            newEnv.putAll(cmiEnv);
        }
        try {
            return new InitialContext(newEnv);
        } finally {
            // Restore the previous protocol configuration
            if(protocolConfiguration != null) {
                ConfigurationRepository.setCurrentConfiguration(protocolConfiguration);
            }
        }
    }

    /**
     * @return the protocol used by this configuration.
     */
    public Protocol getProtocol() {
        return protocol;
    }

    /**
     * @return the name of this configuration
     */
    public String getName() {
        return name;
    }

    /**
     * @return a copy of the properties of this configuration
     */
    public Properties getProperties() {
        return (Properties) properties.clone();
    }

    /**
     * @return the host.
     */
    public String getHost() {
        return host;
    }

    /**
     * @return the port for this protocol name service
     */
    public int getPort() {
        return port;
    }

    /**
     * @return the Provider URL attribute
     */
    public String getProviderURL() {
        return (String) jndiEnv.get(Context.PROVIDER_URL);
    }

    /**
     * Gets value of properties object.
     * @param key the key of the properties
     * @return value stored in a property object
     * @throws ConfigurationException if properties are missing
     */
    protected String getValue(final String key) throws ConfigurationException {
        // properties cannot be null, check in constructor
        String s = properties.getProperty(key);
        if (s == null) {
            throw new ConfigurationException("Property '" + key
                    + "' was not found in the properties object of the protocol, properties are :'" + properties + "'");
        }
        return s;
    }

    /**
     * @return the jndiEnv (used for InitialContext).
     */
    public Hashtable<Object, ?> getJndiEnv() {
        return jndiEnv;
    }

    /**
     * MBean method : Gets the InitialContextFactory classname (Context.INITIAL_CONTEXT_FACTORY).
     * @return the InitialContextFactory classname
     */
    public String getInitialContextFactoryClassName() {
        return protocol.getInitialContextFactoryClassName();
    }

    /**
     * Gets JNDI names of the context with this configuration.
     * @return JNDI names
     * @throws NamingException if the names cannot be listed
     */
    public List<String> getNames() throws NamingException {
        Context ctx = getInitialContext(getJndiEnv());

        List<String> names = new ArrayList<String>();
        NamingEnumeration<NameClassPair> ne = ctx.list("");
        String n = null;
        while (ne.hasMore()) {
            NameClassPair ncp = ne.next();
            n = ncp.getName();
            names.add(n);
        }
        return names;
    }

    /**
     * @return Object Name
     */
    public String getobjectName() {
        return objectName;
    }

    /**
     * Sets the object name of this mbean.
     * @param name the Object Name
     */
    public void setobjectName(final String name) {
        this.objectName = name;
    }

    /**
     * @return true if it is an event provider
     */
    public boolean iseventProvider() {
        return false;
    }

    /**
     * @return true if this managed object implements J2EE State Management
     *         Model
     */
    public boolean isstateManageable() {
        return false;
    }

    /**
     * @return true if this managed object implements the J2EE StatisticProvider
     *         Model
     */
    public boolean isstatisticsProvider() {
        return false;
    }

    /**
     * @return true if CMI is enabled for this protocol
     */
    public boolean isCmiEnabled() {
        return cmiEnabled;
    }

    /**
     * Set if CMI is enabled for this protocol.
     * @param cmiEnabled true if CMI is enabled for this protocol
     */
    public void setCmiEnabled(final boolean cmiEnabled) {
        this.cmiEnabled = cmiEnabled;
    }

    /**
     * Gets the ObjectName of the protocol.
     * @return ObjectName of the protocol
     */
    public String getObjectName() {
        return objectName;
    }

    /**Set The ObjectName of the protocol.
     * @param objectName The ObjectNAme to set
     */
    public void setObjectName(final String objectName) {
        this.objectName = objectName;
    }

    /* (non-Javadoc)
     * @see org.ow2.carol.util.configuration.ProtocolConfigurationImplMBean#getProviderURLs()
     */
    public List<String> getProviderURLs() {
        return providerURLs;
    }

    /**
     * Sets provider URLs to the protocol.
     * @param providerURLs The provider URLs to set. e.g <b>rmi://localhost:1099</b>
     */
    public void setProviderURLs(final List<String> providerURLs) {
        this.providerURLs = providerURLs;
    }

    /**
     * Sets provider port
     * @param port The port to set
     */
    public void setPort(final int port) {
        this.port = port;
    }
    /**
     * Sets a host
     * @param host The host to set e.g <b>localhost</b>
     */
    public void setHost(final String host) {
        this.host = host;
    }

}
