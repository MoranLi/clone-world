/**
 * Copyright (C) 2002-2007 - INRIA (www.inria.fr)
 *
 * CAROL: Common Architecture for RMI ObjectWeb Layer
 *
 * This library is developed inside the OW2 Consortium,
 * http://www.ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: JInterceptorStore.java 1700 2008-03-20 17:07:32Z loris $
 * --------------------------------------------------------------------------
 */

package org.ow2.carol.rmi.jrmp.interceptor.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import org.ow2.carol.rmi.jrmp.interceptor.spi.JClientRequestInterceptor;
import org.ow2.carol.rmi.jrmp.interceptor.spi.JInitializer;
import org.ow2.carol.util.configuration.TraceCarol;

/**
 * Class <code>JInterceptorStore</code> is the CAROL JRMP Client and Server
 * Interceptors Storage System
 * @author Guillaume Riviere (Guillaume.Riviere@inrialpes.fr)
 * @author Loris Bouzzonet (Add the capability to add interceptors after the Carol initialization)
 * @version 2.0, 25/11/2007
 */
public final class JInterceptorStore {

    /**
     * Initializer class prefix.
     */
    public static final String INTIALIZER_PREFIX = "org.ow2.PortableInterceptor.JRMPInitializerClass";

    /**
     * Singleton.
     */
    private static JInterceptorStore jiStore = null;

    private final List<JInterceptorsGroup> jinterceptorsList;

    /**
     * private remote Interceptor cache for Context propagation
     */
    private List<JClientRequestInterceptor> rcis;

    /**
     * JRMPINfo Impl
     */
    private final JRMPInitInfoImpl jrmpInfo;

    /**
     * Initialize interceptors for a carol server
     */
    private JInterceptorStore() {
        jrmpInfo = new JRMPInitInfoImpl();
        jinterceptorsList = new ArrayList<JInterceptorsGroup>();
        // Load the Interceptors
        try {
            Properties sys = System.getProperties();
            for (Enumeration<?> e = sys.propertyNames(); e.hasMoreElements();) {
                String pkey = (String) e.nextElement();
                if (pkey.startsWith(INTIALIZER_PREFIX)) {
                    String initializer = pkey.substring(INTIALIZER_PREFIX.length() + 1);
                    JInitializer jinit = (JInitializer) getClass().getClassLoader().loadClass(initializer).newInstance();
                    jrmpInfo.clear();
                    jinit.pre_init(jrmpInfo);
                    jinit.post_init(jrmpInfo);
                    JInterceptorsGroup jInterceptors =
                        new JInterceptorsGroup(initializer,
                                Arrays.asList(jrmpInfo.getServerRequestInterceptors()),
                                Arrays.asList(jrmpInfo.getClientRequestInterceptors()));
                    jinterceptorsList.add(jInterceptors);
                }
            }
            // first remote reference = local reference
            resetRemoteInterceptors();
        } catch (Exception e) {
            //we did not found the interceptor do nothing but a trace ?
            TraceCarol.error("JrmpPRODelegate(), No interceptors found", e);
            throw new RuntimeException("Cannot initialize the JInterceptorStore", e);
        }
    }

    public static synchronized JInterceptorStore getJInterceptorStore() {
        if(jiStore == null) {
            jiStore = new JInterceptorStore();
        }
        return jiStore;
    }

    /**
     * Get Initializers method
     * @return JRMP Initializers enumeration
     */
    public List<JInterceptorsGroup> getJInterceptors() {
        return jinterceptorsList;
    }

    /**
     * Get interceptor if exists. Executed by the clients when unserializing a stub.
     * @param ia interceptors initializers
     * @return JClientRequestInterceptors [] , the interceptors
     */
    public synchronized JClientRequestInterceptor[] setRemoteInterceptors(final String[] ia) {
        jrmpInfo.clear();
        for (String className : ia) {
            JInitializer jinit;
            try {
                jinit = (JInitializer) Class.forName(className).newInstance();
                jinit.pre_init(jrmpInfo);
                jinit.post_init(jrmpInfo);
            } catch (Exception e) {
                TraceCarol.error("can not load interceptors", e);
            }
        }
        rcis = Arrays.asList(jrmpInfo.getClientRequestInterceptors());
        return rcis.toArray(new JClientRequestInterceptor[rcis.size()]);
    }

    /**
     * Add a new interceptor initializer.
     * @param jinitClass a class defining an interceptor initializer
     */
    public synchronized void addLocalInterceptor(final Class<? extends JInitializer> jinitClass) {
        String jinitClassname = jinitClass.getName();
        for(JInterceptorsGroup jInterceptors : jinterceptorsList) {
            if(jInterceptors.getInitializer().equals(jinitClassname)) {
                TraceCarol.debugRmiCarol("Interceptors already registered for class " + jinitClassname);
                return;
            }
        }
        jrmpInfo.clear();
        try {
            JInitializer jinit = jinitClass.newInstance();
            jinit.pre_init(jrmpInfo);
            jinit.post_init(jrmpInfo);
            JInterceptorsGroup jInterceptors =
                new JInterceptorsGroup(jinitClassname,
                    Arrays.asList(jrmpInfo.getServerRequestInterceptors()),
                    Arrays.asList(jrmpInfo.getClientRequestInterceptors()));
            jinterceptorsList.add(jInterceptors);
            resetRemoteInterceptors();
        } catch (Exception e) {
            TraceCarol.error("Cannot add interceptors for class " + jinitClassname, e);
        }
    }

    /**
     * Remove an interceptor initializer.
     * @param jinitClass a class defining an interceptor initializer
     */
    public synchronized void removeLocalInterceptor(final Class<? extends JInitializer> jinitClass) {
        Iterator<JInterceptorsGroup> iterator = jinterceptorsList.iterator();
        while(iterator.hasNext()) {
            JInterceptorsGroup interceptors = iterator.next();
            if(interceptors.getInitializer().equals(jinitClass.getName())) {
                iterator.remove();
                break;
            }
        }
        resetRemoteInterceptors();
    }

    /**
     * Reset the remote interceptors.
     */
    private void resetRemoteInterceptors() {
        rcis = JInterceptorHelper.getInterceptorsByType(jinterceptorsList).getJClientRequestInterceptors();
    }

}
