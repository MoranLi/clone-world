/**
 * Copyright (C) 2007 - Bull S.A.S.
 *
 * CAROL: Common Architecture for RMI ObjectWeb Layer
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: ServerConfiguration.java 1513 2007-11-25 12:22:17Z loris $
 * --------------------------------------------------------------------------
 */


package org.ow2.carol.util.configuration;

public interface ServerConfiguration {

    /**
     * @return true if JNDI has to be started (set of MultiORB ICTX factory)
     */
    boolean isStartingJNDI();

    /**
     * @return true if name services have to be launched)
     */
    boolean isStartingNS();

    /**
     * @return true if ProdelegateClass has to be set to MultiProDelegate
     */
    boolean isStartingRMI();

    /* -------------- Configuration of CMI -----------------*/
    /**
     * @return true if CMI is used
     */
    boolean isStartCMI();

    /**
     * Set if CMI is used.
     * @param startCMI true if CMI is used
     * @throws Exception if cmi cannot be configured
     */
    void setStartCMI(boolean startCMI) throws Exception;

    /**
     * @return a InitialContextFactory name to use with CMI
     */
    String getCmiInitialContextFactory();

    /**
     * @return true if this is a server
     */
    boolean isServer();

    /**
     * Return true if a protocol-independent environment is used.
     * Otherwise the environment of the default protocol is used.
     * @return true if a protocol-independent environment is used
     */
    boolean isMultiEnvironment();

}
