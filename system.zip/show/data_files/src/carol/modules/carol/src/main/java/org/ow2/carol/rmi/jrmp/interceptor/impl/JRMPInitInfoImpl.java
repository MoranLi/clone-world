/**
 * Copyright (C) 2002-2007 - INRIA (www.inria.fr)
 *
 * CAROL: Common Architecture for RMI ObjectWeb Layer
 *
 * This library is developed inside the OW2 Consortium,
 * http://www.ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: JRMPInitInfoImpl.java 1272 2007-09-11 11:43:56Z loris $
 * --------------------------------------------------------------------------
 */
package org.ow2.carol.rmi.jrmp.interceptor.impl;
import java.util.ArrayList;

import org.ow2.carol.rmi.jrmp.interceptor.api.JInitInfo;
import org.ow2.carol.rmi.jrmp.interceptor.spi.JClientRequestInterceptor;
import org.ow2.carol.rmi.jrmp.interceptor.spi.JServerRequestInterceptor;

/**
 * Class <code>JRMPInitInfoImpl</code> is the CAROL JRMP Initializer
 * Implementation
 * @see org.ow2.carol.rmi.jrmp.interceptor.api.JInitInfo
 * @author Guillaume Riviere (Guillaume.Riviere@inrialpes.fr)
 * @version 1.0, 15/07/2002
 */
public class JRMPInitInfoImpl implements JInitInfo {

    /**
     * Request Server Interceptor Hashtable
     */
    protected ArrayList<JServerRequestInterceptor> serverInterceptors = new ArrayList<JServerRequestInterceptor>();

    /**
     * Request Client Interceptor Hashtable
     */
    protected ArrayList<JClientRequestInterceptor> clientInterceptors = new ArrayList<JClientRequestInterceptor>();

    /**
     * add client interceptor
     * @param JClientRequestInterceptor the client interceptor to add
     */
    public void add_client_request_interceptor(JClientRequestInterceptor interceptor) {
        clientInterceptors.add(interceptor);
    }

    /**
     * add server interceptor
     * @param JServerRequestInterceptor the server interceptor to add
     */
    public void add_server_request_interceptor(JServerRequestInterceptor interceptor) {
        serverInterceptors.add(interceptor);
    }

    /**
     * get all the client interceptor
     * @return array of ClientRequestInterceptor
     */
    public JClientRequestInterceptor[] getClientRequestInterceptors() {
        JClientRequestInterceptor[] result = new JClientRequestInterceptor[clientInterceptors.size()];
        return clientInterceptors.toArray(result);
    }

    /**
     * get all the server interceptor
     * @return array of ServerRequestInterceptor
     */
    public JServerRequestInterceptor[] getServerRequestInterceptors() {
        JServerRequestInterceptor[] result = new JServerRequestInterceptor[serverInterceptors.size()];
        return serverInterceptors.toArray(result);
    }

    public void clear() {
        serverInterceptors.clear();
        clientInterceptors.clear();
    }
}