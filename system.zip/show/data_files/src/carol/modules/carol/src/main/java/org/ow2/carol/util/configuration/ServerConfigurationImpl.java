/**
 * Copyright (C) 2005-2007 - Bull S.A.S.
 *
 * CAROL: Common Architecture for RMI ObjectWeb Layer
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: ServerConfigurationImpl.java 1529 2007-12-07 10:10:25Z loris $
 * --------------------------------------------------------------------------
 */
package org.ow2.carol.util.configuration;

import java.lang.reflect.Method;
import java.util.Enumeration;
import java.util.Properties;

import javax.naming.Context;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


/**
 * This class handle the configuration of carol (independent of protocols
 * configuration) It doesn't implement ProtocolConfiguration interface which is
 * dedicated to protocols configuration
 * @author Florent Benoit
 * @author Loris Bouzonnet (Adapting for the new CMI)
 */
public class ServerConfigurationImpl
implements ServerConfiguration, ServerConfigurationImplMBean {

    /**
     * Logger
     */
    private static Log logger = LogFactory.getLog(ServerConfigurationImpl.class);

    /**
     * Properties used for this server.
     */
    private final Properties properties;

    /**
     * Start nameservice of protocols ?
     */
    private final boolean startNS;

    /**
     * Set MultiORB InitialContext factory ?
     */
    private final boolean startJNDI;

    /**
     * Set MultiProDelegate class ?
     */
    private final boolean startRMI;

    /**
     * Set CMIContextWrapper class ?
     */
    private volatile boolean startCMI;

    /**
     * Factory to use to create a new InitialContext for CMI.
     */
    private volatile String cmiInitialContextFactory = null;

    /**
     * The name of the JOnAS domain.
     */
    private final String domainName;

    /**
     * The name of the server for creating MBeans.
     */
    private final String serverName;

    /**
     * The string representation of the ObjectName.
     */
    private String objectName;

    /**
     * The agent identifier of the MBeanServer to retrieve.
     */
    private final String agentId;

    /**
     * True if this is a server.
     */
    private final boolean server;

    /**
     * True if a protocol-independent environment is used.
     * False if the environment of the default protocol is used.
     */
    private volatile boolean multiEnvironment;

    /**
     * Build a server configuration object with the given properties.
     * @param properties the properties need to construct the configuration
     * @param domainName the name of the JOnAS domain
     * @param serverName the name of the server for creating MBeans
     * @param agentId the agent identifier of the MBeanServer to retrieve
     * @throws ConfigurationException if properties are missing
     */
    protected ServerConfigurationImpl(
            final Properties properties, final String domainName, final String serverName, final String agentId)
    throws ConfigurationException {
        this.properties = properties;
        this.domainName = domainName;
        this.serverName = serverName;
        this.agentId = agentId;
        if (properties == null) {
            throw new ConfigurationException("Cannot build a server configuration without properties");
        }

        // Init values with properties object
        startNS = getBooleanValue(CarolDefaultValues.START_NS_KEY);
        startRMI = getBooleanValue(CarolDefaultValues.START_RMI_KEY);
        startJNDI = getBooleanValue(CarolDefaultValues.START_JNDI_KEY);

        server = System.getProperty(CarolDefaultValues.SERVER_MODE, "false").equalsIgnoreCase("true");

        logger.debug(System.getProperties());

        // Prefer the system property
        startCMI = System.getProperty(
                CarolDefaultValues.START_CMI_KEY,
                Boolean.toString(getBooleanValue(CarolDefaultValues.START_CMI_KEY)))
                .equalsIgnoreCase("true");

        Properties jvmProperties = new Properties();
        if (startRMI) {
            jvmProperties.setProperty("javax.rmi.CORBA.PortableRemoteObjectClass", CarolDefaultValues.MULTI_PROD);
        }

        if (startJNDI) {
            jvmProperties.setProperty(Context.INITIAL_CONTEXT_FACTORY, CarolDefaultValues.MULTI_JNDI);
        }

        // Check if CMI should be started
        if(startCMI) {
            initCMI();
        }

        String protocols = properties.getProperty(CarolDefaultValues.PROTOCOLS_KEY);
        boolean isMultiProtocols = false;
        if (protocols != null) {
            isMultiProtocols = (protocols.split(",").length > 1);
        }

        multiEnvironment = getBooleanValue(CarolDefaultValues.CAROL_PREFIX + "." + CarolDefaultValues.MULTI_RMI_PREFIX + ".env");

        String jndiPrefix = CarolDefaultValues.CAROL_PREFIX + "." + CarolDefaultValues.JNDI_PREFIX;
        String multiJvmPrefix = CarolDefaultValues.MULTI_RMI_PREFIX +  "." + CarolDefaultValues.CAROL_PREFIX + "." + "jvm";
        String singleJvmPrefix = CarolDefaultValues.CAROL_PREFIX + "." + CarolDefaultValues.JVM_PREFIX;
        for (Enumeration<?> e = properties.propertyNames(); e.hasMoreElements();) {
            String key = (String) e.nextElement();
            // JNDI JVM properties
            if (key.startsWith(jndiPrefix)) {
                jvmProperties.setProperty(key.substring(jndiPrefix.length() + 1), properties.getProperty(key));
            }

            // Interceptor multi (only in multi protocol)
            if (key.startsWith(multiJvmPrefix) && isMultiProtocols) {
                // extract key
                String newKey = key.substring(multiJvmPrefix.length() + 1);
                jvmProperties.setProperty(newKey, "");
            }

            // JVM properties
            if (key.startsWith(singleJvmPrefix)) {
                // extract key
                String newKey = key.substring(singleJvmPrefix.length() + 1);
                jvmProperties.setProperty(newKey, properties.getProperty(key));
            }

        }

        // Set jvm Properties previously defined
        for (Enumeration<?> e = jvmProperties.propertyNames(); e.hasMoreElements();) {
            String key = (String) e.nextElement();
            String value = jvmProperties.getProperty(key);
            System.setProperty(key, value);
            if (TraceCarol.isDebugCarol()) {
                TraceCarol.debugCarol("Set the JVM property '" + key + "' with the value '" + value + "'.");
            }
        }

    }

    /**
     * Initialize Carol to use CMI.
     * @throws ConfigurationException if properties are missing
     */
    protected void initCMI() throws ConfigurationException {
        // Get the name of implementation of InitialContextFactory to create the wrapper
        cmiInitialContextFactory = properties.getProperty(CarolDefaultValues.CMI_INITIAL_CONTEXT_FACTORY);

        // Check if CMI is executed on a server
        if (server) {

            // CMI is executed on a server that uses replication: if a setter class is done, CMI will be configured now
            String cmiPropertyName = CarolDefaultValues.CAROL_PREFIX + ".cmi."+ CarolDefaultValues.SETTER_CLASS;
            String setterClass = properties.getProperty(cmiPropertyName);
            if (setterClass != null) {
                String setterMethodProperties = properties.getProperty(CarolDefaultValues.CAROL_PREFIX + ".cmi."
                        + CarolDefaultValues.SETTER_METHOD_PROPERTIES);
                String setterMethodMBean = properties.getProperty(CarolDefaultValues.CAROL_PREFIX + ".cmi."
                        + CarolDefaultValues.SETTER_METHOD_MBEAN);

                try {
                    Class<?> clazz;
                    try {
                        clazz = Thread.currentThread().getContextClassLoader().loadClass(setterClass);
                    } catch (ClassNotFoundException cnfe) {
                        clazz = getClass().getClassLoader().loadClass(setterClass);
                    }

                    Method mMBean = clazz.getMethod(setterMethodMBean, String.class, String.class, String.class);
                    mMBean.invoke(null, domainName, serverName, agentId);

                    Method mProperties = clazz.getMethod(setterMethodProperties, Properties.class);
                    mProperties.invoke(null, properties);

                } catch (Exception ex) {
                    TraceCarol.error("Cannot set the CMI configuration.", ex);
                    throw new ConfigurationException("Cannot set the CMI configuration.", ex);
                }
            }
        }
    }

    /**
     * Get value of properties object.
     * @param key the key of the properties
     * @return value stored in a property object
     * @throws ConfigurationException if properties are missing
     */
    protected boolean getBooleanValue(String key) throws ConfigurationException {
        // properties cannot be null, check in constructor
        String s = properties.getProperty(key);
        if (s == null) {
            throw new ConfigurationException("Property '" + key
                    + "' was not found in the properties object of the protocol, properties are :'" + properties + "'");
        }
        return Boolean.parseBoolean(s.trim());
    }

    /**
     * @return true if JNDI has to be started (set of MultiORB ICTX factory)
     */
    public boolean isStartingJNDI() {
        return startJNDI;
    }

    /**
     * @return true if name services have to be launched)
     */
    public boolean isStartingNS() {
        return startNS;
    }

    /**
     * @return true if ProdelegateClass has to be set to MultiProDelegate
     */
    public boolean isStartingRMI() {
        return startRMI;
    }


    /**
     * @return true if CMI is used.
     */
    public boolean isStartCMI() {
        return startCMI;
    }

    /**
     * @return a InitialContextFactory name to use with CMI.
     */
    public String getCmiInitialContextFactory() {
        return cmiInitialContextFactory;
    }

    /**
     * Set if CMI is used.
     * @param startCMI true if CMI is used
     * @throws ConfigurationException if cmi cannot be configured
     */
    public synchronized void setStartCMI(final boolean startCMI) throws Exception {
        this.startCMI = startCMI;
        if(startCMI && cmiInitialContextFactory == null) {
            initCMI();
        }
    }

    /**
     * Set the object name of this mbean.
     * @param name the Object Name
     */
    public void setObjectName(final String objectName) {
        this.objectName = objectName;
    }

    /**
     * Get the object name of this mbean.
     */
    public String getObjectName() {
        return objectName;
    }

    /**
     * @return true if this is a server
     */
    public boolean isServer() {
        return server;
    }

    /**
     * Return true if a protocol-independent environment is used.
     * Otherwise the environment of the default protocol is used.
     * @return true if a protocol-independent environment is used
     */
    public boolean isMultiEnvironment() {
        return multiEnvironment;
    }

    /**
     * Set if a protocol-independent environment is used.
     * @param multiEnvironment true if a protocol-independent environment is used
     */
    public void setMultiEnvironment(final boolean multiEnvironment) {
        this.multiEnvironment = multiEnvironment;
    }

}
