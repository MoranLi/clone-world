/**
 * Copyright (C) 2005-2007 - Bull S.A.S.
 *
 * CAROL: Common Architecture for RMI ObjectWeb Layer
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: ConfigurationRepository.java 1534 2007-12-11 09:22:19Z loris $
 * --------------------------------------------------------------------------
 */
package org.ow2.carol.util.configuration;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.net.URL;
import java.net.URLConnection;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import org.ow2.carol.jndi.ns.NameServiceException;
import org.ow2.carol.jndi.ns.NameServiceManager;
import org.ow2.carol.util.mbean.MBeanUtils;

/**
 * This class handle all rmi configuration available at runtime for carol.<br>
 * Configurations could be added/removed after the startup of carol
 * @author Florent Benoit
 */
public final class ConfigurationRepository {

    /**
     * Logger
     */
    private static Log logger = LogFactory.getLog(ConfigurationRepository.class);

    /**
     * Default properties (content of carol-default.properties file)
     */
    private static Properties defaultProperties = null;

    /**
     * Configuration of the server (not the protocols)
     */
    private static ServerConfiguration serverConfiguration = null;

    /**
     * List of protocols configured (and that Carol can manage)
     */
    private static Map<String, Protocol> managedProtocols = null;

    /**
     * List of protocols used at runtime
     */
    private static Map<String, ProtocolConfiguration> managedConfigurations = null;

    /**
     * Thread Local for protocol context propagation
     */
    private static InheritableThreadLocal<ProtocolConfiguration> currentConfiguration = null;

    /**
     * Default configuration to fallback when there is a missing config in
     * thread
     */
    private static ProtocolConfiguration defaultConfiguration = null;

    /**
     * Properties of the carol configuration
     */
    private static Properties properties = null;

    /**
     * Initialization is done
     */
    private static boolean initDone = false;

    /**
     * No public constructor, singleton
     */
    private ConfigurationRepository() {
    }

    /**
     * Check that the configuration is done
     */
    protected static synchronized void checkInitialized() {
        if (!initDone) {
            try {
                if (logger.isDebugEnabled()) {
                    logger.debug("Do the configuration as the configuration was not yet done!");
                }
                init();
            } catch (ConfigurationException ce) {
                IllegalStateException ise = new IllegalStateException(
                        "Configuration of carol was not done and when trying to initialize it, it fails.");
                ise.initCause(ce);
                throw ise;
            }
        }
    }

    /**
     * Checks that carol is initialized
     */
    protected static void checkConfigured() {
        // check that init is done.
        checkInitialized();
        if (managedConfigurations == null) {
            throw new IllegalStateException("Cannot find a configuration, carol was not configured");
        }
    }

    /**
     * @return a list of current configurations
     */
    public static ProtocolConfiguration[] getConfigurations() {
        checkConfigured();
        ProtocolConfiguration[] configs =
            new ProtocolConfiguration[managedConfigurations.size()];
        return managedConfigurations.values().toArray(configs);

    }

    /**
     * Gets a configuration with the given name
     * @param configName name of the configuration
     * @return configuration object associated to the given name
     */
    public static ProtocolConfiguration getConfiguration(final String configName) {
        checkConfigured();
        return managedConfigurations.get(configName);
    }

    /**
     * Gets a protocol with the given name
     * @param protocolName name of the protocol
     * @return protocol object associated to the given name
     */
    public static Protocol getProtocol(final String protocolName) {
        checkConfigured();
        return managedProtocols.get(protocolName);
    }

    /**
     * Build a new configuration for a given protocol
     * @param configurationName the name of the configuration
     * @param protocolName name of the protocol
     * @return a new configuration object for a given protocol
     * @throws ConfigurationException if no configuration can be built
     */
    public static ProtocolConfiguration newConfiguration(
            final String configurationName, final String protocolName)
    throws ConfigurationException {
        checkConfigured();
        Protocol p = null;

        // Check that there is no configuration existing with the same name
        if (managedConfigurations.get(configurationName) != null) {
            throw new ConfigurationException("There is an existing configuration with the name '" + configurationName
                    + "'. Use another name.");
        }

        // Get configured protocol
        if (managedProtocols != null) {
            p = managedProtocols.get(protocolName);
        }
        if (p == null) {
            throw new ConfigurationException("Protocol '" + protocolName + "' doesn't exists in carol. Cannot build");
        }

        return new ProtocolConfigurationImpl(configurationName, p, new Properties(), serverConfiguration);
    }

    /**
     * Set the current configuration object
     * @param config the configuration to set as current configuration
     * @return previous value of the configuration which was set
     */
    public static ProtocolConfiguration setCurrentConfiguration(
            final ProtocolConfiguration config) {
        checkConfigured();
        ProtocolConfiguration old = getCurrentConfiguration();
        currentConfiguration.set(config);
        return old;
    }

    /**
     * @return current carol configuration
     */
    public static ProtocolConfiguration getCurrentConfiguration() {
        checkConfigured();
        ProtocolConfiguration protocolConfiguration = currentConfiguration.get();
        if (protocolConfiguration != null) {
            return protocolConfiguration;
        } else {
            return defaultConfiguration;
        }
    }

    /**
     * Initialize Carol configurations with the carol.properties URL
     * @param carolPropertiesFileURL URL referencing the configuration file
     * @throws ConfigurationException if no properties can be loaded
     */
    public static void init(final URL carolPropertiesFileURL)
    throws ConfigurationException {
        init(carolPropertiesFileURL, null, null);
    }

    /**
     * Initialize Carol configurations with MBeans
     * @param domainName the name of the JOnAS domain
     * @param serverName the name of the server for creating mbeans
     * @throws ConfigurationException if no properties can be loaded
     */
    public static void init(final String domainName, final String serverName)
    throws ConfigurationException {
        init(domainName, serverName, null);
    }

    /**
     * Initialize Carol configurations with MBeans
     * @param domainName the name of the JOnAS domain
     * @param serverName the name of the server for creating mbeans
     * @param agentId the agent identifier of the MBeanServer to retrieve
     * @throws ConfigurationException if no properties can be loaded
     */
    public static void init(final String domainName, final String serverName, final String agentId)
    throws ConfigurationException {
        init(Thread.currentThread().getContextClassLoader().getResource(CarolDefaultValues.CAROL_CONFIGURATION_FILE),
                domainName, serverName, agentId);
    }

    /**
     * Initialize Carol configurations with the carol.properties URL
     * @param carolPropertiesFileURL URL referencing the configuration file
     * @param domainName the name of the JOnAS domain
     * @param serverName the name of the server for creating mbeans
     * @throws ConfigurationException if no properties can be loaded
     */
    public static void init(
            final URL carolPropertiesFileURL, final String domainName, final String serverName)
    throws ConfigurationException {
        init(carolPropertiesFileURL, domainName, serverName, null);
    }

    /**
     * Initialize Carol configurations with the carol.properties URL
     * @param carolPropertiesFileURL URL referencing the configuration file
     * @param domainName the name of the JOnAS domain
     * @param serverName the name of the server for creating mbeans
     * @param agentId the agent identifier of the MBeanServer to retrieve
     * @throws ConfigurationException if no properties can be loaded
     */
    public static void init(
            final URL carolPropertiesFileURL, final String domainName, final String serverName, final String agentId)
    throws ConfigurationException {
        if (initDone) {
            return;
        }

        // Configure logger
        TraceCarol.configure();

        Properties carolProperties = getPropertiesFromURL(carolPropertiesFileURL);

        init(carolProperties, domainName, serverName, agentId);
    }

    /**
     * Initialize Carol configurations with the given properties
     * @param carolProperties properties to configure Carol
     * @param domainName the name of the JOnAS domain
     * @param serverName the name of the server for creating mbeans
     * @throws ConfigurationException if no properties can be loaded
     */
    public static void init(
            final Properties carolProperties, final String domainName, final String serverName)
    throws ConfigurationException {
        init(carolProperties, domainName, serverName, null);
    }

    /**
     * Initialize Carol configurations with the given properties
     * @param carolProperties properties to configure Carol
     * @param domainName the name of the JOnAS domain
     * @param serverName the name of the server for creating mbeans
     * @param agentId the agent identifier of the MBeanServer to retrieve
     * @throws ConfigurationException if no properties can be loaded
     */
    @SuppressWarnings("unchecked")
    public static void init(
            final Properties carolProperties, final String domainName, final String serverName, final String agentId)
    throws ConfigurationException {
        if (initDone) {
            return;
        }

        // Configure logger
        TraceCarol.configure();

        Properties carolDefaultProperties = getDefaultProperties();

        /*
         * Merge two properties file in following order : carol properties
         * overwrite default values
         */
        properties = mergeProperties(carolDefaultProperties, carolProperties);

        // Extract general configuration
        serverConfiguration =
            new ServerConfigurationImpl(properties, domainName, serverName, agentId);

        // Reinit protocols
        managedProtocols = new LinkedHashMap<String, Protocol>();
        managedConfigurations = new LinkedHashMap<String, ProtocolConfiguration>();

        // Reset thread local
        currentConfiguration = new InheritableThreadLocal<ProtocolConfiguration>();

        // Now build protocols objects by extracting them
        int propertyBeginLength = CarolDefaultValues.CAROL_PREFIX.length();
        int propertyEndLength = CarolDefaultValues.FACTORY_PREFIX.length();
        for (Enumeration<?> e = properties.propertyNames(); e.hasMoreElements();) {
            String key = (String) e.nextElement();
            // Detect protocol name on all matching carol.XXXX.context.factory
            // properties
            if (key.startsWith(CarolDefaultValues.CAROL_PREFIX) && key.endsWith(CarolDefaultValues.FACTORY_PREFIX)) {
                // Extract protocol name
                String protocolName = key.substring(propertyBeginLength + 1, key.length() - propertyEndLength - 1);
                // Get the implementation
                String prefixProtocol = CarolDefaultValues.CAROL_PREFIX + "." + protocolName + ".";
                String protocolClassName = properties.getProperty(prefixProtocol + CarolDefaultValues.PROTOCOL_CLASS_SUFFIX);

                // Build protocol
                if (logger.isDebugEnabled()) {
                    logger.debug("Build protocol object for protocol name found '" + protocolName + "'.");
                }
                Protocol protocol;
                if(protocolClassName != null ) {
                    Class<? extends Protocol> protocolClass;
                    try {
                        protocolClass = (Class<? extends Protocol>) Class.forName(protocolClassName);
                        Constructor<? extends Protocol> constructor =
                            protocolClass.getConstructor(String.class, Properties.class, Log.class, String.class, String.class);
                        protocol = constructor.newInstance(protocolName, properties, logger, domainName, serverName);
                    } catch (Exception e1) {
                        TraceCarol.error("Cannot build the protocol " + protocolName + "for class " + protocolClassName, e1);
                        throw new ConfigurationException(
                                "Cannot build the protocol " + protocolName + "for class " + protocolClassName, e1);
                    }
                } else {
                    protocol = new Protocol(protocolName, properties, logger, domainName, serverName);
                }
                managedProtocols.put(protocolName, protocol);

            }
        }

        /*
         * ... and finish with building configurations This is done by using
         * protocols chosen by user
         */

        // read property in carol properties file
        String protocols = properties.getProperty(CarolDefaultValues.PROTOCOLS_KEY);
        String defaultProtocol = properties.getProperty(CarolDefaultValues.DEFAULT_PROTOCOLS_KEY);
        if (defaultProtocol == null || defaultProtocol.equals("")) {
            throw new ConfigurationException("No default protocol defined with property '"
                    + CarolDefaultValues.DEFAULT_PROTOCOLS_KEY + "', check your carol configuration.");
        }
        if (protocols == null || protocols.equals("")) {
            logger.info("No protocols were defined for property '" + CarolDefaultValues.PROTOCOLS_KEY
                    + "', trying with default protocol = '" + defaultProtocol + "'.");
            protocols = defaultProtocol;
        }

        // for each protocol, build a configuration object
        String[] protocolsArray = protocols.split(",");

        for (String protocolName : protocolsArray) {

            // is it present ?
            Protocol protocol = managedProtocols.get(protocolName);
            if (protocol == null) {
                throw new ConfigurationException("Cannot find a protocol with name '" + protocolName
                        + "' in the list of available protocols.");
            }
            ProtocolConfiguration protoConfig = new ProtocolConfigurationImpl(protocolName, protocol, properties, serverConfiguration);
            managedConfigurations.put(protocolName, protoConfig);
        }

        // Check if the given default protocol is enabled
        if(!Arrays.asList(protocolsArray).contains(defaultProtocol)) {
            // Set the default configuration to the first available protocol
            if(protocolsArray.length != 1) {
                logger.info("The given defaut protocol is not enabled, so the first declared protocol, ie "
                        + protocolsArray[0] + ", will be used as default.");
            }
            defaultProtocol = protocolsArray[0];
        }

        // Set the default configuration to the default protocol
        defaultConfiguration = managedConfigurations.get(defaultProtocol);

        if (domainName != null && serverName != null) {
            initMbeans(domainName, serverName, agentId);
        }

        initDone = true;

        // If 'carol.start.ns=true' use the name service manager in order to start all the configured name services
        if(serverConfiguration.isStartingNS()) {
            try {
                NameServiceManager.getNameServiceManager().startNS();
            } catch (NameServiceException e) {
                TraceCarol.error("A name service was already started.", e);
            }
        }
    }

    /**
     * Add a configuration
     * @param protocolConfiguration the configuration to add
     * @throws ConfigurationException if the configuration exists
     */
    public static void addConfiguration(final ProtocolConfiguration protocolConfiguration)
    throws ConfigurationException {
        String protocolConfigName = protocolConfiguration.getName();
        if (managedConfigurations.get(protocolConfigName) != null) {
            throw new ConfigurationException("The configuration named '" + protocolConfigName + "' already exist.");
        }
        managedConfigurations.put(protocolConfigName, protocolConfiguration);
    }

    /**
     * Gets server configuration (made with carol-default.properties and
     * carol.properties file)
     * @return server configuration
     */
    public static ServerConfiguration getServerConfiguration() {
        checkConfigured();
        return serverConfiguration;
    }

    /**
     * Merge content of two properties object (second overwrite first values)
     * @param defaultValues default values
     * @param values new values
     * @return properties object with merge done
     */
    protected static Properties mergeProperties(
            final Properties defaultValues, final Properties values) {
        Properties p = new Properties();
        p.putAll(defaultValues);
        // overwrite some
        p.putAll(values);
        return p;
    }

    /**
     * Initialize Carol configurations with an URL of carol properties file
     * found with Classloader
     * @throws ConfigurationException if no properties can be loaded
     */
    public static void init() throws ConfigurationException {
        init(Thread.currentThread().getContextClassLoader().getResource(CarolDefaultValues.CAROL_CONFIGURATION_FILE));
    }

    /**
     * Initialize carol with default configuration file found in jar of carol
     * @return properties object corresponding to carol-default.properties file
     * @throws ConfigurationException if the properties file cannot be get
     */
    protected static Properties getDefaultProperties() throws ConfigurationException {
        if (defaultProperties == null) {
            // First, found the URL of this file
            URL defaultConfigurationFile = Thread.currentThread().getContextClassLoader().getResource(
                    CarolDefaultValues.CAROL_DEFAULT_CONFIGURATION_FILE);

            defaultProperties = getPropertiesFromURL(defaultConfigurationFile);
        }
        return defaultProperties;

    }

    /**
     * Gets a properties object based on given URL
     * @param url URL from where build properties object
     * @return properties object with data from the given URL
     * @throws ConfigurationException if properties cannot be built
     */
    protected static Properties getPropertiesFromURL(final URL url)
    throws ConfigurationException {
        if (url == null) {
            if (logger.isDebugEnabled()) {
                logger.debug("Return empty properties, URL is null");
            }
            return new Properties();
        }

        // Get inputStream + invalid cache
        InputStream is = null;
        try {
            URLConnection urlConnect = null;
            urlConnect = url.openConnection();
            // disable cache
            urlConnect.setDefaultUseCaches(false);

            is = urlConnect.getInputStream();
        } catch (IOException ioe) {
            throw new ConfigurationException("Invalid URL '" + url + "' : " + ioe.getMessage(), ioe);
        }

        // Check inpustream
        if (is == null) {
            throw new ConfigurationException("No inputstream for URL '" + url + "'.");
        }

        // load properties from URL
        Properties p = new Properties();
        try {
            p.load(is);
        } catch (IOException ioe) {
            throw new ConfigurationException("Could not load input stream of  URL '" + url + "' : " + ioe.getMessage());
        }

        // close inputstream
        try {
            is.close();
        } catch (IOException ioe) {
            throw new ConfigurationException("Cannot close inputStream", ioe);
        }

        return p;
    }

    /**
     * @return the default Configuration when no thread local is set.
     */
    public static ProtocolConfiguration getDefaultConfiguration() {
        checkConfigured();
        return defaultConfiguration;
    }

    /**
     * @return the properties used by Carol configuration.
     */
    public static Properties getProperties() {
        checkConfigured();
        return properties;
    }

    /**
     * @return the number of active protocols
     */
    public static int getActiveConfigurationsNumber() {
        checkConfigured();
        if (managedConfigurations != null) {
            return managedConfigurations.size();
        } else {
            return 0;
        }
    }

    /**
     * Add an interceptor at runtime for a given protocol.
     * @param protocolName protocol name
     * @param interceptorInitializer Interceptor initializer class name
     * @throws ConfigurationException if interceptor cannot be added
     */
    @Deprecated
    public static void addInterceptors(
            final String protocolName, final String interceptorInitializer)
    throws ConfigurationException {
        checkConfigured();
        Protocol protocol = getProtocol(protocolName);
        if (protocol == null) {
            logger.error("Cannot add interceptor on an unknown protocol '" + protocolName + "'.");
            throw new ConfigurationException("Cannot add interceptor on an unknown protocol '" + protocolName + "'.");
        }
        protocol.addInterceptor(interceptorInitializer);
    }

    /**
     * Add an interceptor at runtime for a given protocol.
     * @param protocolName protocol name
     * @param interceptorInitializer Interceptor initializer class
     * @throws ConfigurationException if interceptor cannot be added
     */
    public static void addInterceptors(
            final String protocolName, final Class<?> interceptorInitializer)
    throws ConfigurationException {
        checkConfigured();
        Protocol protocol = getProtocol(protocolName);
        if (protocol == null) {
            logger.error("Cannot add interceptor on an unknown protocol '" + protocolName + "'.");
            throw new ConfigurationException("Cannot add interceptor on an unknown protocol '" + protocolName + "'.");
        }
        protocol.addInterceptor(interceptorInitializer);
    }

    /**
     * Remove an interceptor at runtime for a given protocol.
     * @param protocolName protocol name
     * @param interceptorInitializer Interceptor initializer class
     * @throws ConfigurationException if interceptor cannot be added
     */
    public static void removeInterceptors(
            final String protocolName, final Class<?> interceptorInitializer)
    throws ConfigurationException {
        checkConfigured();
        Protocol protocol = getProtocol(protocolName);
        if (protocol == null) {
            logger.error("Cannot remove interceptor on an unknown protocol '" + protocolName + "'.");
            throw new ConfigurationException("Cannot remove interceptor on an unknown protocol '" + protocolName + "'.");
        }
        protocol.removeInterceptor(interceptorInitializer);
    }

    /**
     * Init the MBean for each configuration
     * @param domainName the name of the JOnAS domain
     * @param serverName the name of the server for creating mbeans
     * @param agentId the agent identifier of the MBeanServer to retrieve
     * @throws ConfigurationException if MBeans are not created
     */
    protected static void initMbeans(
            final String domainName, final String serverName, final String agentId)
    throws ConfigurationException {

        MBeanUtils.registerServerConfigurationMBean(
                (ServerConfigurationImplMBean) serverConfiguration, logger, domainName, serverName, agentId);

        for (String protocolName : managedConfigurations.keySet()) {
            ProtocolConfiguration protocolConfiguration = managedConfigurations.get(protocolName);
            if (protocolConfiguration instanceof ProtocolConfigurationImplMBean) {
                MBeanUtils.registerProtocolConfigurationMBean((ProtocolConfigurationImplMBean) protocolConfiguration,
                        logger, domainName, serverName, agentId);
            }
        }

    }

    /**
     * Return true if CMI is globally enabled.
     * Nevertheless, it can be disabled for a given protocol.
     * @return true if CMI is globally enabled
     */
    public static boolean isCMIEnabled() {
        return serverConfiguration.isStartCMI();
    }

    /**
     * Return true if a protocol-independent environment is used.
     * Otherwise the environment of the default protocol is used.
     * @return true if a protocol-independent environment is used
     */
    public static boolean isMultiEnvironment() {
        return serverConfiguration.isMultiEnvironment();
    }

}
