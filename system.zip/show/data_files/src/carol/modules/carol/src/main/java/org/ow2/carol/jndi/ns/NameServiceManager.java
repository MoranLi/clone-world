/**
 * Copyright (C) 2002-2007 - INRIA (www.inria.fr)
 *
 * CAROL: Common Architecture for RMI ObjectWeb Layer
 *
 * This library is developed inside the ObjectWeb Consortium,
 * http://www.ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: NameServiceManager.java 1513 2007-11-25 12:22:17Z loris $
 * --------------------------------------------------------------------------
 */
package org.ow2.carol.jndi.ns;

import java.util.LinkedHashMap;
import java.util.Map;

import org.ow2.carol.util.configuration.ConfigurationRepository;
import org.ow2.carol.util.configuration.Protocol;
import org.ow2.carol.util.configuration.ProtocolConfiguration;
import org.ow2.carol.util.configuration.TraceCarol;

/**
 * Class <code> NameServicemanager </code> is the CAROL Name Service manager.
 * This is the carol API for Name services management
 * @author Guillaume Riviere
 */
public final class NameServiceManager {

    /**
     * Default sleep value
     */
    private static final int SLEEP_VALUE = 10000;

    /**
     * Name Service Hashtable
     */
    private Map<String, NameService> nsTable;

    /**
     * Singleton.
     */
    private static NameServiceManager singleton =  null;

    /**
     * Private constructor for unicity.
     */
    private NameServiceManager() {
        if (TraceCarol.isDebugJndiCarol()) {
            TraceCarol.debugJndiCarol("NameServiceManager.NameServiceManager()");
        }

        // List of current name server
        nsTable = new LinkedHashMap<String, NameService>();
        ProtocolConfiguration[] protocolConfigurations = ConfigurationRepository.getConfigurations();
        for (ProtocolConfiguration protocolConfiguration : protocolConfigurations) {
            String configurationName = protocolConfiguration.getName();
            Protocol protocol = protocolConfiguration.getProtocol();
            NameService nsC = null;
            try {
                nsC = (NameService) Class.forName(protocol.getRegistryClassName()).newInstance();
            } catch (Exception e) {
                String msg = "Cannot instantiate registry class '" + protocol.getRegistryClassName() + "'";
                TraceCarol.error(msg, e);
            }
            nsC.setPort(protocolConfiguration.getPort());
            nsC.setHost(protocolConfiguration.getHost());
            nsC.setConfigProperties(protocolConfiguration.getProperties());
            // Add the NameService in the list of configurations
            nsTable.put(configurationName, nsC);
        }
    }

    /**
     * @return the name service manager
     */
    public static NameServiceManager getNameServiceManager() {
        if(singleton == null) {
            singleton = new NameServiceManager();
        }
        return singleton;
    }

    /**
     * Start all names service
     * @throws NameServiceException if one of the name services is already start
     */
    public void startNS() throws NameServiceException {
        if (TraceCarol.isDebugJndiCarol()) {
            TraceCarol.debugJndiCarol("NameServiceManager.startNS()");
        }
        // test if one of the ns is already started
        for (String k : nsTable.keySet()) {
            NameService currentNS = nsTable.get(k);
            if (currentNS.isStarted()) {
                throw new NameServiceException("The " + k + " name service is already started");
            }
        }
        // Start all name services
        startNonStartedNS();
    }

    /**
     * Start all non-started names service
     */
    public void startNonStartedNS() {
        if (TraceCarol.isDebugJndiCarol()) {
            TraceCarol.debugJndiCarol("NameServiceManager.startNonStartedNS()");
        }
        // start name services
        for (String k : nsTable.keySet()) {
            NameService currentNS = nsTable.get(k);

            // Set the current configuration
            ProtocolConfiguration pc = ConfigurationRepository.getConfiguration(k);
            ConfigurationRepository.setCurrentConfiguration(pc);
            try {
                currentNS.start();
                if (TraceCarol.isInfoCarol()) {
                    TraceCarol.infoCarol("Name service for " + k + " is started on port " + currentNS.getPort());
                }
            } catch (NameServiceException nse) {
                // do nothing, just trace
                if (TraceCarol.isDebugJndiCarol()) {
                    TraceCarol
                            .debugJndiCarol("NameServiceManager.startNonStartedNS() can not start name service: " + k);
                }
            }
        }
    }

    /**
     * Stop all name services
     * @throws NameServiceException if an exception occurs at stopping time
     */
    public void stopNS() throws NameServiceException {
        if (TraceCarol.isDebugJndiCarol()) {
            TraceCarol.debugJndiCarol("NameServiceManager.stopNS()");
        }
        // stop name services
        for (String k : nsTable.keySet()) {
            NameService currentNS = nsTable.get(k);
            currentNS.stop();
        }
    }

    /**
     * @return true if the name service manager is started
     */
    public boolean isStarted() {
        // test if one of the ns is already started
        for (String k : nsTable.keySet()) {
            NameService currentNS = nsTable.get(k);
            if (currentNS.isStarted()) {
                return true;
            }
        }
        return false;
    }

    /**
     * Main function: start all registry and wait for control C function
     * @param args arguments
     */
    public static void main(String[] args) {

        // configure logging
        TraceCarol.configure();

        final NameServiceManager nameServiceManager = NameServiceManager.getNameServiceManager();
        try {
            nameServiceManager.startNonStartedNS();
            // add a shutdown hook for this process
            Runtime.getRuntime().addShutdownHook(new Thread() {

                public void run() {
                    try {
                        nameServiceManager.stopNS();
                    } catch (Exception e) {
                        TraceCarol.error("Carol Naming ShutdownHook problem", e);
                    }
                }
            });
            while (true) {
                Thread.sleep(SLEEP_VALUE);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
