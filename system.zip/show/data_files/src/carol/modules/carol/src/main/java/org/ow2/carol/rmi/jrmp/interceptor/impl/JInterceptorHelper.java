/**
 * Copyright (C) 2002-2007 - INRIA (www.inria.fr)
 *
 * CAROL: Common Architecture for RMI ObjectWeb Layer
 *
 * This library is developed inside the OW2 Consortium,
 * http://www.ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: JInterceptorHelper.java 1515 2007-11-25 16:18:55Z loris $
 * --------------------------------------------------------------------------
 */
package org.ow2.carol.rmi.jrmp.interceptor.impl;

//java import
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.rmi.server.UID;
import java.util.ArrayList;
import java.util.List;

import org.ow2.carol.rmi.jrmp.interceptor.spi.JClientRequestInterceptor;
import org.ow2.carol.rmi.jrmp.interceptor.spi.JServerRequestInterceptor;
import org.ow2.carol.util.configuration.TraceCarol;

/**
 * Class <code>JInterceptorHelper</code> is the CAROL JRMP Interceptor Helper
 * this class is used by the other pakage class to manage interceptions
 * @author Guillaume Riviere (Guillaume.Riviere@inrialpes.fr)
 * @version 1.0, 15/07/2002
 */
public abstract class JInterceptorHelper {

    // int value for context propagation optimization
    protected static final int NO_CTX = 0;

    protected static final int REMOTE_CTX = 1;

    protected static final int LOCAL_CTX = 2;

    /**
     * The Inet Adress
     */
    protected static byte[] ia = null;

    /**
     * The spaceID
     */
    protected static UID spaceID = null;

    /**
     * @return byte [] InetAddress
     */
    public static byte[] getInetAddress() {
        if(ia == null) {
            try {
                ia = InetAddress.getLocalHost().getAddress();
            } catch (UnknownHostException e) {
                TraceCarol.error("Cannot get the address of localhost", e);
            }
        }
        return ia;
    }

    /**
     * @return space UID
     */
    public static UID getSpaceID() {
        if(spaceID == null) {
            spaceID = new UID();
        }
        return spaceID;
    }

    public static JInterceptorsKind getInterceptorsByType(final List<JInterceptorsGroup> jinterceptorsList) {
        ArrayList<JServerRequestInterceptor> sis = new ArrayList<JServerRequestInterceptor>();
        ArrayList<JClientRequestInterceptor> cis = new ArrayList<JClientRequestInterceptor>();
        ArrayList<String> jinitializers = new ArrayList<String>();
        for(JInterceptorsGroup jInterceptors : jinterceptorsList) {
            jinitializers.add(jInterceptors.getInitializer());
            sis.addAll(jInterceptors.getSis());
            cis.addAll(jInterceptors.getCis());
        }
        return new JInterceptorsKind(jinitializers, sis, cis);
    }
}
