/**
 * Copyright (C) 2007 - Bull S.A.S.
 * Copyright (C) 2002,2004 - INRIA (www.inria.fr)
 *
 * CAROL: Common Architecture for RMI ObjectWeb Layer
 *
 * This library is developed inside the ObjectWeb Consortium,
 * http://www.ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: JUnicastServerRef.java 1515 2007-11-25 16:18:55Z loris $
 * --------------------------------------------------------------------------
 */
package org.ow2.carol.rmi.jrmp.server;

// sun import
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.RemoteCall;
import java.rmi.server.RemoteRef;
import java.util.List;

import org.ow2.carol.rmi.jrmp.interceptor.impl.JInterceptorsKind;
import org.ow2.carol.rmi.jrmp.interceptor.impl.JInterceptorHelper;
import org.ow2.carol.rmi.jrmp.interceptor.impl.JInterceptorsGroup;
import org.ow2.carol.rmi.jrmp.interceptor.impl.JServerInterceptorHelper;
import org.ow2.carol.rmi.jrmp.interceptor.spi.JClientRequestInterceptor;
import org.ow2.carol.rmi.jrmp.interceptor.spi.JServerRequestInterceptor;

import sun.rmi.server.UnicastServerRef;
import sun.rmi.transport.LiveRef;

/**
 * Class <code>JUnicastServerRef</code> implements the remote reference layer
 * server-side behavior for remote objects exported with the JUnicastRef
 * reference type.
 * @author Guillaume Riviere (Guillaume.Riviere@inrialpes.fr)
 * @version 1.0, 15/07/2002
 */
@SuppressWarnings("deprecation")
public class JUnicastServerRef extends UnicastServerRef {

    /**
     * ServerRequestInterceptor array
     */
    protected final JServerRequestInterceptor[] sis;

    /**
     * ClientRequestInterceptor array
     */
    protected final JClientRequestInterceptor[] cis;

    /**
     * Initializer classnames array.
     */
    protected final String[] initializers;

    private int localId = -2;

    /**
     * Constructor with interceptor
     * @param ref the live reference
     * @param sis the server interceptor array
     * @param cis the client interceptor array
     * @param initializers
     */
    public JUnicastServerRef(final LiveRef ref, final List<JInterceptorsGroup> jinterceptorsList) {
        super(ref);
        JInterceptorsKind interceptorsByType =
            JInterceptorHelper.getInterceptorsByType(jinterceptorsList);
        List<JServerRequestInterceptor> sistmp = interceptorsByType.getJServerRequestInterceptors();
        this.sis = sistmp.toArray(new JServerRequestInterceptor[sistmp.size()]);
        List<JClientRequestInterceptor> cistmp = interceptorsByType.getJClientRequestInterceptors();
        this.cis = cistmp.toArray(new JClientRequestInterceptor[cistmp.size()]);
        List<String> initmp = interceptorsByType.getInitializers();
        this.initializers = initmp.toArray(new String[initmp.size()]);
    }

    /**
     * Constructor with interceptor
     * @param port the port reference
     * @param sis the server interceptor array
     * @param cis the client interceptor array
     * @param initializers
     */
    public JUnicastServerRef(final int port, final List<JInterceptorsGroup> jinterceptorsList) {
        super(new LiveRef(port));
        JInterceptorsKind interceptorsByType =
            JInterceptorHelper.getInterceptorsByType(jinterceptorsList);
        List<JServerRequestInterceptor> sistmp = interceptorsByType.getJServerRequestInterceptors();
        this.sis = sistmp.toArray(new JServerRequestInterceptor[sistmp.size()]);
        List<JClientRequestInterceptor> cistmp = interceptorsByType.getJClientRequestInterceptors();
        this.cis = cistmp.toArray(new JClientRequestInterceptor[cistmp.size()]);
        List<String> initmp = interceptorsByType.getInitializers();
        this.initializers = initmp.toArray(new String[initmp.size()]);
    }

    /**
     * get the ref class name
     * @return String the class name
     */
    @Override
    public String getRefClass(ObjectOutput out) {
        super.getRefClass(out);
        return "org.ow2.carol.rmi.jrmp.server.JUnicastServerRef";
    }

    /**
     * use a different kind of RemoteRef instance. This method is used by the
     * remote client to get the Client reference
     * @return remote Ref the remote reference
     */
    @Override
    protected RemoteRef getClientRef() {
        return new JUnicastRef(ref, cis, initializers, localId);
    }

    /**
     * @param obj
     * @param localId
     * @param object
     * @return
     */
    public Remote exportObject(Remote obj, Object object, int localId) throws RemoteException {
        this.localId = localId;
        return super.exportObject(obj, object);
    }

    /**
     * override unmarshalCustomCallData to receive and establish contexts sent
     * by the client
     * @param in the object input
     */
    @Override
    protected void unmarshalCustomCallData(ObjectInput in) throws IOException, ClassNotFoundException {
        JServerInterceptorHelper.receive_request(in, sis);
        super.unmarshalCustomCallData(in);
    }

    /**
     * override dispatch to use a specific thread factory
     * @param obj the remote object
     * @param call the remote call on this object
     */
    @Override
    public void dispatch(Remote obj, RemoteCall call) throws IOException {
        super.dispatch(obj, new JRemoteServerCall(call, sis));
    }
}
