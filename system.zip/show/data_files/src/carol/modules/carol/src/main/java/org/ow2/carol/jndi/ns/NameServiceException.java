/**
 * Copyright (C) 2002-2007 - INRIA (www.inria.fr)
 *
 * CAROL: Common Architecture for RMI ObjectWeb Layer
 *
 * This library is developed inside the ObjectWeb Consortium,
 * http://www.ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: NameServiceException.java 1310 2007-10-10 08:53:11Z loris $
 * --------------------------------------------------------------------------
 */
package org.ow2.carol.jndi.ns;

/**
 * Class <code> NameServiceException </code> throw when there is a problem in
 * the carol name service
 * @author Guillaume Riviere (Guillaume.Riviere@inrialpes.fr)
 * @version 1.0, 15/07/2002
 */
public class NameServiceException extends Exception {

    /**
     * Id for serializable class.
     */
    private static final long serialVersionUID = -188932457881982181L;

    /**
     * constructor with a the detail message
     * @param s exception string
     */
    public NameServiceException(String s) {
        super(s);
    }

}
