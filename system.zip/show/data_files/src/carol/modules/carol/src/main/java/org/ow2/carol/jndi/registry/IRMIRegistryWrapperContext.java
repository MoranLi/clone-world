/**
 * Copyright (C) 2005-2007 - Bull S.A.S.
 *
 * CAROL: Common Architecture for RMI ObjectWeb Layer
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: IRMIRegistryWrapperContext.java 1532 2007-12-09 18:47:25Z loris $
 * --------------------------------------------------------------------------
 */
package org.ow2.carol.jndi.registry;

import java.util.Hashtable;

import javax.naming.Context;

import org.ow2.carol.jndi.ns.IRMIRegistry;
import org.ow2.carol.jndi.spi.IRMIContextWrapperFactory;

/**
 * Wrapper on a Registry object and implementing Context
 * @author Guillaume Riviere
 * @author Florent Benoit (Refactoring)
 */
public class IRMIRegistryWrapperContext extends AbsRegistryWrapperContext implements Context {

    /**
     * Create a local context for the registry
     * @param env hashtable used
     */
    public IRMIRegistryWrapperContext(Hashtable<Object, Object> env) {
        super(env, IRMIRegistry.getRegistry(), IRMIContextWrapperFactory.class.getName());
    }

}
