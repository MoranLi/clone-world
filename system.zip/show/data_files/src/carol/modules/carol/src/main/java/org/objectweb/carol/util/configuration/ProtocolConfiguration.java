/**
 * Copyright (C) 2005-2007 - Bull S.A.S.
 *
 * CAROL: Common Architecture for RMI ObjectWeb Layer
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: ProtocolConfiguration.java 1272 2007-09-11 11:43:56Z loris $
 * --------------------------------------------------------------------------
 */
package org.objectweb.carol.util.configuration;

import java.util.Properties;


/**
 * This interface defines an rmi configuration that is used by Carol.
 * @author Florent Benoit
 */
@Deprecated
public interface ProtocolConfiguration extends org.ow2.carol.util.configuration.ProtocolConfiguration {

    /**
     * @return the protocol used by this configuration.
     */
    Protocol getProtocol();

    /**
     * Configure this configuration with a given properties object
     * @param properties given properties
     * @throws ConfigurationException if the given config is invalid
     */
    void configure(Properties properties) throws ConfigurationException;
}
