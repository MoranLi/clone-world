/**
 * Copyright (C) 2005-2007 - Bull S.A.S.
 *
 * CAROL: Common Architecture for RMI ObjectWeb Layer
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: Protocol.java 1528 2007-12-05 14:40:22Z loris $
 * --------------------------------------------------------------------------
 */
package org.ow2.carol.util.configuration;

import java.lang.reflect.Method;
import java.util.Properties;

import javax.rmi.CORBA.PortableRemoteObjectDelegate;

import org.apache.commons.logging.Log;

/**
 * This class defines common attributes of a protocol for Carol.<br>
 * An rmi configuration relies on a protocol by specifying properties. For
 * example a protocol is composed of a Prodelegate Implementation class, a
 * registry class, etc.<br>
 * But the PROVIDER_URL could be different. This is done in Configuration
 * object. (one protocol could be associated to different configurations)<br>
 * ie : JRMP --> jrmp1 with localhost:1099, jrmp2 with localhost:1100
 * @author Florent Benoit
 */
public class Protocol {

    /**
     * Name of this protocol
     */
    private final String name;

    /**
     * Properties of this protocol
     */
    private final Properties properties;

    /**
     * PortableRemoteObject object
     */
    private PortableRemoteObjectDelegate portableRemoteObjectDelegate = null;

    /**
     * Name of the class of PortableRemoteObject
     */
    private final String portableRemoteObjectClassName;

    /**
     * Context.INITIAL_CONTEXT_FACTORY class implementation
     */
    private final String initialContextFactoryClassName;

    /**
     * Registry class (implementing org.ow2.carol.jndi.ns.NameService
     * class)
     */
    private final String registryClassName;

    /**
     * Prefix for interceptors
     */
    private final String interceptorNamePrefix;

    /**
     * Gets value of properties object
     * @param key the key of the properties
     * @return value stored in a property object
     * @throws ConfigurationException if properties are missing
     */
    protected String getValue(final String key) throws ConfigurationException {
        // properties cannot be null, check in constructor
        String s = properties.getProperty(key);
        if (s == null) {
            throw new ConfigurationException("Property '" + key + "' was not found in the properties object of the protocol, properties are :'" + properties + "'");
        }
        return s;
    }

    @Deprecated
    protected Protocol() {
        name = null;
        properties = null;
        portableRemoteObjectClassName = null;
        initialContextFactoryClassName = null;
        registryClassName = null;
        interceptorNamePrefix = null;
    }

    /**
     * Build a new protocol object with given parameters
     * @param name the name of this protocol
     * @param properties properties of this protocol
     * @param logger logger
     * @param domainName the name of the JOnAS domain
     * @param serverName the name of the server for creating mbeans
     * @throws ConfigurationException if properties are missing
     */
    public Protocol(
            final String name, final Properties properties, final Log logger, final String domainName, final String serverName)
        throws ConfigurationException {
        if (name == null || "".equals(name)) {
            throw new ConfigurationException("Cannot build a protocol with null or empty name");
        }
        this.name = name;

        if (properties == null) {
            throw new ConfigurationException("Cannot build a new protocol without properties");
        }
        this.properties = properties;

        String dName, sName;

        if (domainName == null) {
            dName = "defaultDomain";
        } else {
            dName = domainName;
        }

        if (serverName == null) {
            sName = "defaultServer";
        } else {
            sName = serverName;
        }

        String prefixProtocol = CarolDefaultValues.CAROL_PREFIX + "." + name + ".";

        // PRODelegate
        portableRemoteObjectClassName = getValue(prefixProtocol + CarolDefaultValues.PRO_PREFIX);

        // Initial Context factory
        this.initialContextFactoryClassName = getValue(prefixProtocol + CarolDefaultValues.FACTORY_PREFIX);

        // Registry class
        this.registryClassName = getValue(prefixProtocol + CarolDefaultValues.NS_PREFIX);

        // JVM interceptors
        interceptorNamePrefix = properties.getProperty(CarolDefaultValues.CAROL_PREFIX + "." + name + "."
                + CarolDefaultValues.INTERCEPTOR_PKGS_PREFIX);

        String interceptorValues = properties.getProperty(CarolDefaultValues.CAROL_PREFIX + "." + name + "."
                + CarolDefaultValues.INTERCEPTOR_VALUES_PREFIX);

        // set the jvm interceptors flag
        if ((interceptorNamePrefix != null) && (interceptorValues != null)) {
            //Parse jvm the properties
            String[] values = interceptorValues.split(",");
            for (String value : values) {
                addInterceptor(value);
            }
        }

        // set the properties in the underlying protocol if needed
        String setterClass = properties.getProperty(CarolDefaultValues.CAROL_PREFIX + "." + name + "."
                + CarolDefaultValues.SETTER_CLASS);

        if (setterClass != null) {
            String setterMethodProperties = getValue(CarolDefaultValues.CAROL_PREFIX + "." + name + "."
                + CarolDefaultValues.SETTER_METHOD_PROPERTIES);
            String setterMethodMBean = getValue(CarolDefaultValues.CAROL_PREFIX + "." + name + "."
                    + CarolDefaultValues.SETTER_METHOD_MBEAN);

            try {
                Class<?> clazz = Thread.currentThread().getContextClassLoader().loadClass(setterClass);

                Method mProperties = clazz.getMethod(setterMethodProperties, Properties.class);
                mProperties.invoke(null, properties);

                Method mMBean = clazz.getMethod(setterMethodMBean, String.class, String.class);
                mMBean.invoke(null, dName, sName);

            } catch (ClassNotFoundException cnfe) {
                if (logger.isDebugEnabled()) {
                    logger.debug(name + "is not available, don't configure it.");
                }
            } catch (NoClassDefFoundError ncdfe) {
                if (logger.isDebugEnabled()) {
                    logger.debug(name + "is not available, don't configure it.");
                }
            } catch (Exception ex) {
                TraceCarol.error("Cannot set the " + name + " configuration.", ex);
                throw new ConfigurationException("Cannot set the " + name + " configuration.", ex);
            }
        }
    }

    /**
     * Add an interceptor for the given protocol by the static way.
     * @param interceptorInitializer the classname of the interceptor initializer
     */
    @Deprecated
    public void addInterceptor(final String interceptorInitializer) {
        System.setProperty(interceptorNamePrefix + "." + interceptorInitializer, "");
        if (TraceCarol.isDebugCarol()) {
            TraceCarol.debugCarol("Setting interceptor " + interceptorNamePrefix + "." + interceptorInitializer + "/");
        }
    }

    /**
     * Add an interceptor for the given protocol by the dynamic way.
     * @param jinitClass the class of the interceptor initializer
     */
    public void addInterceptor(final Class<?> jinitClass) {
        TraceCarol.error("The protocol " + name + "doesn't support dynamic interceptors.");
        throw new UnsupportedOperationException(
                "The protocol " + name + "doesn't support dynamic interceptors.");
    }

    /**
     * Remove an interceptor for the given protocol by the dynamic way.
     * @param jinitClass the class of the interceptor initializer
     */
    public void removeInterceptor(final Class<?> jinitClass) {
        TraceCarol.error("The protocol " + name + "doesn't support dynamic interceptors.");
        throw new UnsupportedOperationException(
                "The protocol " + name + "doesn't support dynamic interceptors.");
    }

    /**
     * @return the initialContextFactory ClassName.
     */
    public String getInitialContextFactoryClassName() {
        return initialContextFactoryClassName;
    }

    /**
     * @return the registry ClassName.
     */
    public String getRegistryClassName() {
        return registryClassName;
    }

    /**
     * @return the portableRemoteObject delegate.
     */
    public PortableRemoteObjectDelegate getPortableRemoteObject() {
        if (portableRemoteObjectDelegate != null) {
            return portableRemoteObjectDelegate;
        }
        try {
            Class<?> clazz = Thread.currentThread().getContextClassLoader().loadClass(portableRemoteObjectClassName);
            portableRemoteObjectDelegate = (PortableRemoteObjectDelegate) clazz.newInstance();
        } catch (Exception e) {
            IllegalStateException newEx = new IllegalStateException("Cannot build PortableRemoteObjectDelegate class '" + portableRemoteObjectClassName + "'");
            newEx.initCause(e);
            throw newEx;
        }

        return portableRemoteObjectDelegate;
    }

    /**
     * @return the name of this protocol.
     */
    public String getName() {
        return name;
    }

}
