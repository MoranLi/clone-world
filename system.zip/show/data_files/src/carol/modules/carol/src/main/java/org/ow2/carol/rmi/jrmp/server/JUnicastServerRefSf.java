/**
 * Copyright (C) 2007 - Bull S.A.S.
 * Copyright (C) 2002,2004 - INRIA (www.inria.fr)
 *
 * CAROL: Common Architecture for RMI ObjectWeb Layer
 *
 * This library is developed inside the ObjectWeb Consortium,
 * http://www.ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: JUnicastServerRefSf.java 1515 2007-11-25 16:18:55Z loris $
 * --------------------------------------------------------------------------
 */
package org.ow2.carol.rmi.jrmp.server;

//sun import
import java.io.ObjectOutput;
import java.rmi.server.RMIClientSocketFactory;
import java.rmi.server.RMIServerSocketFactory;
import java.rmi.server.RemoteRef;
import java.util.List;

import org.ow2.carol.rmi.jrmp.interceptor.impl.JInterceptorsGroup;

import sun.rmi.transport.LiveRef;

/**
 * Class <code>JUnicastServerRefSf</code> implements the remote reference
 * layer server-side behavior for remote objects exported with the JUnicastRefSf
 * reference type.
 * @author Guillaume Riviere (Guillaume.Riviere@inrialpes.fr)
 * @version 1.0, 15/07/2002
 */
public final class JUnicastServerRefSf extends JUnicastServerRef {

    /**
     * Constructor with interceptor Create a new Unicast Server RemoteRef.
     * @param liveRef the live reference
     * @param sis the server interceptor array
     * @param cis the client interceptor array
     * @param initializers
     */
    public JUnicastServerRefSf(final LiveRef ref, final List<JInterceptorsGroup> jinterceptorsList) {
        super(ref, jinterceptorsList);
    }

    /**
     * Constructor with interceptor and custom sockets factories
     * @param port the port reference
     * @param csf the client socket factory
     * @param sf the server socket factory
     * @param sis the server interceptor array
     * @param cis the client interceptor array
     * @param initializers
     */
    public JUnicastServerRefSf(
            final int port, final RMIClientSocketFactory csf, final RMIServerSocketFactory ssf, final List<JInterceptorsGroup> jinterceptorsList) {
        super(new LiveRef(port, csf, ssf), jinterceptorsList);
    }

    /**
     * get the ref class name
     * @return String the class name
     */
    @Override
    public String getRefClass(final ObjectOutput out) {
        super.getRefClass(out);
        return "org.ow2.carol.rmi.jrmp.server.JUnicastServerRefSf";
    }

    /**
     * use a different kind of RemoteRef instance
     * @return remoet Ref the remote reference
     */
    @Override
    protected RemoteRef getClientRef() {
        return new JUnicastRefSf(ref, cis, initializers, -2);
    }
}
