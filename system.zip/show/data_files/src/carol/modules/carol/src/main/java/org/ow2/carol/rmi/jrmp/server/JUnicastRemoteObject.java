/**
 * Copyright (C) 2007 Bull S.A.S.
 * Copyright (C) 2002,2004 - INRIA (www.inria.fr)
 *
 * CAROL: Common Architecture for RMI ObjectWeb Layer
 *
 * This library is developed inside the ObjectWeb Consortium,
 * http://www.ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: JUnicastRemoteObject.java 1515 2007-11-25 16:18:55Z loris $
 * --------------------------------------------------------------------------
 */
package org.ow2.carol.rmi.jrmp.server;

import java.rmi.NoSuchObjectException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.server.RMIClientSocketFactory;
import java.rmi.server.RMIServerSocketFactory;
import java.rmi.server.RemoteServer;
import java.rmi.server.RemoteStub;
import java.rmi.server.ServerCloneException;
import java.util.List;

import org.ow2.carol.rmi.jrmp.interceptor.impl.JInterceptorsGroup;
import org.ow2.carol.util.configuration.CarolDefaultValues;

import sun.rmi.transport.ObjectTable;

/**
 * Class Extension of <code>UnicastRemoteObject</code> CAROL class ensuring
 * the JRMP context propagation Unicast Reference ensuring context propagation
 * with custom sockets
 * @author Guillaume Riviere (Guillaume.Riviere@inrialpes.fr)
 * @version 1.0, 15/07/2002
 */
public class JUnicastRemoteObject extends RemoteServer {

    /**
     * Id for serializable class.
     */
    private static final long serialVersionUID = 5385452936766764864L;

    protected RMIClientSocketFactory csf = null;

    protected RMIServerSocketFactory ssf = null;

    protected JUnicastRemoteObject(final List<JInterceptorsGroup> jinterceptorsList) throws RemoteException {
        // search in the jvm properties if the port number properties exist
        this(0, jinterceptorsList);
    }

    protected JUnicastRemoteObject(
            final int p, final List<JInterceptorsGroup> jinterceptorsList) throws RemoteException {
        JUnicastRemoteObject.exportObject(this, p, jinterceptorsList);
    }

    protected JUnicastRemoteObject(
            final int p, final RMIClientSocketFactory csf, final RMIServerSocketFactory ssf, final List<JInterceptorsGroup> jinterceptorsList)
    throws RemoteException {
        this.csf = csf;
        this.ssf = ssf;
        JUnicastRemoteObject.exportObject(this, p, csf, ssf, jinterceptorsList);
    }

    // exports methods
    protected void exportObject(final List<JInterceptorsGroup> jinterceptorsList) throws RemoteException {
        if (csf == null && ssf == null) {
            JUnicastRemoteObject.exportObject(this, 0, jinterceptorsList);
        } else {
            JUnicastRemoteObject.exportObject(this, 0, csf, ssf, jinterceptorsList);
        }
    }

    public static RemoteStub exportObject(
            final Remote obj, final List<JInterceptorsGroup> jinterceptorsList) throws RemoteException {
        return (RemoteStub) JUnicastRemoteObject.exportObject(obj, 0, jinterceptorsList);
    }

    public static Remote exportObject(
            final Remote obj, final int p, final List<JInterceptorsGroup> jinterceptorsList) throws RemoteException {

        return JUnicastRemoteObject.exportObjectR(obj, new JUnicastServerRef(p, jinterceptorsList));
    }

    public static Remote exportObject(
            final Remote obj, final int p, final RMIClientSocketFactory csf, final RMIServerSocketFactory ssf,
            final List<JInterceptorsGroup> jinterceptorsList) throws RemoteException {

        return JUnicastRemoteObject.exportObjectR(obj, new JUnicastServerRefSf(p, csf, ssf, jinterceptorsList));
    }

    /**
     * Real export object (locally and remotely)
     * @param obj
     * @param serverRef
     * @param params
     * @param args
     * @return @throws RemoteException
     */
    protected static Remote exportObjectR(Remote obj, JUnicastServerRef serverRef) throws RemoteException {
        int localId = -2;
        if (Boolean.getBoolean(CarolDefaultValues.LOCAL_JRMP_PROPERTY)) {
            localId = JLocalObjectStore.storeObject(obj);
        }
        if (obj instanceof JUnicastRemoteObject) ((JUnicastRemoteObject) obj).ref = serverRef;
        Remote rob = serverRef.exportObject(obj, null, localId);
        return rob;
    }

    /**
     * Real unexport Object (locally and remotely)
     * @param obj
     * @param force
     * @return @throws NoSuchObjectException
     */
    public static boolean unexportObject(Remote obj, boolean force) throws NoSuchObjectException {
        if (Boolean.getBoolean(CarolDefaultValues.LOCAL_JRMP_PROPERTY)) {
            JUnicastRef remoteref = (JUnicastRef) ((RemoteStub) ObjectTable.getStub(obj)).getRef();
            JLocalObjectStore.removeObject(remoteref.getLocalId());
        }
        return ObjectTable.unexportObject(obj, force);
    }

    private void readObject(java.io.ObjectInputStream in) throws java.io.IOException, ClassNotFoundException {
        in.defaultReadObject();
        exportObject(null);
    }

    @Override
    public Object clone() throws CloneNotSupportedException {
        try {
            JUnicastRemoteObject cloned = (JUnicastRemoteObject) super.clone();
            cloned.exportObject(null);
            return cloned;
        } catch (RemoteException e) {
            throw new ServerCloneException("Clone failed", e);
        }
    }
}

