/**
 * Copyright (C) 2002-2007 - INRIA (www.inria.fr)
 *
 * CAROL: Common Architecture for RMI ObjectWeb Layer
 *
 * This library is developed inside the OW2 Consortium,
 * http://www.ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: NameServiceManager.java 1513 2007-11-25 12:22:17Z loris $
 * --------------------------------------------------------------------------
 */
package org.objectweb.carol.jndi.ns;


/**
 * Class <code> NameServicemanager </code> is the CAROL Name Service manager.
 * This is the carol API for Name services management
 * @author Guillaume Riviere
 */
@Deprecated
public final class NameServiceManager {


    /**
     * Private default constructor.
     */
    private NameServiceManager() {
    }


    /**
     * Start all names service
     * @throws NameServiceException if one of the name services is already start
     */
    public static void startNS() throws NameServiceException {
        try {
            org.ow2.carol.jndi.ns.NameServiceManager.getNameServiceManager().startNS();
        } catch(org.ow2.carol.jndi.ns.NameServiceException e) {
            throw new NameServiceException(e.getMessage());
        }
    }

    /**
     * Start all non-started names service
     */
    public static void startNonStartedNS() {
        org.ow2.carol.jndi.ns.NameServiceManager.getNameServiceManager().startNonStartedNS();
    }

    /**
     * Stop all name services
     * @throws NameServiceException if an exception occurs at stopping time
     */

    public static void stopNS() throws NameServiceException {
        try {
            org.ow2.carol.jndi.ns.NameServiceManager.getNameServiceManager().stopNS();
        } catch(org.ow2.carol.jndi.ns.NameServiceException e) {
            throw new NameServiceException(e.getMessage());
        }
    }

    /**
     * Main function: start all registry and wait for control C function
     * @param args arguments
     */
    public static void main(String[] args) {
        org.ow2.carol.jndi.ns.NameServiceManager.main(args);
    }
}
