 /**
 * Copyright (C) 2002-2007 - INRIA (www.inria.fr)
 *
 * CAROL: Common Architecture for RMI ObjectWeb Layer
 *
 * This library is developed inside the OW2 Consortium,
 * http://www.ow2.org
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307
 * USA
 *
 * --------------------------------------------------------------------------
 * $Id: JRMPServerRequestInfoImpl.java 1534 2007-12-11 09:22:19Z loris $
 * --------------------------------------------------------------------------
 */
package org.ow2.carol.rmi.jrmp.interceptor.impl;

import java.util.ArrayList;
import java.util.Collection;

import org.ow2.carol.rmi.jrmp.interceptor.api.JServerRequestInfo;
import org.ow2.carol.rmi.jrmp.interceptor.spi.JServiceContext;

/**
 * Class <code>JRMPServerRequestInfoImpl</code> is the CAROL JRMP Server
 * Request info (JServerRequestInfo) Implementation
 * @see org.ow2.carol.rmi.jrmp.interceptor.api.JServerRequestInfo
 * @author Guillaume Riviere (Guillaume.Riviere@inrialpes.fr)
 * @version 1.0, 15/07/2002
 */
public class JRMPServerRequestInfoImpl implements JServerRequestInfo {

    /**
     * Request Service Context ArrayList
     */
    protected ArrayList<JServiceContext> scTable = new ArrayList<JServiceContext>();

    /**
     * Empty constructor available for Request Information
     */
    public JRMPServerRequestInfoImpl() {
    }

    /**
     * add a JServicecontext
     * @param JServiceContext the context to add
     * @param boolean replace if true replace the existing service context
     */
    public void add_reply_service_context(JServiceContext jServiceContext) {
        scTable.add(jServiceContext);
    }

    /**
     * Add the all the reply service context
     * @param c Services contexts
     */
    public void add_all_reply_service_context(Collection<JServiceContext> c) {
        scTable.addAll(c);
    }

    /**
     * Get the context specified by this id if there is no context corresponding
     * with this id return null
     * @param id the context id
     * @return JServiceContex the specific ServiceContext
     */
    public JServiceContext get_request_service_context(int id) {
        for (JServiceContext jc : scTable) {
            if (jc.getContextId() == id) {
                return jc;
            }
        }
        return null;
    }

    /**
     * Get the all the request service context if there is no context return
     * null
     * @return Collection the ServiceContexts
     */
    public Collection<JServiceContext> get_all_request_service_context() {
        return scTable;
    }

    /**
     * Get the context specified by this id if there is no context corresponding
     * with this id return null
     * @param id the context id
     * @return JServiceContex the specific ServiceContext
     */
    public JServiceContext get_reply_service_context(int id) {
        for (JServiceContext jc : scTable) {
            if (jc.getContextId() == id) {
                return jc;
            }
        }
        return null;
    }

    /**
     * Get the all the reply service context
     * @return Collection the ServiceContexts
     */
    public Collection<JServiceContext> get_all_reply_service_context() {
        return scTable;
    }

    /**
     * true if exit one or more context
     */
    public boolean hasContexts() {
        return !(scTable.isEmpty());
    }

    /**
     * clear the service contexts table
     */
    public void clearAllContexts() {
        scTable.clear();
    }
}
