function initializeSlider(){
  var Revisionslider = d3.slider().axis(true).min(system_min_revision).max(system_max_revision).value(system_max_revision-num_of_dimension).on("slide", function(evt, value) {
    revisionSliderFunction(value);
  })
  d3.select("#revision_slider").call(Revisionslider);
  var numberslider = d3.slider().axis(true).min(5).max(100).value(100).on("slide", function(evt, value) {
    numberSliderFunction(value);
  })
  d3.select("#dimension_slider").call(numberslider);
}
function numberSliderFunction(value){
  num_of_dimension = Math.round(value);
  if(current_min_revision + num_of_dimension > system_max_revision){
    num_of_dimension = system_max_revision - current_min_revision;
  }
  document.getElementById("num_dim").innerText="# of revision shown: "+num_of_dimension;
  clearCurrentPC();
  // clone data form source file
  var new_data = Object.assign(data);
  reCreatePC(new_data);
}
function revisionSliderFunction(value){
  current_min_revision = Math.round(value);
  current_max_revision = current_min_revision+num_of_dimension;
  if(current_min_revision < system_min_revision){
    current_min_revision = system_min_revision;
    current_max_revision = system_min_revision+num_of_dimension;
  }
  if(current_max_revision > system_max_revision){
    current_max_revision = system_max_revision;
    current_min_revision = system_max_revision-num_of_dimension;
  }
  document.getElementById("current_start").innerText="Start from revision: "+current_min_revision;
  clearCurrentPC();
  // clone data form source file
  var new_data = Object.assign(data);
  reCreatePC(new_data);
}
