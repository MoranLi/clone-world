function createParallelCoordinate(dataIn){
  // create data pardoords
  // define dimensions function for data parcoords
  var parcoords_dimensions = {};
  var yaxislength = document.getElementById("example").clientHeight;
  var data_keys = Object.keys(dataIn[0]);
  var singledim = [];
  for(var y = 0;y<=max_instance_change_count;y+=max_instance_change_count/10){
    singledim.push(y)
  }
  for(var x = 0;x<data_keys.length;x++){
    if(isNormalInteger(data_keys[x])){
      parcoords_dimensions[data_keys[x]] = {
        type: 'number',
        tickPadding: 0,
        innerTickSize: 3,
        outerTickSize: 3,
        ticks : 0, 
        tickValues : [],
        yscale: d3.scale.linear().domain([0,max_instance_change_count]).range([yaxislength-40,0])
      }
    }
  }
  // create and initialize parallel coordinate
  parcoords = 
    d3.parcoords()("#example")
      .color(function(d){
        return coloring(d);
      })
      .alpha(0.5)
      .mode("queue");
  parcoords
    .margin({
      top: 20,
      left: 4,
      right: 20,
      bottom: 0
    });
  parcoords
    .data(dataIn)
    .smoothness(0)
    .composite("source-over")
    .nullValueSeparator("bottom")
    .dimensions(parcoords_dimensions)
    .render()
    .brushMode("1D-axes")
    .axisDots();

  var sumColor = d3.scale.linear().domain([0,max_change_count]).range(["#00FF00","#FF0000"])
  // create data table, row hover highlighting 
  var grid = d3.divgrid(["Cl.Frag.","Start","End"]);
  d3.select("#grid")
    .datum(dataIn)
    .call(grid)
    .selectAll(".rowx")
    .style("background",function(d){
      return sumColor(d.Change);
    })
    .on({
      "click": function(d) { 
        if(hightlight_chain.indexOf(d) === -1){
          hightlight_chain.push(d)
        }
        parcoords.highlight(hightlight_chain)
      }
    });
  
  parcoords.on("brush", function(d) {
    parcoords.unhighlight(hightlight_chain);
    brush_chain = [];
    for(var i = 0;i<d.length;i++){
      var d_info = d[i]['Name']+":"+d[i]['Type'];
      if(!brush_chain.includes(d_info) && d.length < data.length) {
        brush_chain.push(d_info);
      }
    }
    var grid = d3.divgrid(["Cl.Frag.","Start","End"]);
    d3.select("#grid")
      .datum(d)
      .call(grid)
      .selectAll(".rowx")
      .style("background",function(d){
        return sumColor(d.Change);
      })
      .on({
        "click": function(d) { 
          if(hightlight_chain.indexOf(d) === -1){
            hightlight_chain.push(d)
          }
          parcoords.highlight(hightlight_chain)
        }
      });
  });
  // change opacity of path to make parcoords curve readedable even in high number of dimension
  var font_size_scale = d3.scale.linear().domain([0,100]).range([15,5]);
  var font_size = font_size_scale(Object.keys(parcoords_dimensions).length)+"px";
  d3.selectAll("path").style("opacity", 0.1);
  d3.selectAll("text.label").style("font-size", font_size);
}
// clear data parcoords
function clearCurrentPC(){
  var myNode = document.getElementById("example");
  while (myNode.firstChild) {
    myNode.removeChild(myNode.firstChild);
  }
}
// recreate data parcoords
function reCreatePC(new_data){
  var mod_data = [];
  for(var i=0;i<new_data.length;i++){
    var curr_chain_info = new_data[i]['Name']+":"+new_data[i]['Type'];
    // match data in brush chain
    if(brush_chain.length>0 && brush_chain.indexOf(curr_chain_info) == -1) continue;
    var recreate = recreate_full_dimension_data(new_data[i]);
    mod_data.push(recreate);
  }
  mod_data.filter(function(d){
    return +d["Class"] >= 0;
  })
  current_data = mod_data;
  createParallelCoordinate(current_data,false);
  initializePathAxis();
}
// recreate data parcoords
function reCreateRevsionReducePC(new_data){
  var mod_data = [];
  for(var i=0;i<new_data.length;i++){
    var recreate = recreate_revision_reduce_data(new_data[i]);
    mod_data.push(recreate);
  }
  mod_data.filter(function(d){
    return +d["Class"] >= 0;
  })
  current_data = mod_data;
  createParallelCoordinate(current_data,true);
  initializePathAxis();
}
