function loadData(name,filter) {
  //*******************************************************************************
  // Main Function: load json file and read data for visualise***
  //*******************************************************************************
  // read source file for clone chain information
  if (!filter.types.find(d => d.id == 1)) filter.types.push({ id: 1, chains: [] });
  if (!filter.types.find(d => d.id == 2)) filter.types.push({ id: 2, chains: [] });
  if (!filter.types.find(d => d.id == 3)) filter.types.push({ id: 3, chains: [] });
  filter.types = filter.types.sort((a, b) => a.id - b.id);
  d3.json('../data_files/'+name+'.json', function(raw_data) {
    // read source file for different colors
    d3.json('../data_files/colors.json',function(color){
      document.getElementById("example").innerText = "";
      var colors = Object.assign(color);
      // initialize global variable
      chain_index_data = [{},{},{}];
      TypeClone = 1;
      showCrossBoundary = false;
      showOnlyLastRevsion = false;
      rectangled = false;
      num_of_dimension = 100;
      hightlight_chain = [];
      brush_chain = [];
      revision_change_chain = [];
      color_collection = {};
      // load clone chain by type and filter only the selected 
      var type1Info= {};
      type1_chain = [];
      raw_data.t1_clone_evolution.forEach(function(d){
        type1Info[parseInt(d['name'])] = {
          change : d['sumChangeCount'],
          class : d['lastClass']
        };
        var index = filter.types[0].chains.indexOf(d['name'].toString())
        if( index > -1){
          var new_d = d;
          new_d['cloneId'] = filter.types[0].associatingCloneIds[index];
          type1_chain.push(new_d);
        }
      })
      type1_support_edgelist = [];
      type1_cross_edgelist = [];
      type1_chain.forEach(function(element){
        if(element['baseCase']['changecount'] > 0){
          revision_change_chain.push(element['startRevision']);
        }
        if(color_collection[element['baseCase']['cloneclass']] == undefined){
          color_collection[element['baseCase']['cloneclass']] = colors.pop();
        }
        for( var clone of Object.keys(element['cloneInstances'])){
          var instance = element['cloneInstances'][clone];
          if(instance['changecount'] != undefined && instance['changecount'] > 0){
            revision_change_chain.push(parseInt(clone));
          }
          if(color_collection[instance['cloneclass']] == undefined){
            color_collection[instance['cloneclass']] = colors.pop();
          }
        }
        for( var edge of Object.keys(element["supportCountMap"])){
          if(filter.types[0].chains.indexOf(edge.toString()) > -1){
            type1_support_edgelist.push({
              source: parseInt(element['name']),
              target: parseInt(edge),
              weight: element["supportCountMap"][edge],
              n1weight: element['sumChangeCount'],
              n1Class: element['lastClass'],
              n2weight: type1Info[parseInt(edge)].change,
              n2Class: type1Info[parseInt(edge)].class,
            })
          }
        }
        for( var edge of Object.keys(element["crossBoundaryCountMap"])){
          if(filter.types[0].chains.indexOf(edge.toString()) > -1){
            type1_cross_edgelist.push({
              source: parseInt(element['name']),
              target: parseInt(edge),
              weight: element["crossBoundaryCountMap"][edge],
              n1weight: element['sumChangeCount'],
              n1Class: element['lastClass'],
              n2weight: type1Info[parseInt(edge)].change,
              n2Class: type1Info[parseInt(edge)].class,
            })
          }
        }
      })
      var type2Info= {};
      type2_chain = [];
      raw_data.t2_clone_evolution.forEach(function(d){
        type2Info[parseInt(d['name'])] = {
          change : d['sumChangeCount'],
          class : d['lastClass']
        };
        var index = filter.types[1].chains.indexOf(d['name'].toString())
        if( index > -1){
          var new_d = d;
          new_d['cloneId'] = filter.types[1].associatingCloneIds[index];
          type2_chain.push(new_d);
        }
      })
      type2_support_edgelist = [];
      type2_cross_edgelist = [];
      type2_chain.forEach(function(element){
        if(element['baseCase']['changecount'] > 0){
          revision_change_chain.push(element['startRevision']);
        }
        if(color_collection[element['baseCase']['cloneclass']] == undefined){
          color_collection[element['baseCase']['cloneclass']] = colors.pop();
        }
        for( var clone of Object.keys(element['cloneInstances'])){
          var instance = element['cloneInstances'][clone];
          if(instance['changecount'] != undefined && instance['changecount'] > 0){
            revision_change_chain.push(parseInt(clone));
          }
          if(color_collection[instance['cloneclass']] == undefined){
            color_collection[instance['cloneclass']] = colors.pop();
          }
        }
        for( var edge of Object.keys(element["supportCountMap"])){
          if(filter.types[1].chains.indexOf(edge.toString()) > -1){
            type2_support_edgelist.push({
              source: parseInt(element['name']),
              target: parseInt(edge),
              weight: element["supportCountMap"][edge],
              n1weight: element['sumChangeCount'],
              n1Class: element['lastClass'],
              n2weight: type2Info[parseInt(edge)].change,
              n2Class: type2Info[parseInt(edge)].class,
            })
          }
        }
        for( var edge of Object.keys(element["crossBoundaryCountMap"])){
          if(filter.types[1].chains.indexOf(edge.toString()) > -1){
            type2_cross_edgelist.push({
              source: parseInt(element['name']),
              target: parseInt(edge),
              weight: element["crossBoundaryCountMap"][edge],
              n1weight: element['sumChangeCount'],
              n1Class: element['lastClass'],
              n2weight: type2Info[parseInt(edge)].change,
              n2Class: type2Info[parseInt(edge)].class,
            })
          }
        }
      })
      var type3Info= {};
      type3_chain = [];
      raw_data.t3_clone_evolution.forEach(function(d){
        type3Info[parseInt(d['name'])] = {
          change : d['sumChangeCount'],
          class : d['lastClass']
        };
        var index = filter.types[2].chains.indexOf(d['name'].toString())
        if( index > -1){
          var new_d = d;
          new_d['cloneId'] = filter.types[2].associatingCloneIds[index];
          type3_chain.push(new_d);
        }
      })
      type3_support_edgelist = [];
      type3_cross_edgelist = [];
      type3_chain.forEach(function(element){
        if(element['baseCase']['changecount'] > 0){
          revision_change_chain.push(element['startRevision']);
        }
        if(color_collection[element['baseCase']['cloneclass']] == undefined){
          color_collection[element['baseCase']['cloneclass']] = colors.pop();
        }
        for( var clone of Object.keys(element['cloneInstances'])){
          var instance = element['cloneInstances'][clone];
          if(instance['changecount'] != undefined && instance['changecount'] > 0){
            revision_change_chain.push(parseInt(clone));
          }
          if(color_collection[instance['cloneclass']] == undefined){
            color_collection[instance['cloneclass']] = colors.pop();
          }
        }
        for( var edge of Object.keys(element["supportCountMap"])){
          if(filter.types[2].chains.indexOf(edge.toString()) > -1){
            type3_support_edgelist.push({
              source: parseInt(element['name']),
              target: parseInt(edge),
              weight: element["supportCountMap"][edge],
              n1weight: element['sumChangeCount'],
              n1Class: element['lastClass'],
              n2weight: type3Info[parseInt(edge)].change,
              n2Class: type3Info[parseInt(edge)].class,
            })
          }
        }
        for( var edge of Object.keys(element["crossBoundaryCountMap"])){
          if(filter.types[2].chains.indexOf(edge.toString()) > -1){
            type3_cross_edgelist.push({
              source: parseInt(element['name']),
              target: parseInt(edge),
              weight: element["crossBoundaryCountMap"][edge],
              n1weight: element['sumChangeCount'],
              n1Class: element['lastClass'],
              n2weight: type3Info[parseInt(edge)].change,
              n2Class: type3Info[parseInt(edge)].class,
            })
          }
        }
      })
      // combine the result and reorder from highest changecount to lowest
      var combineType123 = type1_chain.concat(type2_chain.concat(type3_chain)).sort(function(c1,c2){
        return c2.sumChangeCount - c1.sumChangeCount;
      })
      data = Object.assign(combineType123);
      // read color information
      // read max number for sum of changecount of each chain over all revison
      max_change_count = raw_data.max_changecount;
      // read max number for changecount of each clone instance
      max_instance_change_count = raw_data.max_instance_changecount;
      // read start and end revision of system
      system_min_revision = raw_data.min_revision;
      system_max_revision = raw_data.max_revision;
      current_min_revision = system_max_revision-num_of_dimension;
      current_max_revision = system_max_revision;
      document.getElementById("current_start").innerText="Start from revision: "+current_min_revision;
      database_name = raw_data.system_name;
      // store index of each chain in origin data
      for(var i=0;i<data.length;i++){
        if(data[i]["type"] === 1){
          chain_index_data[0][data[i]["name"]] = i;
        }
        if(data[i]["type"] === 2){
          chain_index_data[1][data[i]["name"]] = i;
        }
        if(data[i]["type"] === 3){
          chain_index_data[2][data[i]["name"]] = i;
        }
      }
      // copy the data, make data reuseable
      var new_data = Object.assign(data);
      // initialize visualization
      reCreatePC(new_data);
      initializePathAxis();
      var width = document.getElementById('s1svg').parentElement.clientWidth - 100 ;
      var height = document.getElementById('s1svg').parentElement.clientHeight - 50;
      // if(width < height){
      //   height = height/width * 100;
      //   width = width;
      // }
      // else {
      //   width = width/height * 100;
      //   height = 100; 
      // }
      document.getElementById('s1svg').setAttribute("viewbox","0 0 "+width+" "+height);
      document.getElementById('s2svg').setAttribute("viewbox","0 0 "+width+" "+height);
      document.getElementById('s3svg').setAttribute("viewbox","0 0 "+width+" "+height);
      document.getElementById('c1svg').setAttribute("viewbox","0 0 "+width+" "+height);
      document.getElementById('c2svg').setAttribute("viewbox","0 0 "+width+" "+height);
      document.getElementById('c3svg').setAttribute("viewbox","0 0 "+width+" "+height);
      createNetwork(type1_support_edgelist,'s1',width, height);
      createNetwork(type1_cross_edgelist,'c1',width, height);
      createNetwork(type2_support_edgelist,'s2',width, height);
      createNetwork(type2_cross_edgelist,'c2',width, height);
      createNetwork(type3_support_edgelist,'s3',width, height);
      createNetwork(type3_cross_edgelist,'c3',width, height);
      // initialize control
      initializeControl();
    })
  });
}

function initializeTypeClone(type_chain, type_support_edgelist, type_cross_edgelist){

}

// add event listener to controls
function initializeControl(){
  // initailize function for buttons
   initializeButton();
  // initialize slider to control max dimension
   initializeSlider();
}