function recreate_full_dimension_data(chain){
  var newData = {};
  var j = current_min_revision;
  var lastClass = undefined;
  current_max_revision = current_min_revision+num_of_dimension;
  // load data by revision 
  for(;j<=current_max_revision;j++){
    // not data in current revision
    if(j == chain["startRevision"]){
      newData[j] = chain["baseCase"]["changecount"];
    }
    else{
      if(chain["cloneInstances"][j] == undefined){
        newData[j] = 0;
        lastClass = -1;
      }
      else{
        if(chain["cloneInstances"][j]["changecount"] == undefined){
          newData[j] = chain["baseCase"]["changecount"];
        }
        else{
          newData[j] = parseInt(chain["cloneInstances"][j]["changecount"]);
        }
        // reset lastClass used to color chain
        if(chain["cloneInstances"][j]["cloneclass"] != undefined){
          lastClass = chain["cloneInstances"][j]["cloneclass"];
        }
      }
    }
  }
  if(lastClass == undefined){
    lastClass = chain["baseCase"]["cloneclass"];
  }
  // copy other field from original data
  newData["Name"] = chain["name"];
  newData["Start"] = chain ["startRevision"];
  newData["End"] = chain["endRevision"];
  newData["Type"] = chain["type"];
  newData["Change"] = chain["sumChangeCount"];
  newData["Class"] = lastClass;
  newData["supportCount"] = chain["supportCountMap"];
  newData["Cl.Frag."] =  chain["type"]+":"+chain["lastClass"]+":"+chain["cloneId"];
  return newData;
}
function recreate_revision_reduce_data(chain){
  var newData = {};
  var lastClass = undefined;
  current_min_revision = Math.min.apply(null,revision_change_chain);
  current_max_revision = Math.max.apply(null,revision_change_chain);
  // load data by revision 
  for(var j of revision_change_chain){
    // not data in current revision
    if(j == chain["startRevision"]){
      newData[j] = chain["baseCase"]["changecount"];
    }
    else{
      if(chain["cloneInstances"][j] == undefined){
        newData[j] = 0;
        lastClass = -1;
      }
      else{
        if(chain["cloneInstances"][j]["changecount"] == undefined){
          newData[j] = chain["baseCase"]["changecount"];
        }
        else{
          newData[j] = parseInt(chain["cloneInstances"][j]["changecount"]);
        }
        // reset lastClass used to color chain
        if(chain["cloneInstances"][j]["cloneclass"] != undefined){
          lastClass = chain["cloneInstances"][j]["cloneclass"];
        }
      }
    }
  }
  if(lastClass == undefined){
    lastClass = chain["baseCase"]["cloneclass"];
  }
  if(Object.keys(newData).length == 1){
    var index = Object.keys(newData)[0];
    newData[parseInt(index)+1] = 0;
  }
  // copy other field from original data
  newData["Name"] = chain["name"];
  newData["Start"] = chain ["startRevision"];
  newData["End"] = chain["endRevision"];
  newData["Type"] = chain["type"];
  newData["Change"] = chain["sumChangeCount"];
  newData["Class"] = lastClass;
  newData["supportCount"] = chain["supportCountMap"];
  newData["Cl.Frag."] =  chain["type"]+":"+chain["lastClass"]+":"+chain["cloneId"];
  return newData;
}