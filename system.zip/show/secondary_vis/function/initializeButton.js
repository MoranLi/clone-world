function initializeUnhighlightButton(){
  // set unhighlight to unhighlight button
  document.getElementById("highlight").addEventListener("click",function(){
    parcoords.unhighlight(hightlight_chain);
    hightlight_chain = [];
  })
}
function initializeResetDataButton(){
  // set reset function to reset whole system to default view
  document.getElementById("resetData").addEventListener("click",function(){
    brush_chain = [];
    current_data = [];
    // clone data form source file
    var new_data = Object.assign(data)
    clearCurrentPC();
    reCreatePC(new_data);                
  })
}
function initializeRevisionReduceButton(){
  // set reset function to reset whole system to default view
  document.getElementById("revisionReduce").addEventListener("click",function(){
    current_data = [];
    // clone data form source file
    var new_data = Object.assign(data)
    clearCurrentPC();
    reCreateRevsionReducePC(new_data);               
  })
}
// general function to initialize button
function initializeButton(){
  initializeUnhighlightButton();
  initializeResetDataButton();
  initializeRevisionReduceButton();
}

