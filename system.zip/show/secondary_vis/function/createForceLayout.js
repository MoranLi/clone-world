function createNetwork(edgelist, id, width, height) {

  if(edgelist.length === 0){
    document.getElementById(id).innerText+="\n No data selected";
    return;
  }
  var nodeHash = {};
  var nodes = [];
  var edges = [];

  edgelist.forEach(function (edge) {
    if (!nodeHash[edge.source]) {
      nodeHash[edge.source] = {id: edge.source, label: edge.source, weight: edge.n1weight, Class: edge.n1Class};
      nodes.push(nodeHash[edge.source]);
    }
    if (!nodeHash[edge.target]) {
      nodeHash[edge.target] = {id: edge.target, label: edge.target, weight: edge.n2weight, Class: edge.n2Class};
      nodes.push(nodeHash[edge.target]);
    }
    edges.push({source: nodeHash[edge.source], target: nodeHash[edge.target], weight: edge.weight});
  });
  createForceNetwork(nodes, edges, id, width, height);
}

function createForceNetwork(nodes, edges, id, width, height) {

//create a network from an edgelist

  var node_data = nodes.map(function (d) {
    return d.id
  });
  var edge_data = edges.map(function (d) {
    return {
      source: d.source.id,
      target: d.target.id,
      weight: d.weight > 0 ? 1 : 0
    };
  });

  var community = jLouvain().nodes(node_data).edges(edge_data);
  var result = community(); 

  var community_data = {};

  nodes.forEach(function (node) {
    node.module = result[node.id]
    if(community_data[result[node.id]] === undefined){
      community_data[result[node.id]] = [];
    }
    if(community_data[result[node.id]].indexOf(node.id) == -1){
      community_data[result[node.id]].push(node.id);
    }
  });

  var getRadius = d3.scale.linear().domain([0,max_change_count]).range([1,5])

  var force = d3.layout.force().nodes(nodes).links(edges)
    .size([width,height])
    .charge(function (d) {return Math.min(-10, getRadius(d.weight) * -5)}) 
    .gravity(0.5)
    .on("tick", updateNetwork);

  d3.select("svg."+id)
    .on("click",function(){
      contextMenuEnter.selectAll("*").remove();
    })

  var g = d3.select("svg."+id)
    .style("width",width)
    .style("height",height)
    .append("g")
    .attr("class","collect"+id);
    
  d3.select("g.collect"+id).selectAll("line")
    .data(edges)
    .enter()
    .append("line")
    .style("stroke-width", "1px")
    .style("stroke", "#996666")
    .attr("opacity", 0.3);

  var nodeEnter = d3.select("g.collect"+id).selectAll("g.node")
    .data(nodes)
    .enter()
    .append("g")
    .attr("class", "node")
    // .on("click", nodeClick)
    // .on("dblclick", nodeDoubleClick)
    // .on("mouseover", nodeOver)
    // .on("mouseout", nodeOut)
    .on("contextmenu", function (d) {
      d3.event.preventDefault();
      var width = 100;
      var height = 50;
      contextMenuEnter.selectAll("*").remove();
      contextMenuEnter
        .append("rect")
        .attr("transform", "translate(" + d.x + "," + d.y + ")")
        .attr("x", 0)
        .attr("y", 0)
        .attr("width", width)
        .attr("height", height+10)
        .attr("stroke", "black")
        .attr("stroke-width", 1)
        .attr("fill", "azure")
        .attr("opacity", .85);
      contextMenuEnter
        .append("text")
        .datum(d)
        .attr("x", d.x)
        .attr("y", d.y+20)
        .style("cursor", "pointer")
        .text("open")
        .on("click", function(){
            openFile(d,false);
            contextMenuEnter.selectAll("*").remove();
        });
      contextMenuEnter
        .append("text")
        .datum(d)
        .attr("x", d.x)
        .attr("y", d.y+50)
        .style("cursor", "pointer")
        .text("open all")
        .on("click", function(){
            openFile(d,true);
            contextMenuEnter.selectAll("*").remove();
        });
      })
    .call(force.drag());

  nodeEnter.append("circle")
    .attr("r", function(d){
      return getRadius(d.weight);
    })
    .style("fill", function(d){
      return coloring(d);
    })
    .style("stroke", "black")
    .style("stroke-width", "1px")
  
  nodeEnter.append("title").text(d => "chain id: "+d.id+", class id:"+d.Class);
  
  var contextMenuEnter = d3.select("svg."+id).append("g")
    .classed("context-menu", true);

  
  var zoom = d3.behavior.zoom().scaleExtent([1,7])
  zoom.on("zoom", function() {
    g.attr("transform", "translate(" + d3.event.translate + ")scale(" + d3.event.scale + ")");
  });

  d3.select("svg."+id).call(zoom);
  // nodeEnter.append("text")
  //   .style("text-anchor", "middle")
  //   .attr("y", 2)
  //   .style("stroke-width", "1px")
  //   .style("stroke-opacity", 0.75)
  //   .style("stroke", "white")
  //   .style("font-size", "8px")
  //   .text(function (d) {return d.id})
  //   .style("pointer-events", "none")

  // nodeEnter.append("text")
  //   .style("text-anchor", "middle")
  //   .attr("y", 2)
  //   .style("font-size", "8px")
  //   .text(function (d) {return d.id})
  //   .style("pointer-events", "none")

  force.start();

  function nodeClick(d) {
    d.fixed = true;
  }

  function nodeDoubleClick(d) {
    d.fixed = false;
  }

  function nodeOver(d) {
    force.stop();
    highlightEgoNetwork(d);
  }

  function nodeOut() {
    force.start();
    d3.selectAll("g.node > circle")
      .style("fill", function(d){
        return coloring(d);
      })

    d3.selectAll("line")
      .style("stroke", "#996666")
      .style("stroke-width", "1px");
  }

  function highlightEgoNetwork(d) {
    var egoIDs = [];
    var filteredEdges = edges.filter(function (p) {return p.source == d || p.target == d});

    filteredEdges
      .forEach(function (p) {
        if (p.source == d) {
          egoIDs.push(p.target.id)
        }
        else {
          egoIDs.push(p.source.id)
        }
      });

    d3.selectAll("line").filter(function (p) {return filteredEdges.indexOf(p) > -1})
      .style("stroke", "#66CCCC")
      .style("stroke-width", "2px");

    d3.selectAll("circle").filter(function (p) {return egoIDs.indexOf(p.id) > -1})
      .style("fill", "#66CCCC");
  }

  function updateNetwork() {
    d3.select("svg."+id).selectAll("line")
      .attr("x1", function (d) {return d.source.x})
      .attr("y1", function (d) {return d.source.y})
      .attr("x2", function (d) {return d.target.x})
      .attr("y2", function (d) {return d.target.y});

    d3.select("svg."+id).selectAll("g.node")
      .attr("transform", function (d) {return "translate(" + d.x + "," + d.y + ")"});

    // d3.select("svg."+id).selectAll("g.node > circle")
    //   .attr("r", function (d) {
    //     return d.weight
    //   });

  }

  function openFile(d,community){

    var chains;
    chains = community_data[d.module];
    // check if there is not an real path
    if(Object.keys(data[chain_index_data[parseInt(id[1])-1][d.id]]["supportCountMap"]).length === 0){
      chains = [d.id];
    }
    if(!community){
      chains = [d.id];
    }
    var new_data = Object.assign(data);
    current_changecount = [];
    if(chains.length === 1){
        var chain = new_data[chain_index_data[parseInt(id[1])-1][chains[0]]];
        openNewFile(chain);
    }
    else{
        if(window.confirm("Will Open "+chains.length+" files ?")){
            for(var i=0;i<chains.length;i++){
                var chain = new_data[chain_index_data[parseInt(id[1])-1][chains[i]]];
                openNewFile(chain);
            }
        }
    }

  function openNewFile(chain){
    var filePath;
    var startline;
    var endline;
    if(Object.keys(chain["cloneInstances"]).length === 0){
      filePath = chain["baseCase"]["filepath"];
      startline = chain["baseCase"]["startLine"];
      endline = chain["baseCase"]["endLine"];
    }
    else{
      filePath = chain["cloneInstances"][chain["endRevision"]]["filepath"];
      if(filePath == undefined){
        filePath = chain["baseCase"]["filepath"];
      }
      startline = parseInt(chain["cloneInstances"][chain["endRevision"]]["startline"]);
      if(startline == undefined){
        startline = chain["baseCase"]["startLine"];
      }
      endline = parseInt(chain["cloneInstances"][chain["endRevision"]]["endline"]);
      if(endline == undefined){
        endline = chain["baseCase"]["endLine"];
      }
    }
    //var filep = window.location.href.substring(0,window.location.href.length-10)+'/data/'+database_name+"/"+filePath;
    var filep = '../data_files/src/'+filePath;
    d3.text(filep,function(error,file){
      if(error){
        alert("File not exist");
        return;
      }
      var myWindow=window.open();
      var file_array = file.split("\n");
      myWindow.document.write("<ol>");
      for(var i=0;i<file_array.length;i++){
        if(i >= startline-1 && i <= endline-1){
          myWindow.document.write("<li style=\"background: lightgreen\">");
        }
        else{
          myWindow.document.write("<li>");
        }
        myWindow.document.write(file_array[i]);
        myWindow.document.write("</li>");
      }
      myWindow.document.write("</ol>");
      myWindow.scrollTo(0,startline*22);
      myWindow.focus();
    })
  }
}


}