/**
 * global dom/d3 elements, need to be accssable through multiple file
 */
// data parcoords element
// reason be global: reset highlight button
var parcoords;
/**
 * original datas
 * data copy from source file
 * reduce cost of re-read from source file in multiple functions
 */
// name of dataset
var database_name;
// copy of combination of all original clone chain informations
var data;
// copy of original type 1/2/3 clone chains
var type1_chain;
var type2_chain;
var type3_chain;
// copy of original support count edge list
var type1_support_edgelist;
var type2_support_edgelist;
var type3_support_edgelist;
// copy of original crossboundary count edge list
var type1_cross_edgelist;
var type2_cross_edgelist;
var type3_cross_edgelist;
// copy of color set
var color_collection;
// store system min, max revision, for future change # of axis
var system_min_revision;
var system_max_revision;
// store highest total changecount for all the clone chain
var max_change_count;
// store highest instance changecount for all clone instance from data
var max_instance_change_count;
// store index of chain in data group by type
// initialized when load file
var chain_index_data;
// store all revision number which have change in at least one clone chain
var revision_change_chain;
/**
 * conditional variable global
 * global variable modified by control functions(button, slider, select)
 * accessable conditional variable for functions when recreate element
 */
// store current min/max revision
var current_min_revision;
var current_max_revision;
// current # of dimension
var current_dimension;
// record number of dimension shown
var num_of_dimension;
// store chains need to highlight
var hightlight_chain;
// store result of brush
var brush_chain;
// store x-axis for all dimension in pc
var pathes;
/**
 * store dataset for data parcoords 
 * may applied to different conditionalk variable when control changes
 * reduce data couping
 */
// current data set of data parcoords
var current_data;

// check if papamter string is an integer
// https://stackoverflow.com/questions/10834796/validate-that-a-string-is-a-positive-integer
function isNormalInteger(str) {
  return /^\+?(0|[1-9]\d*)$/.test(str);
}
// give each clone chain an color
var coloring = function(d) {
  if(d["Class"] == -1){
    return "#D1D2D3";
  }
  return color_collection[d["Class"]];
};

function initializePathAxis(){
  // calculate a axis for each dimension
  // base on x axis of each path
  pathes = [];
  Array.prototype.forEach.call(document.getElementsByTagName("path"),function(path){
    var x = (path.getBoundingClientRect().left + path.getBoundingClientRect().right) / 2
    pathes.push(x);
  })
  pathes.pop();
}